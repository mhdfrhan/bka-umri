import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Public\ChatbotController::send
 * @see app/Http/Controllers/Public/ChatbotController.php:15
 * @route '/api/chatbot/send'
 */
export const send = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: send.url(options),
    method: 'post',
})

send.definition = {
    methods: ["post"],
    url: '/api/chatbot/send',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Public\ChatbotController::send
 * @see app/Http/Controllers/Public/ChatbotController.php:15
 * @route '/api/chatbot/send'
 */
send.url = (options?: RouteQueryOptions) => {
    return send.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Public\ChatbotController::send
 * @see app/Http/Controllers/Public/ChatbotController.php:15
 * @route '/api/chatbot/send'
 */
send.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: send.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Public\ChatbotController::send
 * @see app/Http/Controllers/Public/ChatbotController.php:15
 * @route '/api/chatbot/send'
 */
    const sendForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: send.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Public\ChatbotController::send
 * @see app/Http/Controllers/Public/ChatbotController.php:15
 * @route '/api/chatbot/send'
 */
        sendForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: send.url(options),
            method: 'post',
        })
    
    send.form = sendForm
/**
* @see \App\Http\Controllers\Public\ChatbotController::newSession
 * @see app/Http/Controllers/Public/ChatbotController.php:43
 * @route '/api/chatbot/new-session'
 */
export const newSession = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: newSession.url(options),
    method: 'post',
})

newSession.definition = {
    methods: ["post"],
    url: '/api/chatbot/new-session',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Public\ChatbotController::newSession
 * @see app/Http/Controllers/Public/ChatbotController.php:43
 * @route '/api/chatbot/new-session'
 */
newSession.url = (options?: RouteQueryOptions) => {
    return newSession.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Public\ChatbotController::newSession
 * @see app/Http/Controllers/Public/ChatbotController.php:43
 * @route '/api/chatbot/new-session'
 */
newSession.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: newSession.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Public\ChatbotController::newSession
 * @see app/Http/Controllers/Public/ChatbotController.php:43
 * @route '/api/chatbot/new-session'
 */
    const newSessionForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: newSession.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Public\ChatbotController::newSession
 * @see app/Http/Controllers/Public/ChatbotController.php:43
 * @route '/api/chatbot/new-session'
 */
        newSessionForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: newSession.url(options),
            method: 'post',
        })
    
    newSession.form = newSessionForm
/**
* @see \App\Http\Controllers\Public\ChatbotController::faqs
 * @see app/Http/Controllers/Public/ChatbotController.php:53
 * @route '/api/chatbot/faqs'
 */
export const faqs = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: faqs.url(options),
    method: 'get',
})

faqs.definition = {
    methods: ["get","head"],
    url: '/api/chatbot/faqs',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Public\ChatbotController::faqs
 * @see app/Http/Controllers/Public/ChatbotController.php:53
 * @route '/api/chatbot/faqs'
 */
faqs.url = (options?: RouteQueryOptions) => {
    return faqs.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Public\ChatbotController::faqs
 * @see app/Http/Controllers/Public/ChatbotController.php:53
 * @route '/api/chatbot/faqs'
 */
faqs.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: faqs.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Public\ChatbotController::faqs
 * @see app/Http/Controllers/Public/ChatbotController.php:53
 * @route '/api/chatbot/faqs'
 */
faqs.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: faqs.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Public\ChatbotController::faqs
 * @see app/Http/Controllers/Public/ChatbotController.php:53
 * @route '/api/chatbot/faqs'
 */
    const faqsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: faqs.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Public\ChatbotController::faqs
 * @see app/Http/Controllers/Public/ChatbotController.php:53
 * @route '/api/chatbot/faqs'
 */
        faqsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: faqs.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Public\ChatbotController::faqs
 * @see app/Http/Controllers/Public/ChatbotController.php:53
 * @route '/api/chatbot/faqs'
 */
        faqsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: faqs.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    faqs.form = faqsForm
const chatbot = {
    send: Object.assign(send, send),
newSession: Object.assign(newSession, newSession),
faqs: Object.assign(faqs, faqs),
}

export default chatbot