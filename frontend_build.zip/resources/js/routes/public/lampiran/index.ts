import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Public\LampiranController::index
 * @see app/Http/Controllers/Public/LampiranController.php:18
 * @route '/lampiran'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/lampiran',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Public\LampiranController::index
 * @see app/Http/Controllers/Public/LampiranController.php:18
 * @route '/lampiran'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Public\LampiranController::index
 * @see app/Http/Controllers/Public/LampiranController.php:18
 * @route '/lampiran'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Public\LampiranController::index
 * @see app/Http/Controllers/Public/LampiranController.php:18
 * @route '/lampiran'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Public\LampiranController::index
 * @see app/Http/Controllers/Public/LampiranController.php:18
 * @route '/lampiran'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Public\LampiranController::index
 * @see app/Http/Controllers/Public/LampiranController.php:18
 * @route '/lampiran'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Public\LampiranController::index
 * @see app/Http/Controllers/Public/LampiranController.php:18
 * @route '/lampiran'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Public\LampiranController::download
 * @see app/Http/Controllers/Public/LampiranController.php:83
 * @route '/lampiran/download/{id}'
 */
export const download = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: download.url(args, options),
    method: 'get',
})

download.definition = {
    methods: ["get","head"],
    url: '/lampiran/download/{id}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Public\LampiranController::download
 * @see app/Http/Controllers/Public/LampiranController.php:83
 * @route '/lampiran/download/{id}'
 */
download.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    id: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        id: args.id,
                }

    return download.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Public\LampiranController::download
 * @see app/Http/Controllers/Public/LampiranController.php:83
 * @route '/lampiran/download/{id}'
 */
download.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: download.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Public\LampiranController::download
 * @see app/Http/Controllers/Public/LampiranController.php:83
 * @route '/lampiran/download/{id}'
 */
download.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: download.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Public\LampiranController::download
 * @see app/Http/Controllers/Public/LampiranController.php:83
 * @route '/lampiran/download/{id}'
 */
    const downloadForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: download.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Public\LampiranController::download
 * @see app/Http/Controllers/Public/LampiranController.php:83
 * @route '/lampiran/download/{id}'
 */
        downloadForm.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: download.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Public\LampiranController::download
 * @see app/Http/Controllers/Public/LampiranController.php:83
 * @route '/lampiran/download/{id}'
 */
        downloadForm.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: download.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    download.form = downloadForm
/**
* @see \App\Http\Controllers\Public\LampiranController::kategori
 * @see app/Http/Controllers/Public/LampiranController.php:39
 * @route '/lampiran/{slug}'
 */
export const kategori = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: kategori.url(args, options),
    method: 'get',
})

kategori.definition = {
    methods: ["get","head"],
    url: '/lampiran/{slug}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Public\LampiranController::kategori
 * @see app/Http/Controllers/Public/LampiranController.php:39
 * @route '/lampiran/{slug}'
 */
kategori.url = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { slug: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    slug: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        slug: args.slug,
                }

    return kategori.definition.url
            .replace('{slug}', parsedArgs.slug.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Public\LampiranController::kategori
 * @see app/Http/Controllers/Public/LampiranController.php:39
 * @route '/lampiran/{slug}'
 */
kategori.get = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: kategori.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Public\LampiranController::kategori
 * @see app/Http/Controllers/Public/LampiranController.php:39
 * @route '/lampiran/{slug}'
 */
kategori.head = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: kategori.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Public\LampiranController::kategori
 * @see app/Http/Controllers/Public/LampiranController.php:39
 * @route '/lampiran/{slug}'
 */
    const kategoriForm = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: kategori.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Public\LampiranController::kategori
 * @see app/Http/Controllers/Public/LampiranController.php:39
 * @route '/lampiran/{slug}'
 */
        kategoriForm.get = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: kategori.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Public\LampiranController::kategori
 * @see app/Http/Controllers/Public/LampiranController.php:39
 * @route '/lampiran/{slug}'
 */
        kategoriForm.head = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: kategori.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    kategori.form = kategoriForm
const lampiran = {
    index: Object.assign(index, index),
download: Object.assign(download, download),
kategori: Object.assign(kategori, kategori),
}

export default lampiran