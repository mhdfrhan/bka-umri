import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
import profil from './profil'
import bidang from './bidang'
import berita from './berita'
import pengumuman from './pengumuman'
import dokumentasi from './dokumentasi'
import lampiran from './lampiran'
import kontak from './kontak'
/**
* @see \App\Http\Controllers\Public\SitemapController::sitemap
 * @see app/Http/Controllers/Public/SitemapController.php:20
 * @route '/sitemap.xml'
 */
export const sitemap = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: sitemap.url(options),
    method: 'get',
})

sitemap.definition = {
    methods: ["get","head"],
    url: '/sitemap.xml',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Public\SitemapController::sitemap
 * @see app/Http/Controllers/Public/SitemapController.php:20
 * @route '/sitemap.xml'
 */
sitemap.url = (options?: RouteQueryOptions) => {
    return sitemap.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Public\SitemapController::sitemap
 * @see app/Http/Controllers/Public/SitemapController.php:20
 * @route '/sitemap.xml'
 */
sitemap.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: sitemap.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Public\SitemapController::sitemap
 * @see app/Http/Controllers/Public/SitemapController.php:20
 * @route '/sitemap.xml'
 */
sitemap.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: sitemap.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Public\SitemapController::sitemap
 * @see app/Http/Controllers/Public/SitemapController.php:20
 * @route '/sitemap.xml'
 */
    const sitemapForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: sitemap.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Public\SitemapController::sitemap
 * @see app/Http/Controllers/Public/SitemapController.php:20
 * @route '/sitemap.xml'
 */
        sitemapForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: sitemap.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Public\SitemapController::sitemap
 * @see app/Http/Controllers/Public/SitemapController.php:20
 * @route '/sitemap.xml'
 */
        sitemapForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: sitemap.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    sitemap.form = sitemapForm
/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/maintenance'
 */
export const maintenance = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: maintenance.url(options),
    method: 'get',
})

maintenance.definition = {
    methods: ["get","head"],
    url: '/maintenance',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/maintenance'
 */
maintenance.url = (options?: RouteQueryOptions) => {
    return maintenance.definition.url + queryParams(options)
}

/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/maintenance'
 */
maintenance.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: maintenance.url(options),
    method: 'get',
})
/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/maintenance'
 */
maintenance.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: maintenance.url(options),
    method: 'head',
})

    /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/maintenance'
 */
    const maintenanceForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: maintenance.url(options),
        method: 'get',
    })

            /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/maintenance'
 */
        maintenanceForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: maintenance.url(options),
            method: 'get',
        })
            /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/maintenance'
 */
        maintenanceForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: maintenance.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    maintenance.form = maintenanceForm
const publicMethod = {
    profil: Object.assign(profil, profil),
bidang: Object.assign(bidang, bidang),
berita: Object.assign(berita, berita),
pengumuman: Object.assign(pengumuman, pengumuman),
dokumentasi: Object.assign(dokumentasi, dokumentasi),
lampiran: Object.assign(lampiran, lampiran),
kontak: Object.assign(kontak, kontak),
sitemap: Object.assign(sitemap, sitemap),
maintenance: Object.assign(maintenance, maintenance),
}

export default publicMethod