import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Public\KontakController::index
 * @see app/Http/Controllers/Public/KontakController.php:19
 * @route '/kontak'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/kontak',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Public\KontakController::index
 * @see app/Http/Controllers/Public/KontakController.php:19
 * @route '/kontak'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Public\KontakController::index
 * @see app/Http/Controllers/Public/KontakController.php:19
 * @route '/kontak'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Public\KontakController::index
 * @see app/Http/Controllers/Public/KontakController.php:19
 * @route '/kontak'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Public\KontakController::index
 * @see app/Http/Controllers/Public/KontakController.php:19
 * @route '/kontak'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Public\KontakController::index
 * @see app/Http/Controllers/Public/KontakController.php:19
 * @route '/kontak'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Public\KontakController::index
 * @see app/Http/Controllers/Public/KontakController.php:19
 * @route '/kontak'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Public\KontakController::store
 * @see app/Http/Controllers/Public/KontakController.php:50
 * @route '/kontak'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/kontak',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Public\KontakController::store
 * @see app/Http/Controllers/Public/KontakController.php:50
 * @route '/kontak'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Public\KontakController::store
 * @see app/Http/Controllers/Public/KontakController.php:50
 * @route '/kontak'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Public\KontakController::store
 * @see app/Http/Controllers/Public/KontakController.php:50
 * @route '/kontak'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Public\KontakController::store
 * @see app/Http/Controllers/Public/KontakController.php:50
 * @route '/kontak'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
const kontak = {
    index: Object.assign(index, index),
store: Object.assign(store, store),
}

export default kontak