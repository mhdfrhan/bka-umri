import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
import beranda from './beranda'
import bidang from './bidang'
import profil from './profil'
import berita from './berita'
import pengumuman from './pengumuman'
import dokumentasi from './dokumentasi'
import aset from './aset'
import dokumen from './dokumen'
import settings from './settings'
import chatbot from './chatbot'
import users from './users'
import logs from './logs'
import securityAudit from './security-audit'
import monitoring from './monitoring'
/**
* @see \App\Http\Controllers\Admin\AsetController::editorUpload
 * @see app/Http/Controllers/Admin/AsetController.php:145
 * @route '/admin/editor-upload'
 */
export const editorUpload = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: editorUpload.url(options),
    method: 'post',
})

editorUpload.definition = {
    methods: ["post"],
    url: '/admin/editor-upload',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\AsetController::editorUpload
 * @see app/Http/Controllers/Admin/AsetController.php:145
 * @route '/admin/editor-upload'
 */
editorUpload.url = (options?: RouteQueryOptions) => {
    return editorUpload.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AsetController::editorUpload
 * @see app/Http/Controllers/Admin/AsetController.php:145
 * @route '/admin/editor-upload'
 */
editorUpload.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: editorUpload.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\AsetController::editorUpload
 * @see app/Http/Controllers/Admin/AsetController.php:145
 * @route '/admin/editor-upload'
 */
    const editorUploadForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: editorUpload.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AsetController::editorUpload
 * @see app/Http/Controllers/Admin/AsetController.php:145
 * @route '/admin/editor-upload'
 */
        editorUploadForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: editorUpload.url(options),
            method: 'post',
        })
    
    editorUpload.form = editorUploadForm
/**
* @see \App\Http\Controllers\Admin\AsetController::editorImageDelete
 * @see app/Http/Controllers/Admin/AsetController.php:187
 * @route '/admin/editor-image'
 */
export const editorImageDelete = (options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: editorImageDelete.url(options),
    method: 'delete',
})

editorImageDelete.definition = {
    methods: ["delete"],
    url: '/admin/editor-image',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Admin\AsetController::editorImageDelete
 * @see app/Http/Controllers/Admin/AsetController.php:187
 * @route '/admin/editor-image'
 */
editorImageDelete.url = (options?: RouteQueryOptions) => {
    return editorImageDelete.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AsetController::editorImageDelete
 * @see app/Http/Controllers/Admin/AsetController.php:187
 * @route '/admin/editor-image'
 */
editorImageDelete.delete = (options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: editorImageDelete.url(options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Admin\AsetController::editorImageDelete
 * @see app/Http/Controllers/Admin/AsetController.php:187
 * @route '/admin/editor-image'
 */
    const editorImageDeleteForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: editorImageDelete.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AsetController::editorImageDelete
 * @see app/Http/Controllers/Admin/AsetController.php:187
 * @route '/admin/editor-image'
 */
        editorImageDeleteForm.delete = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: editorImageDelete.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    editorImageDelete.form = editorImageDeleteForm
const admin = {
    beranda: Object.assign(beranda, beranda),
bidang: Object.assign(bidang, bidang),
profil: Object.assign(profil, profil),
berita: Object.assign(berita, berita),
pengumuman: Object.assign(pengumuman, pengumuman),
dokumentasi: Object.assign(dokumentasi, dokumentasi),
aset: Object.assign(aset, aset),
editorUpload: Object.assign(editorUpload, editorUpload),
editorImageDelete: Object.assign(editorImageDelete, editorImageDelete),
dokumen: Object.assign(dokumen, dokumen),
settings: Object.assign(settings, settings),
chatbot: Object.assign(chatbot, chatbot),
users: Object.assign(users, users),
logs: Object.assign(logs, logs),
securityAudit: Object.assign(securityAudit, securityAudit),
monitoring: Object.assign(monitoring, monitoring),
}

export default admin