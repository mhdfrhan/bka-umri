import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\PengaturanController::toggleRead
 * @see app/Http/Controllers/Admin/PengaturanController.php:168
 * @route '/admin/settings/inbox/{id}/toggle-read'
 */
export const toggleRead = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: toggleRead.url(args, options),
    method: 'post',
})

toggleRead.definition = {
    methods: ["post"],
    url: '/admin/settings/inbox/{id}/toggle-read',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\PengaturanController::toggleRead
 * @see app/Http/Controllers/Admin/PengaturanController.php:168
 * @route '/admin/settings/inbox/{id}/toggle-read'
 */
toggleRead.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    id: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        id: args.id,
                }

    return toggleRead.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\PengaturanController::toggleRead
 * @see app/Http/Controllers/Admin/PengaturanController.php:168
 * @route '/admin/settings/inbox/{id}/toggle-read'
 */
toggleRead.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: toggleRead.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\PengaturanController::toggleRead
 * @see app/Http/Controllers/Admin/PengaturanController.php:168
 * @route '/admin/settings/inbox/{id}/toggle-read'
 */
    const toggleReadForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: toggleRead.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\PengaturanController::toggleRead
 * @see app/Http/Controllers/Admin/PengaturanController.php:168
 * @route '/admin/settings/inbox/{id}/toggle-read'
 */
        toggleReadForm.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: toggleRead.url(args, options),
            method: 'post',
        })
    
    toggleRead.form = toggleReadForm
/**
* @see \App\Http\Controllers\Admin\PengaturanController::destroy
 * @see app/Http/Controllers/Admin/PengaturanController.php:184
 * @route '/admin/settings/inbox/{id}'
 */
export const destroy = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/settings/inbox/{id}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Admin\PengaturanController::destroy
 * @see app/Http/Controllers/Admin/PengaturanController.php:184
 * @route '/admin/settings/inbox/{id}'
 */
destroy.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    id: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        id: args.id,
                }

    return destroy.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\PengaturanController::destroy
 * @see app/Http/Controllers/Admin/PengaturanController.php:184
 * @route '/admin/settings/inbox/{id}'
 */
destroy.delete = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Admin\PengaturanController::destroy
 * @see app/Http/Controllers/Admin/PengaturanController.php:184
 * @route '/admin/settings/inbox/{id}'
 */
    const destroyForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\PengaturanController::destroy
 * @see app/Http/Controllers/Admin/PengaturanController.php:184
 * @route '/admin/settings/inbox/{id}'
 */
        destroyForm.delete = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const inbox = {
    toggleRead: Object.assign(toggleRead, toggleRead),
destroy: Object.assign(destroy, destroy),
}

export default inbox