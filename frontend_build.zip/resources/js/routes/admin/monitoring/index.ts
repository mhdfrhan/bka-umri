import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\MonitoringController::index
 * @see app/Http/Controllers/Admin/MonitoringController.php:18
 * @route '/admin/monitoring'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/monitoring',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\MonitoringController::index
 * @see app/Http/Controllers/Admin/MonitoringController.php:18
 * @route '/admin/monitoring'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\MonitoringController::index
 * @see app/Http/Controllers/Admin/MonitoringController.php:18
 * @route '/admin/monitoring'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\MonitoringController::index
 * @see app/Http/Controllers/Admin/MonitoringController.php:18
 * @route '/admin/monitoring'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\MonitoringController::index
 * @see app/Http/Controllers/Admin/MonitoringController.php:18
 * @route '/admin/monitoring'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\MonitoringController::index
 * @see app/Http/Controllers/Admin/MonitoringController.php:18
 * @route '/admin/monitoring'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\MonitoringController::index
 * @see app/Http/Controllers/Admin/MonitoringController.php:18
 * @route '/admin/monitoring'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Admin\MonitoringController::cleanup
 * @see app/Http/Controllers/Admin/MonitoringController.php:106
 * @route '/admin/monitoring/cleanup'
 */
export const cleanup = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: cleanup.url(options),
    method: 'post',
})

cleanup.definition = {
    methods: ["post"],
    url: '/admin/monitoring/cleanup',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\MonitoringController::cleanup
 * @see app/Http/Controllers/Admin/MonitoringController.php:106
 * @route '/admin/monitoring/cleanup'
 */
cleanup.url = (options?: RouteQueryOptions) => {
    return cleanup.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\MonitoringController::cleanup
 * @see app/Http/Controllers/Admin/MonitoringController.php:106
 * @route '/admin/monitoring/cleanup'
 */
cleanup.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: cleanup.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\MonitoringController::cleanup
 * @see app/Http/Controllers/Admin/MonitoringController.php:106
 * @route '/admin/monitoring/cleanup'
 */
    const cleanupForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: cleanup.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\MonitoringController::cleanup
 * @see app/Http/Controllers/Admin/MonitoringController.php:106
 * @route '/admin/monitoring/cleanup'
 */
        cleanupForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: cleanup.url(options),
            method: 'post',
        })
    
    cleanup.form = cleanupForm
/**
* @see \App\Http\Controllers\Admin\MonitoringController::apiStats
 * @see app/Http/Controllers/Admin/MonitoringController.php:95
 * @route '/admin/monitoring/api/stats'
 */
export const apiStats = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: apiStats.url(options),
    method: 'get',
})

apiStats.definition = {
    methods: ["get","head"],
    url: '/admin/monitoring/api/stats',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\MonitoringController::apiStats
 * @see app/Http/Controllers/Admin/MonitoringController.php:95
 * @route '/admin/monitoring/api/stats'
 */
apiStats.url = (options?: RouteQueryOptions) => {
    return apiStats.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\MonitoringController::apiStats
 * @see app/Http/Controllers/Admin/MonitoringController.php:95
 * @route '/admin/monitoring/api/stats'
 */
apiStats.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: apiStats.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\MonitoringController::apiStats
 * @see app/Http/Controllers/Admin/MonitoringController.php:95
 * @route '/admin/monitoring/api/stats'
 */
apiStats.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: apiStats.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\MonitoringController::apiStats
 * @see app/Http/Controllers/Admin/MonitoringController.php:95
 * @route '/admin/monitoring/api/stats'
 */
    const apiStatsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: apiStats.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\MonitoringController::apiStats
 * @see app/Http/Controllers/Admin/MonitoringController.php:95
 * @route '/admin/monitoring/api/stats'
 */
        apiStatsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: apiStats.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\MonitoringController::apiStats
 * @see app/Http/Controllers/Admin/MonitoringController.php:95
 * @route '/admin/monitoring/api/stats'
 */
        apiStatsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: apiStats.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    apiStats.form = apiStatsForm
const monitoring = {
    index: Object.assign(index, index),
cleanup: Object.assign(cleanup, cleanup),
apiStats: Object.assign(apiStats, apiStats),
}

export default monitoring