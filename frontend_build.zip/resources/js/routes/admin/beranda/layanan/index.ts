import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\BerandaController::update
 * @see app/Http/Controllers/Admin/BerandaController.php:301
 * @route '/admin/beranda/layanan'
 */
export const update = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/admin/beranda/layanan',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Admin\BerandaController::update
 * @see app/Http/Controllers/Admin/BerandaController.php:301
 * @route '/admin/beranda/layanan'
 */
update.url = (options?: RouteQueryOptions) => {
    return update.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\BerandaController::update
 * @see app/Http/Controllers/Admin/BerandaController.php:301
 * @route '/admin/beranda/layanan'
 */
update.put = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Admin\BerandaController::update
 * @see app/Http/Controllers/Admin/BerandaController.php:301
 * @route '/admin/beranda/layanan'
 */
    const updateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\BerandaController::update
 * @see app/Http/Controllers/Admin/BerandaController.php:301
 * @route '/admin/beranda/layanan'
 */
        updateForm.put = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
const layanan = {
    update: Object.assign(update, update),
}

export default layanan