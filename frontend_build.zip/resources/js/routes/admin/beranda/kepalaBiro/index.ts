import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\BerandaController::update
 * @see app/Http/Controllers/Admin/BerandaController.php:221
 * @route '/admin/beranda/kepala-biro'
 */
export const update = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/admin/beranda/kepala-biro',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Admin\BerandaController::update
 * @see app/Http/Controllers/Admin/BerandaController.php:221
 * @route '/admin/beranda/kepala-biro'
 */
update.url = (options?: RouteQueryOptions) => {
    return update.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\BerandaController::update
 * @see app/Http/Controllers/Admin/BerandaController.php:221
 * @route '/admin/beranda/kepala-biro'
 */
update.put = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Admin\BerandaController::update
 * @see app/Http/Controllers/Admin/BerandaController.php:221
 * @route '/admin/beranda/kepala-biro'
 */
    const updateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\BerandaController::update
 * @see app/Http/Controllers/Admin/BerandaController.php:221
 * @route '/admin/beranda/kepala-biro'
 */
        updateForm.put = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
const kepalaBiro = {
    update: Object.assign(update, update),
}

export default kepalaBiro