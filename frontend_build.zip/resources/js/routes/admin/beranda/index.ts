import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
import banner from './banner'
import kepalaBiro from './kepalaBiro'
import statistik from './statistik'
import layanan from './layanan'
/**
* @see \App\Http\Controllers\Admin\BerandaController::edit
 * @see app/Http/Controllers/Admin/BerandaController.php:23
 * @route '/admin/beranda'
 */
export const edit = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/admin/beranda',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\BerandaController::edit
 * @see app/Http/Controllers/Admin/BerandaController.php:23
 * @route '/admin/beranda'
 */
edit.url = (options?: RouteQueryOptions) => {
    return edit.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\BerandaController::edit
 * @see app/Http/Controllers/Admin/BerandaController.php:23
 * @route '/admin/beranda'
 */
edit.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\BerandaController::edit
 * @see app/Http/Controllers/Admin/BerandaController.php:23
 * @route '/admin/beranda'
 */
edit.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\BerandaController::edit
 * @see app/Http/Controllers/Admin/BerandaController.php:23
 * @route '/admin/beranda'
 */
    const editForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\BerandaController::edit
 * @see app/Http/Controllers/Admin/BerandaController.php:23
 * @route '/admin/beranda'
 */
        editForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\BerandaController::edit
 * @see app/Http/Controllers/Admin/BerandaController.php:23
 * @route '/admin/beranda'
 */
        editForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
const beranda = {
    edit: Object.assign(edit, edit),
banner: Object.assign(banner, banner),
kepalaBiro: Object.assign(kepalaBiro, kepalaBiro),
statistik: Object.assign(statistik, statistik),
layanan: Object.assign(layanan, layanan),
}

export default beranda