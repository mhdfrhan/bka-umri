import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\ProfilController::edit
 * @see app/Http/Controllers/Admin/ProfilController.php:61
 * @route '/admin/profil/visi-misi'
 */
export const edit = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/admin/profil/visi-misi',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\ProfilController::edit
 * @see app/Http/Controllers/Admin/ProfilController.php:61
 * @route '/admin/profil/visi-misi'
 */
edit.url = (options?: RouteQueryOptions) => {
    return edit.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\ProfilController::edit
 * @see app/Http/Controllers/Admin/ProfilController.php:61
 * @route '/admin/profil/visi-misi'
 */
edit.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\ProfilController::edit
 * @see app/Http/Controllers/Admin/ProfilController.php:61
 * @route '/admin/profil/visi-misi'
 */
edit.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\ProfilController::edit
 * @see app/Http/Controllers/Admin/ProfilController.php:61
 * @route '/admin/profil/visi-misi'
 */
    const editForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\ProfilController::edit
 * @see app/Http/Controllers/Admin/ProfilController.php:61
 * @route '/admin/profil/visi-misi'
 */
        editForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\ProfilController::edit
 * @see app/Http/Controllers/Admin/ProfilController.php:61
 * @route '/admin/profil/visi-misi'
 */
        editForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\Admin\ProfilController::update
 * @see app/Http/Controllers/Admin/ProfilController.php:82
 * @route '/admin/profil/visi-misi'
 */
export const update = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/admin/profil/visi-misi',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Admin\ProfilController::update
 * @see app/Http/Controllers/Admin/ProfilController.php:82
 * @route '/admin/profil/visi-misi'
 */
update.url = (options?: RouteQueryOptions) => {
    return update.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\ProfilController::update
 * @see app/Http/Controllers/Admin/ProfilController.php:82
 * @route '/admin/profil/visi-misi'
 */
update.put = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Admin\ProfilController::update
 * @see app/Http/Controllers/Admin/ProfilController.php:82
 * @route '/admin/profil/visi-misi'
 */
    const updateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\ProfilController::update
 * @see app/Http/Controllers/Admin/ProfilController.php:82
 * @route '/admin/profil/visi-misi'
 */
        updateForm.put = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
const visiMisi = {
    edit: Object.assign(edit, edit),
update: Object.assign(update, update),
}

export default visiMisi