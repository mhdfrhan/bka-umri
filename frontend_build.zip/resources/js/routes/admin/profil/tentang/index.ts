import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\ProfilController::edit
 * @see app/Http/Controllers/Admin/ProfilController.php:23
 * @route '/admin/profil/tentang'
 */
export const edit = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/admin/profil/tentang',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\ProfilController::edit
 * @see app/Http/Controllers/Admin/ProfilController.php:23
 * @route '/admin/profil/tentang'
 */
edit.url = (options?: RouteQueryOptions) => {
    return edit.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\ProfilController::edit
 * @see app/Http/Controllers/Admin/ProfilController.php:23
 * @route '/admin/profil/tentang'
 */
edit.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\ProfilController::edit
 * @see app/Http/Controllers/Admin/ProfilController.php:23
 * @route '/admin/profil/tentang'
 */
edit.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\ProfilController::edit
 * @see app/Http/Controllers/Admin/ProfilController.php:23
 * @route '/admin/profil/tentang'
 */
    const editForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\ProfilController::edit
 * @see app/Http/Controllers/Admin/ProfilController.php:23
 * @route '/admin/profil/tentang'
 */
        editForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\ProfilController::edit
 * @see app/Http/Controllers/Admin/ProfilController.php:23
 * @route '/admin/profil/tentang'
 */
        editForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\Admin\ProfilController::update
 * @see app/Http/Controllers/Admin/ProfilController.php:41
 * @route '/admin/profil/tentang'
 */
export const update = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/admin/profil/tentang',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Admin\ProfilController::update
 * @see app/Http/Controllers/Admin/ProfilController.php:41
 * @route '/admin/profil/tentang'
 */
update.url = (options?: RouteQueryOptions) => {
    return update.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\ProfilController::update
 * @see app/Http/Controllers/Admin/ProfilController.php:41
 * @route '/admin/profil/tentang'
 */
update.put = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Admin\ProfilController::update
 * @see app/Http/Controllers/Admin/ProfilController.php:41
 * @route '/admin/profil/tentang'
 */
    const updateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\ProfilController::update
 * @see app/Http/Controllers/Admin/ProfilController.php:41
 * @route '/admin/profil/tentang'
 */
        updateForm.put = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
const tentang = {
    edit: Object.assign(edit, edit),
update: Object.assign(update, update),
}

export default tentang