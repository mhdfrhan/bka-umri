import tentang from './tentang'
import visiMisi from './visiMisi'
import struktur from './struktur'
const profil = {
    tentang: Object.assign(tentang, tentang),
visiMisi: Object.assign(visiMisi, visiMisi),
struktur: Object.assign(struktur, struktur),
}

export default profil