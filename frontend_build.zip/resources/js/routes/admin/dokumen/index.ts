import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
import kategori from './kategori'
import berkas from './berkas'
/**
* @see \App\Http\Controllers\Admin\DokumenController::index
 * @see app/Http/Controllers/Admin/DokumenController.php:18
 * @route '/admin/dokumen'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/dokumen',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\DokumenController::index
 * @see app/Http/Controllers/Admin/DokumenController.php:18
 * @route '/admin/dokumen'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\DokumenController::index
 * @see app/Http/Controllers/Admin/DokumenController.php:18
 * @route '/admin/dokumen'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\DokumenController::index
 * @see app/Http/Controllers/Admin/DokumenController.php:18
 * @route '/admin/dokumen'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\DokumenController::index
 * @see app/Http/Controllers/Admin/DokumenController.php:18
 * @route '/admin/dokumen'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\DokumenController::index
 * @see app/Http/Controllers/Admin/DokumenController.php:18
 * @route '/admin/dokumen'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\DokumenController::index
 * @see app/Http/Controllers/Admin/DokumenController.php:18
 * @route '/admin/dokumen'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
const dokumen = {
    index: Object.assign(index, index),
kategori: Object.assign(kategori, kategori),
berkas: Object.assign(berkas, berkas),
}

export default dokumen