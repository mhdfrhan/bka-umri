import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\DokumenController::reorder
 * @see app/Http/Controllers/Admin/DokumenController.php:185
 * @route '/admin/dokumen/berkas/reorder'
 */
export const reorder = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reorder.url(options),
    method: 'post',
})

reorder.definition = {
    methods: ["post"],
    url: '/admin/dokumen/berkas/reorder',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\DokumenController::reorder
 * @see app/Http/Controllers/Admin/DokumenController.php:185
 * @route '/admin/dokumen/berkas/reorder'
 */
reorder.url = (options?: RouteQueryOptions) => {
    return reorder.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\DokumenController::reorder
 * @see app/Http/Controllers/Admin/DokumenController.php:185
 * @route '/admin/dokumen/berkas/reorder'
 */
reorder.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reorder.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\DokumenController::reorder
 * @see app/Http/Controllers/Admin/DokumenController.php:185
 * @route '/admin/dokumen/berkas/reorder'
 */
    const reorderForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: reorder.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\DokumenController::reorder
 * @see app/Http/Controllers/Admin/DokumenController.php:185
 * @route '/admin/dokumen/berkas/reorder'
 */
        reorderForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: reorder.url(options),
            method: 'post',
        })
    
    reorder.form = reorderForm
/**
* @see \App\Http\Controllers\Admin\DokumenController::reorderUnified
 * @see app/Http/Controllers/Admin/DokumenController.php:204
 * @route '/admin/dokumen/berkas/reorder-unified'
 */
export const reorderUnified = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reorderUnified.url(options),
    method: 'post',
})

reorderUnified.definition = {
    methods: ["post"],
    url: '/admin/dokumen/berkas/reorder-unified',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\DokumenController::reorderUnified
 * @see app/Http/Controllers/Admin/DokumenController.php:204
 * @route '/admin/dokumen/berkas/reorder-unified'
 */
reorderUnified.url = (options?: RouteQueryOptions) => {
    return reorderUnified.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\DokumenController::reorderUnified
 * @see app/Http/Controllers/Admin/DokumenController.php:204
 * @route '/admin/dokumen/berkas/reorder-unified'
 */
reorderUnified.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reorderUnified.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\DokumenController::reorderUnified
 * @see app/Http/Controllers/Admin/DokumenController.php:204
 * @route '/admin/dokumen/berkas/reorder-unified'
 */
    const reorderUnifiedForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: reorderUnified.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\DokumenController::reorderUnified
 * @see app/Http/Controllers/Admin/DokumenController.php:204
 * @route '/admin/dokumen/berkas/reorder-unified'
 */
        reorderUnifiedForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: reorderUnified.url(options),
            method: 'post',
        })
    
    reorderUnified.form = reorderUnifiedForm
/**
* @see \App\Http\Controllers\Admin\DokumenController::restore
 * @see app/Http/Controllers/Admin/DokumenController.php:444
 * @route '/admin/dokumen/berkas/{id}/restore'
 */
export const restore = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: restore.url(args, options),
    method: 'post',
})

restore.definition = {
    methods: ["post"],
    url: '/admin/dokumen/berkas/{id}/restore',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\DokumenController::restore
 * @see app/Http/Controllers/Admin/DokumenController.php:444
 * @route '/admin/dokumen/berkas/{id}/restore'
 */
restore.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    id: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        id: args.id,
                }

    return restore.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\DokumenController::restore
 * @see app/Http/Controllers/Admin/DokumenController.php:444
 * @route '/admin/dokumen/berkas/{id}/restore'
 */
restore.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: restore.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\DokumenController::restore
 * @see app/Http/Controllers/Admin/DokumenController.php:444
 * @route '/admin/dokumen/berkas/{id}/restore'
 */
    const restoreForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: restore.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\DokumenController::restore
 * @see app/Http/Controllers/Admin/DokumenController.php:444
 * @route '/admin/dokumen/berkas/{id}/restore'
 */
        restoreForm.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: restore.url(args, options),
            method: 'post',
        })
    
    restore.form = restoreForm
/**
* @see \App\Http\Controllers\Admin\DokumenController::store
 * @see app/Http/Controllers/Admin/DokumenController.php:231
 * @route '/admin/dokumen/berkas'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/dokumen/berkas',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\DokumenController::store
 * @see app/Http/Controllers/Admin/DokumenController.php:231
 * @route '/admin/dokumen/berkas'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\DokumenController::store
 * @see app/Http/Controllers/Admin/DokumenController.php:231
 * @route '/admin/dokumen/berkas'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\DokumenController::store
 * @see app/Http/Controllers/Admin/DokumenController.php:231
 * @route '/admin/dokumen/berkas'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\DokumenController::store
 * @see app/Http/Controllers/Admin/DokumenController.php:231
 * @route '/admin/dokumen/berkas'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Admin\DokumenController::storeMultiple
 * @see app/Http/Controllers/Admin/DokumenController.php:303
 * @route '/admin/dokumen/berkas/multiple'
 */
export const storeMultiple = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeMultiple.url(options),
    method: 'post',
})

storeMultiple.definition = {
    methods: ["post"],
    url: '/admin/dokumen/berkas/multiple',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\DokumenController::storeMultiple
 * @see app/Http/Controllers/Admin/DokumenController.php:303
 * @route '/admin/dokumen/berkas/multiple'
 */
storeMultiple.url = (options?: RouteQueryOptions) => {
    return storeMultiple.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\DokumenController::storeMultiple
 * @see app/Http/Controllers/Admin/DokumenController.php:303
 * @route '/admin/dokumen/berkas/multiple'
 */
storeMultiple.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeMultiple.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\DokumenController::storeMultiple
 * @see app/Http/Controllers/Admin/DokumenController.php:303
 * @route '/admin/dokumen/berkas/multiple'
 */
    const storeMultipleForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeMultiple.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\DokumenController::storeMultiple
 * @see app/Http/Controllers/Admin/DokumenController.php:303
 * @route '/admin/dokumen/berkas/multiple'
 */
        storeMultipleForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeMultiple.url(options),
            method: 'post',
        })
    
    storeMultiple.form = storeMultipleForm
/**
* @see \App\Http\Controllers\Admin\DokumenController::update
 * @see app/Http/Controllers/Admin/DokumenController.php:355
 * @route '/admin/dokumen/berkas/{id}'
 */
export const update = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/admin/dokumen/berkas/{id}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Admin\DokumenController::update
 * @see app/Http/Controllers/Admin/DokumenController.php:355
 * @route '/admin/dokumen/berkas/{id}'
 */
update.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    id: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        id: args.id,
                }

    return update.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\DokumenController::update
 * @see app/Http/Controllers/Admin/DokumenController.php:355
 * @route '/admin/dokumen/berkas/{id}'
 */
update.put = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Admin\DokumenController::update
 * @see app/Http/Controllers/Admin/DokumenController.php:355
 * @route '/admin/dokumen/berkas/{id}'
 */
    const updateForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\DokumenController::update
 * @see app/Http/Controllers/Admin/DokumenController.php:355
 * @route '/admin/dokumen/berkas/{id}'
 */
        updateForm.put = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Admin\DokumenController::destroy
 * @see app/Http/Controllers/Admin/DokumenController.php:423
 * @route '/admin/dokumen/berkas/{id}'
 */
export const destroy = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/dokumen/berkas/{id}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Admin\DokumenController::destroy
 * @see app/Http/Controllers/Admin/DokumenController.php:423
 * @route '/admin/dokumen/berkas/{id}'
 */
destroy.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    id: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        id: args.id,
                }

    return destroy.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\DokumenController::destroy
 * @see app/Http/Controllers/Admin/DokumenController.php:423
 * @route '/admin/dokumen/berkas/{id}'
 */
destroy.delete = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Admin\DokumenController::destroy
 * @see app/Http/Controllers/Admin/DokumenController.php:423
 * @route '/admin/dokumen/berkas/{id}'
 */
    const destroyForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\DokumenController::destroy
 * @see app/Http/Controllers/Admin/DokumenController.php:423
 * @route '/admin/dokumen/berkas/{id}'
 */
        destroyForm.delete = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const berkas = {
    reorder: Object.assign(reorder, reorder),
reorderUnified: Object.assign(reorderUnified, reorderUnified),
restore: Object.assign(restore, restore),
store: Object.assign(store, store),
storeMultiple: Object.assign(storeMultiple, storeMultiple),
update: Object.assign(update, update),
destroy: Object.assign(destroy, destroy),
}

export default berkas