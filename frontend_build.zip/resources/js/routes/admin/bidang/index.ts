import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\BidangController::reorder
 * @see app/Http/Controllers/Admin/BidangController.php:430
 * @route '/admin/bidang/reorder'
 */
export const reorder = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reorder.url(options),
    method: 'post',
})

reorder.definition = {
    methods: ["post"],
    url: '/admin/bidang/reorder',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\BidangController::reorder
 * @see app/Http/Controllers/Admin/BidangController.php:430
 * @route '/admin/bidang/reorder'
 */
reorder.url = (options?: RouteQueryOptions) => {
    return reorder.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\BidangController::reorder
 * @see app/Http/Controllers/Admin/BidangController.php:430
 * @route '/admin/bidang/reorder'
 */
reorder.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reorder.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\BidangController::reorder
 * @see app/Http/Controllers/Admin/BidangController.php:430
 * @route '/admin/bidang/reorder'
 */
    const reorderForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: reorder.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\BidangController::reorder
 * @see app/Http/Controllers/Admin/BidangController.php:430
 * @route '/admin/bidang/reorder'
 */
        reorderForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: reorder.url(options),
            method: 'post',
        })
    
    reorder.form = reorderForm
/**
* @see \App\Http\Controllers\Admin\BidangController::index
 * @see app/Http/Controllers/Admin/BidangController.php:21
 * @route '/admin/bidang'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/bidang',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\BidangController::index
 * @see app/Http/Controllers/Admin/BidangController.php:21
 * @route '/admin/bidang'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\BidangController::index
 * @see app/Http/Controllers/Admin/BidangController.php:21
 * @route '/admin/bidang'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\BidangController::index
 * @see app/Http/Controllers/Admin/BidangController.php:21
 * @route '/admin/bidang'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\BidangController::index
 * @see app/Http/Controllers/Admin/BidangController.php:21
 * @route '/admin/bidang'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\BidangController::index
 * @see app/Http/Controllers/Admin/BidangController.php:21
 * @route '/admin/bidang'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\BidangController::index
 * @see app/Http/Controllers/Admin/BidangController.php:21
 * @route '/admin/bidang'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Admin\BidangController::create
 * @see app/Http/Controllers/Admin/BidangController.php:69
 * @route '/admin/bidang/create'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/admin/bidang/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\BidangController::create
 * @see app/Http/Controllers/Admin/BidangController.php:69
 * @route '/admin/bidang/create'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\BidangController::create
 * @see app/Http/Controllers/Admin/BidangController.php:69
 * @route '/admin/bidang/create'
 */
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\BidangController::create
 * @see app/Http/Controllers/Admin/BidangController.php:69
 * @route '/admin/bidang/create'
 */
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\BidangController::create
 * @see app/Http/Controllers/Admin/BidangController.php:69
 * @route '/admin/bidang/create'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\BidangController::create
 * @see app/Http/Controllers/Admin/BidangController.php:69
 * @route '/admin/bidang/create'
 */
        createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\BidangController::create
 * @see app/Http/Controllers/Admin/BidangController.php:69
 * @route '/admin/bidang/create'
 */
        createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\Admin\BidangController::store
 * @see app/Http/Controllers/Admin/BidangController.php:77
 * @route '/admin/bidang'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/bidang',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\BidangController::store
 * @see app/Http/Controllers/Admin/BidangController.php:77
 * @route '/admin/bidang'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\BidangController::store
 * @see app/Http/Controllers/Admin/BidangController.php:77
 * @route '/admin/bidang'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\BidangController::store
 * @see app/Http/Controllers/Admin/BidangController.php:77
 * @route '/admin/bidang'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\BidangController::store
 * @see app/Http/Controllers/Admin/BidangController.php:77
 * @route '/admin/bidang'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Admin\BidangController::show
 * @see app/Http/Controllers/Admin/BidangController.php:0
 * @route '/admin/bidang/{bidang}'
 */
export const show = (args: { bidang: string | number } | [bidang: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/admin/bidang/{bidang}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\BidangController::show
 * @see app/Http/Controllers/Admin/BidangController.php:0
 * @route '/admin/bidang/{bidang}'
 */
show.url = (args: { bidang: string | number } | [bidang: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { bidang: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    bidang: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        bidang: args.bidang,
                }

    return show.definition.url
            .replace('{bidang}', parsedArgs.bidang.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\BidangController::show
 * @see app/Http/Controllers/Admin/BidangController.php:0
 * @route '/admin/bidang/{bidang}'
 */
show.get = (args: { bidang: string | number } | [bidang: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\BidangController::show
 * @see app/Http/Controllers/Admin/BidangController.php:0
 * @route '/admin/bidang/{bidang}'
 */
show.head = (args: { bidang: string | number } | [bidang: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\BidangController::show
 * @see app/Http/Controllers/Admin/BidangController.php:0
 * @route '/admin/bidang/{bidang}'
 */
    const showForm = (args: { bidang: string | number } | [bidang: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\BidangController::show
 * @see app/Http/Controllers/Admin/BidangController.php:0
 * @route '/admin/bidang/{bidang}'
 */
        showForm.get = (args: { bidang: string | number } | [bidang: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\BidangController::show
 * @see app/Http/Controllers/Admin/BidangController.php:0
 * @route '/admin/bidang/{bidang}'
 */
        showForm.head = (args: { bidang: string | number } | [bidang: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Admin\BidangController::edit
 * @see app/Http/Controllers/Admin/BidangController.php:205
 * @route '/admin/bidang/{bidang}/edit'
 */
export const edit = (args: { bidang: string | number } | [bidang: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/admin/bidang/{bidang}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\BidangController::edit
 * @see app/Http/Controllers/Admin/BidangController.php:205
 * @route '/admin/bidang/{bidang}/edit'
 */
edit.url = (args: { bidang: string | number } | [bidang: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { bidang: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    bidang: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        bidang: args.bidang,
                }

    return edit.definition.url
            .replace('{bidang}', parsedArgs.bidang.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\BidangController::edit
 * @see app/Http/Controllers/Admin/BidangController.php:205
 * @route '/admin/bidang/{bidang}/edit'
 */
edit.get = (args: { bidang: string | number } | [bidang: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\BidangController::edit
 * @see app/Http/Controllers/Admin/BidangController.php:205
 * @route '/admin/bidang/{bidang}/edit'
 */
edit.head = (args: { bidang: string | number } | [bidang: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\BidangController::edit
 * @see app/Http/Controllers/Admin/BidangController.php:205
 * @route '/admin/bidang/{bidang}/edit'
 */
    const editForm = (args: { bidang: string | number } | [bidang: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\BidangController::edit
 * @see app/Http/Controllers/Admin/BidangController.php:205
 * @route '/admin/bidang/{bidang}/edit'
 */
        editForm.get = (args: { bidang: string | number } | [bidang: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\BidangController::edit
 * @see app/Http/Controllers/Admin/BidangController.php:205
 * @route '/admin/bidang/{bidang}/edit'
 */
        editForm.head = (args: { bidang: string | number } | [bidang: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\Admin\BidangController::update
 * @see app/Http/Controllers/Admin/BidangController.php:253
 * @route '/admin/bidang/{bidang}'
 */
export const update = (args: { bidang: string | number } | [bidang: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/admin/bidang/{bidang}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\Admin\BidangController::update
 * @see app/Http/Controllers/Admin/BidangController.php:253
 * @route '/admin/bidang/{bidang}'
 */
update.url = (args: { bidang: string | number } | [bidang: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { bidang: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    bidang: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        bidang: args.bidang,
                }

    return update.definition.url
            .replace('{bidang}', parsedArgs.bidang.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\BidangController::update
 * @see app/Http/Controllers/Admin/BidangController.php:253
 * @route '/admin/bidang/{bidang}'
 */
update.put = (args: { bidang: string | number } | [bidang: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\Admin\BidangController::update
 * @see app/Http/Controllers/Admin/BidangController.php:253
 * @route '/admin/bidang/{bidang}'
 */
update.patch = (args: { bidang: string | number } | [bidang: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Admin\BidangController::update
 * @see app/Http/Controllers/Admin/BidangController.php:253
 * @route '/admin/bidang/{bidang}'
 */
    const updateForm = (args: { bidang: string | number } | [bidang: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\BidangController::update
 * @see app/Http/Controllers/Admin/BidangController.php:253
 * @route '/admin/bidang/{bidang}'
 */
        updateForm.put = (args: { bidang: string | number } | [bidang: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\Admin\BidangController::update
 * @see app/Http/Controllers/Admin/BidangController.php:253
 * @route '/admin/bidang/{bidang}'
 */
        updateForm.patch = (args: { bidang: string | number } | [bidang: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Admin\BidangController::destroy
 * @see app/Http/Controllers/Admin/BidangController.php:395
 * @route '/admin/bidang/{bidang}'
 */
export const destroy = (args: { bidang: string | number } | [bidang: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/bidang/{bidang}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Admin\BidangController::destroy
 * @see app/Http/Controllers/Admin/BidangController.php:395
 * @route '/admin/bidang/{bidang}'
 */
destroy.url = (args: { bidang: string | number } | [bidang: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { bidang: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    bidang: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        bidang: args.bidang,
                }

    return destroy.definition.url
            .replace('{bidang}', parsedArgs.bidang.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\BidangController::destroy
 * @see app/Http/Controllers/Admin/BidangController.php:395
 * @route '/admin/bidang/{bidang}'
 */
destroy.delete = (args: { bidang: string | number } | [bidang: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Admin\BidangController::destroy
 * @see app/Http/Controllers/Admin/BidangController.php:395
 * @route '/admin/bidang/{bidang}'
 */
    const destroyForm = (args: { bidang: string | number } | [bidang: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\BidangController::destroy
 * @see app/Http/Controllers/Admin/BidangController.php:395
 * @route '/admin/bidang/{bidang}'
 */
        destroyForm.delete = (args: { bidang: string | number } | [bidang: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const bidang = {
    reorder: Object.assign(reorder, reorder),
index: Object.assign(index, index),
create: Object.assign(create, create),
store: Object.assign(store, store),
show: Object.assign(show, show),
edit: Object.assign(edit, edit),
update: Object.assign(update, update),
destroy: Object.assign(destroy, destroy),
}

export default bidang