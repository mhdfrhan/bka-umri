import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\SecurityAuditController::index
 * @see app/Http/Controllers/Admin/SecurityAuditController.php:22
 * @route '/admin/security-audit'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/security-audit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\SecurityAuditController::index
 * @see app/Http/Controllers/Admin/SecurityAuditController.php:22
 * @route '/admin/security-audit'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\SecurityAuditController::index
 * @see app/Http/Controllers/Admin/SecurityAuditController.php:22
 * @route '/admin/security-audit'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\SecurityAuditController::index
 * @see app/Http/Controllers/Admin/SecurityAuditController.php:22
 * @route '/admin/security-audit'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\SecurityAuditController::index
 * @see app/Http/Controllers/Admin/SecurityAuditController.php:22
 * @route '/admin/security-audit'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\SecurityAuditController::index
 * @see app/Http/Controllers/Admin/SecurityAuditController.php:22
 * @route '/admin/security-audit'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\SecurityAuditController::index
 * @see app/Http/Controllers/Admin/SecurityAuditController.php:22
 * @route '/admin/security-audit'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Admin\SecurityAuditController::clearLogs
 * @see app/Http/Controllers/Admin/SecurityAuditController.php:95
 * @route '/admin/security-audit/logs'
 */
export const clearLogs = (options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: clearLogs.url(options),
    method: 'delete',
})

clearLogs.definition = {
    methods: ["delete"],
    url: '/admin/security-audit/logs',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Admin\SecurityAuditController::clearLogs
 * @see app/Http/Controllers/Admin/SecurityAuditController.php:95
 * @route '/admin/security-audit/logs'
 */
clearLogs.url = (options?: RouteQueryOptions) => {
    return clearLogs.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\SecurityAuditController::clearLogs
 * @see app/Http/Controllers/Admin/SecurityAuditController.php:95
 * @route '/admin/security-audit/logs'
 */
clearLogs.delete = (options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: clearLogs.url(options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Admin\SecurityAuditController::clearLogs
 * @see app/Http/Controllers/Admin/SecurityAuditController.php:95
 * @route '/admin/security-audit/logs'
 */
    const clearLogsForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: clearLogs.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\SecurityAuditController::clearLogs
 * @see app/Http/Controllers/Admin/SecurityAuditController.php:95
 * @route '/admin/security-audit/logs'
 */
        clearLogsForm.delete = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: clearLogs.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    clearLogs.form = clearLogsForm
/**
* @see \App\Http\Controllers\Admin\SecurityAuditController::terminateSession
 * @see app/Http/Controllers/Admin/SecurityAuditController.php:113
 * @route '/admin/security-audit/sessions/{id}'
 */
export const terminateSession = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: terminateSession.url(args, options),
    method: 'delete',
})

terminateSession.definition = {
    methods: ["delete"],
    url: '/admin/security-audit/sessions/{id}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Admin\SecurityAuditController::terminateSession
 * @see app/Http/Controllers/Admin/SecurityAuditController.php:113
 * @route '/admin/security-audit/sessions/{id}'
 */
terminateSession.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    id: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        id: args.id,
                }

    return terminateSession.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\SecurityAuditController::terminateSession
 * @see app/Http/Controllers/Admin/SecurityAuditController.php:113
 * @route '/admin/security-audit/sessions/{id}'
 */
terminateSession.delete = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: terminateSession.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Admin\SecurityAuditController::terminateSession
 * @see app/Http/Controllers/Admin/SecurityAuditController.php:113
 * @route '/admin/security-audit/sessions/{id}'
 */
    const terminateSessionForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: terminateSession.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\SecurityAuditController::terminateSession
 * @see app/Http/Controllers/Admin/SecurityAuditController.php:113
 * @route '/admin/security-audit/sessions/{id}'
 */
        terminateSessionForm.delete = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: terminateSession.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    terminateSession.form = terminateSessionForm
/**
* @see \App\Http\Controllers\Admin\SecurityAuditController::toggleBlacklist
 * @see app/Http/Controllers/Admin/SecurityAuditController.php:135
 * @route '/admin/security-audit/blacklist'
 */
export const toggleBlacklist = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: toggleBlacklist.url(options),
    method: 'post',
})

toggleBlacklist.definition = {
    methods: ["post"],
    url: '/admin/security-audit/blacklist',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\SecurityAuditController::toggleBlacklist
 * @see app/Http/Controllers/Admin/SecurityAuditController.php:135
 * @route '/admin/security-audit/blacklist'
 */
toggleBlacklist.url = (options?: RouteQueryOptions) => {
    return toggleBlacklist.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\SecurityAuditController::toggleBlacklist
 * @see app/Http/Controllers/Admin/SecurityAuditController.php:135
 * @route '/admin/security-audit/blacklist'
 */
toggleBlacklist.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: toggleBlacklist.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\SecurityAuditController::toggleBlacklist
 * @see app/Http/Controllers/Admin/SecurityAuditController.php:135
 * @route '/admin/security-audit/blacklist'
 */
    const toggleBlacklistForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: toggleBlacklist.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\SecurityAuditController::toggleBlacklist
 * @see app/Http/Controllers/Admin/SecurityAuditController.php:135
 * @route '/admin/security-audit/blacklist'
 */
        toggleBlacklistForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: toggleBlacklist.url(options),
            method: 'post',
        })
    
    toggleBlacklist.form = toggleBlacklistForm
const securityAudit = {
    index: Object.assign(index, index),
clearLogs: Object.assign(clearLogs, clearLogs),
terminateSession: Object.assign(terminateSession, terminateSession),
toggleBlacklist: Object.assign(toggleBlacklist, toggleBlacklist),
}

export default securityAudit