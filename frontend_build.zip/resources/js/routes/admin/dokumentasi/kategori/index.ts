import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\DokumentasiController::store
 * @see app/Http/Controllers/Admin/DokumentasiController.php:302
 * @route '/admin/dokumentasi/kategori'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/dokumentasi/kategori',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\DokumentasiController::store
 * @see app/Http/Controllers/Admin/DokumentasiController.php:302
 * @route '/admin/dokumentasi/kategori'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\DokumentasiController::store
 * @see app/Http/Controllers/Admin/DokumentasiController.php:302
 * @route '/admin/dokumentasi/kategori'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\DokumentasiController::store
 * @see app/Http/Controllers/Admin/DokumentasiController.php:302
 * @route '/admin/dokumentasi/kategori'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\DokumentasiController::store
 * @see app/Http/Controllers/Admin/DokumentasiController.php:302
 * @route '/admin/dokumentasi/kategori'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Admin\DokumentasiController::destroy
 * @see app/Http/Controllers/Admin/DokumentasiController.php:318
 * @route '/admin/dokumentasi/kategori/{id}'
 */
export const destroy = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/dokumentasi/kategori/{id}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Admin\DokumentasiController::destroy
 * @see app/Http/Controllers/Admin/DokumentasiController.php:318
 * @route '/admin/dokumentasi/kategori/{id}'
 */
destroy.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    id: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        id: args.id,
                }

    return destroy.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\DokumentasiController::destroy
 * @see app/Http/Controllers/Admin/DokumentasiController.php:318
 * @route '/admin/dokumentasi/kategori/{id}'
 */
destroy.delete = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Admin\DokumentasiController::destroy
 * @see app/Http/Controllers/Admin/DokumentasiController.php:318
 * @route '/admin/dokumentasi/kategori/{id}'
 */
    const destroyForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\DokumentasiController::destroy
 * @see app/Http/Controllers/Admin/DokumentasiController.php:318
 * @route '/admin/dokumentasi/kategori/{id}'
 */
        destroyForm.delete = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const kategori = {
    store: Object.assign(store, store),
destroy: Object.assign(destroy, destroy),
}

export default kategori