import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
import kategori from './kategori'
/**
* @see \App\Http\Controllers\Admin\DokumentasiController::restore
 * @see app/Http/Controllers/Admin/DokumentasiController.php:291
 * @route '/admin/dokumentasi/{id}/restore'
 */
export const restore = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: restore.url(args, options),
    method: 'post',
})

restore.definition = {
    methods: ["post"],
    url: '/admin/dokumentasi/{id}/restore',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\DokumentasiController::restore
 * @see app/Http/Controllers/Admin/DokumentasiController.php:291
 * @route '/admin/dokumentasi/{id}/restore'
 */
restore.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    id: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        id: args.id,
                }

    return restore.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\DokumentasiController::restore
 * @see app/Http/Controllers/Admin/DokumentasiController.php:291
 * @route '/admin/dokumentasi/{id}/restore'
 */
restore.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: restore.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\DokumentasiController::restore
 * @see app/Http/Controllers/Admin/DokumentasiController.php:291
 * @route '/admin/dokumentasi/{id}/restore'
 */
    const restoreForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: restore.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\DokumentasiController::restore
 * @see app/Http/Controllers/Admin/DokumentasiController.php:291
 * @route '/admin/dokumentasi/{id}/restore'
 */
        restoreForm.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: restore.url(args, options),
            method: 'post',
        })
    
    restore.form = restoreForm
/**
* @see \App\Http\Controllers\Admin\DokumentasiController::index
 * @see app/Http/Controllers/Admin/DokumentasiController.php:21
 * @route '/admin/dokumentasi'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/dokumentasi',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\DokumentasiController::index
 * @see app/Http/Controllers/Admin/DokumentasiController.php:21
 * @route '/admin/dokumentasi'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\DokumentasiController::index
 * @see app/Http/Controllers/Admin/DokumentasiController.php:21
 * @route '/admin/dokumentasi'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\DokumentasiController::index
 * @see app/Http/Controllers/Admin/DokumentasiController.php:21
 * @route '/admin/dokumentasi'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\DokumentasiController::index
 * @see app/Http/Controllers/Admin/DokumentasiController.php:21
 * @route '/admin/dokumentasi'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\DokumentasiController::index
 * @see app/Http/Controllers/Admin/DokumentasiController.php:21
 * @route '/admin/dokumentasi'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\DokumentasiController::index
 * @see app/Http/Controllers/Admin/DokumentasiController.php:21
 * @route '/admin/dokumentasi'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Admin\DokumentasiController::create
 * @see app/Http/Controllers/Admin/DokumentasiController.php:76
 * @route '/admin/dokumentasi/create'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/admin/dokumentasi/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\DokumentasiController::create
 * @see app/Http/Controllers/Admin/DokumentasiController.php:76
 * @route '/admin/dokumentasi/create'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\DokumentasiController::create
 * @see app/Http/Controllers/Admin/DokumentasiController.php:76
 * @route '/admin/dokumentasi/create'
 */
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\DokumentasiController::create
 * @see app/Http/Controllers/Admin/DokumentasiController.php:76
 * @route '/admin/dokumentasi/create'
 */
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\DokumentasiController::create
 * @see app/Http/Controllers/Admin/DokumentasiController.php:76
 * @route '/admin/dokumentasi/create'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\DokumentasiController::create
 * @see app/Http/Controllers/Admin/DokumentasiController.php:76
 * @route '/admin/dokumentasi/create'
 */
        createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\DokumentasiController::create
 * @see app/Http/Controllers/Admin/DokumentasiController.php:76
 * @route '/admin/dokumentasi/create'
 */
        createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\Admin\DokumentasiController::store
 * @see app/Http/Controllers/Admin/DokumentasiController.php:93
 * @route '/admin/dokumentasi'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/dokumentasi',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\DokumentasiController::store
 * @see app/Http/Controllers/Admin/DokumentasiController.php:93
 * @route '/admin/dokumentasi'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\DokumentasiController::store
 * @see app/Http/Controllers/Admin/DokumentasiController.php:93
 * @route '/admin/dokumentasi'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\DokumentasiController::store
 * @see app/Http/Controllers/Admin/DokumentasiController.php:93
 * @route '/admin/dokumentasi'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\DokumentasiController::store
 * @see app/Http/Controllers/Admin/DokumentasiController.php:93
 * @route '/admin/dokumentasi'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Admin\DokumentasiController::show
 * @see app/Http/Controllers/Admin/DokumentasiController.php:0
 * @route '/admin/dokumentasi/{dokumentasi}'
 */
export const show = (args: { dokumentasi: string | number } | [dokumentasi: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/admin/dokumentasi/{dokumentasi}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\DokumentasiController::show
 * @see app/Http/Controllers/Admin/DokumentasiController.php:0
 * @route '/admin/dokumentasi/{dokumentasi}'
 */
show.url = (args: { dokumentasi: string | number } | [dokumentasi: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { dokumentasi: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    dokumentasi: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        dokumentasi: args.dokumentasi,
                }

    return show.definition.url
            .replace('{dokumentasi}', parsedArgs.dokumentasi.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\DokumentasiController::show
 * @see app/Http/Controllers/Admin/DokumentasiController.php:0
 * @route '/admin/dokumentasi/{dokumentasi}'
 */
show.get = (args: { dokumentasi: string | number } | [dokumentasi: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\DokumentasiController::show
 * @see app/Http/Controllers/Admin/DokumentasiController.php:0
 * @route '/admin/dokumentasi/{dokumentasi}'
 */
show.head = (args: { dokumentasi: string | number } | [dokumentasi: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\DokumentasiController::show
 * @see app/Http/Controllers/Admin/DokumentasiController.php:0
 * @route '/admin/dokumentasi/{dokumentasi}'
 */
    const showForm = (args: { dokumentasi: string | number } | [dokumentasi: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\DokumentasiController::show
 * @see app/Http/Controllers/Admin/DokumentasiController.php:0
 * @route '/admin/dokumentasi/{dokumentasi}'
 */
        showForm.get = (args: { dokumentasi: string | number } | [dokumentasi: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\DokumentasiController::show
 * @see app/Http/Controllers/Admin/DokumentasiController.php:0
 * @route '/admin/dokumentasi/{dokumentasi}'
 */
        showForm.head = (args: { dokumentasi: string | number } | [dokumentasi: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Admin\DokumentasiController::edit
 * @see app/Http/Controllers/Admin/DokumentasiController.php:132
 * @route '/admin/dokumentasi/{dokumentasi}/edit'
 */
export const edit = (args: { dokumentasi: string | number } | [dokumentasi: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/admin/dokumentasi/{dokumentasi}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\DokumentasiController::edit
 * @see app/Http/Controllers/Admin/DokumentasiController.php:132
 * @route '/admin/dokumentasi/{dokumentasi}/edit'
 */
edit.url = (args: { dokumentasi: string | number } | [dokumentasi: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { dokumentasi: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    dokumentasi: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        dokumentasi: args.dokumentasi,
                }

    return edit.definition.url
            .replace('{dokumentasi}', parsedArgs.dokumentasi.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\DokumentasiController::edit
 * @see app/Http/Controllers/Admin/DokumentasiController.php:132
 * @route '/admin/dokumentasi/{dokumentasi}/edit'
 */
edit.get = (args: { dokumentasi: string | number } | [dokumentasi: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\DokumentasiController::edit
 * @see app/Http/Controllers/Admin/DokumentasiController.php:132
 * @route '/admin/dokumentasi/{dokumentasi}/edit'
 */
edit.head = (args: { dokumentasi: string | number } | [dokumentasi: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\DokumentasiController::edit
 * @see app/Http/Controllers/Admin/DokumentasiController.php:132
 * @route '/admin/dokumentasi/{dokumentasi}/edit'
 */
    const editForm = (args: { dokumentasi: string | number } | [dokumentasi: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\DokumentasiController::edit
 * @see app/Http/Controllers/Admin/DokumentasiController.php:132
 * @route '/admin/dokumentasi/{dokumentasi}/edit'
 */
        editForm.get = (args: { dokumentasi: string | number } | [dokumentasi: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\DokumentasiController::edit
 * @see app/Http/Controllers/Admin/DokumentasiController.php:132
 * @route '/admin/dokumentasi/{dokumentasi}/edit'
 */
        editForm.head = (args: { dokumentasi: string | number } | [dokumentasi: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\Admin\DokumentasiController::update
 * @see app/Http/Controllers/Admin/DokumentasiController.php:169
 * @route '/admin/dokumentasi/{dokumentasi}'
 */
export const update = (args: { dokumentasi: string | number } | [dokumentasi: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/admin/dokumentasi/{dokumentasi}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\Admin\DokumentasiController::update
 * @see app/Http/Controllers/Admin/DokumentasiController.php:169
 * @route '/admin/dokumentasi/{dokumentasi}'
 */
update.url = (args: { dokumentasi: string | number } | [dokumentasi: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { dokumentasi: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    dokumentasi: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        dokumentasi: args.dokumentasi,
                }

    return update.definition.url
            .replace('{dokumentasi}', parsedArgs.dokumentasi.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\DokumentasiController::update
 * @see app/Http/Controllers/Admin/DokumentasiController.php:169
 * @route '/admin/dokumentasi/{dokumentasi}'
 */
update.put = (args: { dokumentasi: string | number } | [dokumentasi: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\Admin\DokumentasiController::update
 * @see app/Http/Controllers/Admin/DokumentasiController.php:169
 * @route '/admin/dokumentasi/{dokumentasi}'
 */
update.patch = (args: { dokumentasi: string | number } | [dokumentasi: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Admin\DokumentasiController::update
 * @see app/Http/Controllers/Admin/DokumentasiController.php:169
 * @route '/admin/dokumentasi/{dokumentasi}'
 */
    const updateForm = (args: { dokumentasi: string | number } | [dokumentasi: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\DokumentasiController::update
 * @see app/Http/Controllers/Admin/DokumentasiController.php:169
 * @route '/admin/dokumentasi/{dokumentasi}'
 */
        updateForm.put = (args: { dokumentasi: string | number } | [dokumentasi: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\Admin\DokumentasiController::update
 * @see app/Http/Controllers/Admin/DokumentasiController.php:169
 * @route '/admin/dokumentasi/{dokumentasi}'
 */
        updateForm.patch = (args: { dokumentasi: string | number } | [dokumentasi: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Admin\DokumentasiController::destroy
 * @see app/Http/Controllers/Admin/DokumentasiController.php:264
 * @route '/admin/dokumentasi/{dokumentasi}'
 */
export const destroy = (args: { dokumentasi: string | number } | [dokumentasi: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/dokumentasi/{dokumentasi}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Admin\DokumentasiController::destroy
 * @see app/Http/Controllers/Admin/DokumentasiController.php:264
 * @route '/admin/dokumentasi/{dokumentasi}'
 */
destroy.url = (args: { dokumentasi: string | number } | [dokumentasi: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { dokumentasi: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    dokumentasi: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        dokumentasi: args.dokumentasi,
                }

    return destroy.definition.url
            .replace('{dokumentasi}', parsedArgs.dokumentasi.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\DokumentasiController::destroy
 * @see app/Http/Controllers/Admin/DokumentasiController.php:264
 * @route '/admin/dokumentasi/{dokumentasi}'
 */
destroy.delete = (args: { dokumentasi: string | number } | [dokumentasi: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Admin\DokumentasiController::destroy
 * @see app/Http/Controllers/Admin/DokumentasiController.php:264
 * @route '/admin/dokumentasi/{dokumentasi}'
 */
    const destroyForm = (args: { dokumentasi: string | number } | [dokumentasi: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\DokumentasiController::destroy
 * @see app/Http/Controllers/Admin/DokumentasiController.php:264
 * @route '/admin/dokumentasi/{dokumentasi}'
 */
        destroyForm.delete = (args: { dokumentasi: string | number } | [dokumentasi: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const dokumentasi = {
    kategori: Object.assign(kategori, kategori),
restore: Object.assign(restore, restore),
index: Object.assign(index, index),
create: Object.assign(create, create),
store: Object.assign(store, store),
show: Object.assign(show, show),
edit: Object.assign(edit, edit),
update: Object.assign(update, update),
destroy: Object.assign(destroy, destroy),
}

export default dokumentasi