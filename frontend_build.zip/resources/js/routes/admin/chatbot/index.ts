import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
import settings from './settings'
import monitoringBb077c from './monitoring'
import faqs from './faqs'
/**
* @see \App\Http\Controllers\Admin\ChatbotSettingController::index
 * @see app/Http/Controllers/Admin/ChatbotSettingController.php:19
 * @route '/admin/chatbot'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/chatbot',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\ChatbotSettingController::index
 * @see app/Http/Controllers/Admin/ChatbotSettingController.php:19
 * @route '/admin/chatbot'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\ChatbotSettingController::index
 * @see app/Http/Controllers/Admin/ChatbotSettingController.php:19
 * @route '/admin/chatbot'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\ChatbotSettingController::index
 * @see app/Http/Controllers/Admin/ChatbotSettingController.php:19
 * @route '/admin/chatbot'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\ChatbotSettingController::index
 * @see app/Http/Controllers/Admin/ChatbotSettingController.php:19
 * @route '/admin/chatbot'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\ChatbotSettingController::index
 * @see app/Http/Controllers/Admin/ChatbotSettingController.php:19
 * @route '/admin/chatbot'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\ChatbotSettingController::index
 * @see app/Http/Controllers/Admin/ChatbotSettingController.php:19
 * @route '/admin/chatbot'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Admin\ChatbotSettingController::test
 * @see app/Http/Controllers/Admin/ChatbotSettingController.php:98
 * @route '/admin/chatbot/test'
 */
export const test = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: test.url(options),
    method: 'post',
})

test.definition = {
    methods: ["post"],
    url: '/admin/chatbot/test',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\ChatbotSettingController::test
 * @see app/Http/Controllers/Admin/ChatbotSettingController.php:98
 * @route '/admin/chatbot/test'
 */
test.url = (options?: RouteQueryOptions) => {
    return test.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\ChatbotSettingController::test
 * @see app/Http/Controllers/Admin/ChatbotSettingController.php:98
 * @route '/admin/chatbot/test'
 */
test.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: test.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\ChatbotSettingController::test
 * @see app/Http/Controllers/Admin/ChatbotSettingController.php:98
 * @route '/admin/chatbot/test'
 */
    const testForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: test.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\ChatbotSettingController::test
 * @see app/Http/Controllers/Admin/ChatbotSettingController.php:98
 * @route '/admin/chatbot/test'
 */
        testForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: test.url(options),
            method: 'post',
        })
    
    test.form = testForm
/**
* @see \App\Http\Controllers\Admin\ChatbotMonitoringController::monitoring
 * @see app/Http/Controllers/Admin/ChatbotMonitoringController.php:19
 * @route '/admin/chatbot/monitoring'
 */
export const monitoring = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: monitoring.url(options),
    method: 'get',
})

monitoring.definition = {
    methods: ["get","head"],
    url: '/admin/chatbot/monitoring',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\ChatbotMonitoringController::monitoring
 * @see app/Http/Controllers/Admin/ChatbotMonitoringController.php:19
 * @route '/admin/chatbot/monitoring'
 */
monitoring.url = (options?: RouteQueryOptions) => {
    return monitoring.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\ChatbotMonitoringController::monitoring
 * @see app/Http/Controllers/Admin/ChatbotMonitoringController.php:19
 * @route '/admin/chatbot/monitoring'
 */
monitoring.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: monitoring.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\ChatbotMonitoringController::monitoring
 * @see app/Http/Controllers/Admin/ChatbotMonitoringController.php:19
 * @route '/admin/chatbot/monitoring'
 */
monitoring.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: monitoring.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\ChatbotMonitoringController::monitoring
 * @see app/Http/Controllers/Admin/ChatbotMonitoringController.php:19
 * @route '/admin/chatbot/monitoring'
 */
    const monitoringForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: monitoring.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\ChatbotMonitoringController::monitoring
 * @see app/Http/Controllers/Admin/ChatbotMonitoringController.php:19
 * @route '/admin/chatbot/monitoring'
 */
        monitoringForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: monitoring.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\ChatbotMonitoringController::monitoring
 * @see app/Http/Controllers/Admin/ChatbotMonitoringController.php:19
 * @route '/admin/chatbot/monitoring'
 */
        monitoringForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: monitoring.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    monitoring.form = monitoringForm
const chatbot = {
    index: Object.assign(index, index),
settings: Object.assign(settings, settings),
test: Object.assign(test, test),
monitoring: Object.assign(monitoring, monitoringBb077c),
faqs: Object.assign(faqs, faqs),
}

export default chatbot