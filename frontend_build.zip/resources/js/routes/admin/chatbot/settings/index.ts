import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\ChatbotSettingController::update
 * @see app/Http/Controllers/Admin/ChatbotSettingController.php:50
 * @route '/admin/chatbot/settings'
 */
export const update = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: update.url(options),
    method: 'post',
})

update.definition = {
    methods: ["post"],
    url: '/admin/chatbot/settings',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\ChatbotSettingController::update
 * @see app/Http/Controllers/Admin/ChatbotSettingController.php:50
 * @route '/admin/chatbot/settings'
 */
update.url = (options?: RouteQueryOptions) => {
    return update.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\ChatbotSettingController::update
 * @see app/Http/Controllers/Admin/ChatbotSettingController.php:50
 * @route '/admin/chatbot/settings'
 */
update.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: update.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\ChatbotSettingController::update
 * @see app/Http/Controllers/Admin/ChatbotSettingController.php:50
 * @route '/admin/chatbot/settings'
 */
    const updateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\ChatbotSettingController::update
 * @see app/Http/Controllers/Admin/ChatbotSettingController.php:50
 * @route '/admin/chatbot/settings'
 */
        updateForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(options),
            method: 'post',
        })
    
    update.form = updateForm
const settings = {
    update: Object.assign(update, update),
}

export default settings