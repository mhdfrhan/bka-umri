import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\ChatbotMonitoringController::conversations
 * @see app/Http/Controllers/Admin/ChatbotMonitoringController.php:58
 * @route '/admin/chatbot/monitoring/conversations'
 */
export const conversations = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: conversations.url(options),
    method: 'get',
})

conversations.definition = {
    methods: ["get","head"],
    url: '/admin/chatbot/monitoring/conversations',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\ChatbotMonitoringController::conversations
 * @see app/Http/Controllers/Admin/ChatbotMonitoringController.php:58
 * @route '/admin/chatbot/monitoring/conversations'
 */
conversations.url = (options?: RouteQueryOptions) => {
    return conversations.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\ChatbotMonitoringController::conversations
 * @see app/Http/Controllers/Admin/ChatbotMonitoringController.php:58
 * @route '/admin/chatbot/monitoring/conversations'
 */
conversations.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: conversations.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\ChatbotMonitoringController::conversations
 * @see app/Http/Controllers/Admin/ChatbotMonitoringController.php:58
 * @route '/admin/chatbot/monitoring/conversations'
 */
conversations.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: conversations.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\ChatbotMonitoringController::conversations
 * @see app/Http/Controllers/Admin/ChatbotMonitoringController.php:58
 * @route '/admin/chatbot/monitoring/conversations'
 */
    const conversationsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: conversations.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\ChatbotMonitoringController::conversations
 * @see app/Http/Controllers/Admin/ChatbotMonitoringController.php:58
 * @route '/admin/chatbot/monitoring/conversations'
 */
        conversationsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: conversations.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\ChatbotMonitoringController::conversations
 * @see app/Http/Controllers/Admin/ChatbotMonitoringController.php:58
 * @route '/admin/chatbot/monitoring/conversations'
 */
        conversationsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: conversations.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    conversations.form = conversationsForm
/**
* @see \App\Http\Controllers\Admin\ChatbotMonitoringController::conversation
 * @see app/Http/Controllers/Admin/ChatbotMonitoringController.php:100
 * @route '/admin/chatbot/monitoring/conversations/{id}'
 */
export const conversation = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: conversation.url(args, options),
    method: 'get',
})

conversation.definition = {
    methods: ["get","head"],
    url: '/admin/chatbot/monitoring/conversations/{id}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\ChatbotMonitoringController::conversation
 * @see app/Http/Controllers/Admin/ChatbotMonitoringController.php:100
 * @route '/admin/chatbot/monitoring/conversations/{id}'
 */
conversation.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    id: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        id: args.id,
                }

    return conversation.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\ChatbotMonitoringController::conversation
 * @see app/Http/Controllers/Admin/ChatbotMonitoringController.php:100
 * @route '/admin/chatbot/monitoring/conversations/{id}'
 */
conversation.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: conversation.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\ChatbotMonitoringController::conversation
 * @see app/Http/Controllers/Admin/ChatbotMonitoringController.php:100
 * @route '/admin/chatbot/monitoring/conversations/{id}'
 */
conversation.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: conversation.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\ChatbotMonitoringController::conversation
 * @see app/Http/Controllers/Admin/ChatbotMonitoringController.php:100
 * @route '/admin/chatbot/monitoring/conversations/{id}'
 */
    const conversationForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: conversation.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\ChatbotMonitoringController::conversation
 * @see app/Http/Controllers/Admin/ChatbotMonitoringController.php:100
 * @route '/admin/chatbot/monitoring/conversations/{id}'
 */
        conversationForm.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: conversation.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\ChatbotMonitoringController::conversation
 * @see app/Http/Controllers/Admin/ChatbotMonitoringController.php:100
 * @route '/admin/chatbot/monitoring/conversations/{id}'
 */
        conversationForm.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: conversation.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    conversation.form = conversationForm
/**
* @see \App\Http\Controllers\Admin\ChatbotMonitoringController::clear
 * @see app/Http/Controllers/Admin/ChatbotMonitoringController.php:148
 * @route '/admin/chatbot/monitoring/conversations'
 */
export const clear = (options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: clear.url(options),
    method: 'delete',
})

clear.definition = {
    methods: ["delete"],
    url: '/admin/chatbot/monitoring/conversations',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Admin\ChatbotMonitoringController::clear
 * @see app/Http/Controllers/Admin/ChatbotMonitoringController.php:148
 * @route '/admin/chatbot/monitoring/conversations'
 */
clear.url = (options?: RouteQueryOptions) => {
    return clear.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\ChatbotMonitoringController::clear
 * @see app/Http/Controllers/Admin/ChatbotMonitoringController.php:148
 * @route '/admin/chatbot/monitoring/conversations'
 */
clear.delete = (options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: clear.url(options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Admin\ChatbotMonitoringController::clear
 * @see app/Http/Controllers/Admin/ChatbotMonitoringController.php:148
 * @route '/admin/chatbot/monitoring/conversations'
 */
    const clearForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: clear.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\ChatbotMonitoringController::clear
 * @see app/Http/Controllers/Admin/ChatbotMonitoringController.php:148
 * @route '/admin/chatbot/monitoring/conversations'
 */
        clearForm.delete = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: clear.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    clear.form = clearForm
/**
* @see \App\Http\Controllers\Admin\ChatbotMonitoringController::apiStats
 * @see app/Http/Controllers/Admin/ChatbotMonitoringController.php:162
 * @route '/admin/chatbot/monitoring/api/stats'
 */
export const apiStats = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: apiStats.url(options),
    method: 'get',
})

apiStats.definition = {
    methods: ["get","head"],
    url: '/admin/chatbot/monitoring/api/stats',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\ChatbotMonitoringController::apiStats
 * @see app/Http/Controllers/Admin/ChatbotMonitoringController.php:162
 * @route '/admin/chatbot/monitoring/api/stats'
 */
apiStats.url = (options?: RouteQueryOptions) => {
    return apiStats.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\ChatbotMonitoringController::apiStats
 * @see app/Http/Controllers/Admin/ChatbotMonitoringController.php:162
 * @route '/admin/chatbot/monitoring/api/stats'
 */
apiStats.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: apiStats.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\ChatbotMonitoringController::apiStats
 * @see app/Http/Controllers/Admin/ChatbotMonitoringController.php:162
 * @route '/admin/chatbot/monitoring/api/stats'
 */
apiStats.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: apiStats.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\ChatbotMonitoringController::apiStats
 * @see app/Http/Controllers/Admin/ChatbotMonitoringController.php:162
 * @route '/admin/chatbot/monitoring/api/stats'
 */
    const apiStatsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: apiStats.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\ChatbotMonitoringController::apiStats
 * @see app/Http/Controllers/Admin/ChatbotMonitoringController.php:162
 * @route '/admin/chatbot/monitoring/api/stats'
 */
        apiStatsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: apiStats.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\ChatbotMonitoringController::apiStats
 * @see app/Http/Controllers/Admin/ChatbotMonitoringController.php:162
 * @route '/admin/chatbot/monitoring/api/stats'
 */
        apiStatsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: apiStats.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    apiStats.form = apiStatsForm
const monitoring = {
    conversations: Object.assign(conversations, conversations),
conversation: Object.assign(conversation, conversation),
clear: Object.assign(clear, clear),
apiStats: Object.assign(apiStats, apiStats),
}

export default monitoring