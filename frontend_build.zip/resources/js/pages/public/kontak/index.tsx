import { Seo } from '@/components/seo';
import { Head } from '@inertiajs/react';
import {
    MapPin,
    Phone,
    Mail,
    Clock,
    Send,
    Facebook,
    Instagram,
    Youtube,
    Twitter,
    Loader2,
    Compass,
    Layers,
    Navigation,
    Maximize2,
    Copy,
    Check,
} from 'lucide-react';
import { useState, useEffect, useRef } from 'react';
import { toast } from 'sonner';

import { Breadcrumbs } from '@/components/breadcrumbs';
import { PageHero } from '@/components/layout/page-hero';
import { useScrollReveal } from '@/hooks/use-scroll-reveal';
import { cn } from '@/lib/utils';
import 'maplibre-gl/dist/maplibre-gl.css';

interface MediaSosialItem {
    platform: string;
    url: string;
}

interface KontakDetail {
    alamat: string;
    telepon: string;
    email: string;
    jam_operasional: string;
    google_maps_embed: string;
    mediaSosial?: MediaSosialItem[];
}

interface KontakProps {
    kontak?: KontakDetail;
}

export default function KontakIndex({ kontak }: KontakProps) {
    const heroRef = useScrollReveal<HTMLDivElement>();
    const leftRef = useScrollReveal<HTMLDivElement>();
    const rightRef = useScrollReveal<HTMLDivElement>();

    // Safe fallback handling for dynamic vs mock data
    const resolvedKontak = kontak || {
        alamat: '',
        telepon: '',
        email: '',
        jam_operasional: '',
        google_maps_embed: '',
        mediaSosial: []
    };

    // ─── MAPLIBRE GL INTERACTIVE MAP ENGINE STATES & REFS ───
    const MAP_STYLES = [
        {
            id: 'voyager',
            label: 'Voyager (Warna)',
            url: 'https://basemaps.cartocdn.com/gl/voyager-gl-style/style.json',
        },
        {
            id: 'positron',
            label: 'Positron (Terang)',
            url: 'https://basemaps.cartocdn.com/gl/positron-gl-style/style.json',
        },
        {
            id: 'dark-matter',
            label: 'Dark Matter (Gelap)',
            url: 'https://basemaps.cartocdn.com/gl/dark-matter-gl-style/style.json',
        },
    ];

    const mapContainerRef = useRef<HTMLDivElement>(null);
    const mapInstanceRef = useRef<any>(null);

    const [activeStyleId, setActiveStyleId] = useState('voyager');
    const [is3DMode, setIs3DMode] = useState(false);
    const [centerCoords, setCenterCoords] = useState({
        lat: 0.498705,
        lng: 101.415461,
    });
    const [copied, setCopied] = useState(false);

    // Initializing MapLibre GL dynamically to prevent SSR global evaluation issues
    useEffect(() => {
        if (typeof window === 'undefined' || !mapContainerRef.current) {
            return;
        }

        let map: any;

        import('maplibre-gl').then((maplibreglModule) => {
            const maplibregl = maplibreglModule.default;

            map = new maplibregl.Map({
                container: mapContainerRef.current!,
                style: MAP_STYLES[0].url, // Voyager
                center: [101.415461, 0.498705], // Lng, Lat
                zoom: 16,
                pitch: 0,
                bearing: 0,
                dragRotate: true,
            });

            mapInstanceRef.current = map;

            // Wait for style to load then add custom Forrest Green marker
            map.on('load', () => {
                // Create custom pulsed marker DOM element
                const el = document.createElement('div');
                el.className = 'custom-marker';
                el.innerHTML = `
                    <div class="relative flex items-center justify-center">
                        <div class="animate-ping absolute inline-flex h-8 w-8 rounded-full bg-[#0a6c32] opacity-75"></div>
                        <div class="relative flex items-center justify-center rounded-full bg-[#0a6c32] border-2 border-white p-2.5 text-white shadow-md">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                                <path fill-rule="evenodd" d="M5.05 4.05a7 7 0 119.9 9.9L10 18.9l-4.95-4.95a7 7 0 010-9.9zM10 11a2 2 0 100-4 2 2 0 000 4z" clip-rule="evenodd" />
                            </svg>
                        </div>
                    </div>
                `;

                // Add popup
                new maplibregl.Popup({
                    offset: 25,
                    closeButton: false,
                    closeOnClick: false,
                })
                    .setLngLat([101.415461, 0.498705])
                    .setHTML(`
                    <div class="p-2 text-center select-none font-sans">
                        <p class="font-extrabold text-[#1A1A1A] text-xs">Kantor BKA UMRI</p>
                        <p class="text-[10px] text-neutral-500 font-light mt-0.5">Gedung Rektorat Kampus Utama</p>
                    </div>
                `)
                    .addTo(map);

                // Create and add marker
                new maplibregl.Marker({ element: el })
                    .setLngLat([101.415461, 0.498705])
                    .addTo(map);
            });

            // Track coordinate moves
            map.on('move', () => {
                const center = map.getCenter();
                setCenterCoords({ lat: center.lat, lng: center.lng });
            });
        });

        // Cleanup map instance on unmount
        return () => {
            if (map) {
                map.remove();
            }
        };
    }, []);

    // ─── MAP CONTROL ACTIONS ───
    const handleStyleChange = (url: string, id: string) => {
        if (mapInstanceRef.current) {
            mapInstanceRef.current.setStyle(url);
            setActiveStyleId(id);
            toast.success(`Gaya peta berhasil diubah ke ${id.toUpperCase()}`);
        }
    };

    const handleRecenter = () => {
        if (mapInstanceRef.current) {
            mapInstanceRef.current.easeTo({
                center: [101.415461, 0.498705],
                zoom: 16,
                pitch: is3DMode ? 45 : 0,
                bearing: 0,
                duration: 1500,
            });
            toast.success('Peta dikembalikan ke lokasi kampus utama.');
        }
    };

    const handleToggle3D = () => {
        const nextMode = !is3DMode;
        setIs3DMode(nextMode);

        if (mapInstanceRef.current) {
            mapInstanceRef.current.easeTo({
                pitch: nextMode ? 45 : 0,
                bearing: nextMode ? -20 : 0,
                duration: 1200,
            });
            toast.success(
                nextMode
                    ? 'Mode kemiringan 3D diaktifkan'
                    : 'Mode 2D diaktifkan',
            );
        }
    };

    const handleCopyCoords = () => {
        navigator.clipboard.writeText('0.498705, 101.415461');
        setCopied(true);
        toast.success('Koordinat Rektorat UMRI disalin ke papan klip!');
        setTimeout(() => setCopied(false), 2000);
    };

    // Form inputs state
    const [formData, setFormData] = useState({
        nama: '',
        email: '',
        subjek: '',
        pesan: '',
    });

    // Form validation errors state
    const [errors, setErrors] = useState({
        nama: '',
        email: '',
        subjek: '',
        pesan: '',
    });

    const [submitting, setSubmitting] = useState(false);
    const [messageCount, setMessageCount] = useState(0);

    // Dynamic input change handler
    const handleChange = (
        e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>,
    ) => {
        const { name, value } = e.target;
        setFormData((prev) => ({ ...prev, [name]: value }));

        // Real-time validation clearance
        if (errors[name as keyof typeof errors]) {
            setErrors((prev) => ({ ...prev, [name]: '' }));
        }
    };

    // Client-side validation logic
    const validateForm = () => {
        let isValid = true;
        const newErrors = { nama: '', email: '', subjek: '', pesan: '' };

        if (!formData.nama.trim()) {
            newErrors.nama = 'Nama lengkap wajib diisi';
            isValid = false;
        }

        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

        if (!formData.email.trim()) {
            newErrors.email = 'Alamat email wajib diisi';
            isValid = false;
        } else if (!emailRegex.test(formData.email)) {
            newErrors.email = 'Format alamat email tidak valid';
            isValid = false;
        }

        if (!formData.subjek.trim()) {
            newErrors.subjek = 'Subjek pesan wajib diisi';
            isValid = false;
        }

        if (!formData.pesan.trim()) {
            newErrors.pesan = 'Isi pesan wajib diisi';
            isValid = false;
        } else if (formData.pesan.trim().length < 20) {
            newErrors.pesan = 'Pesan minimal berisi 20 karakter';
            isValid = false;
        }

        setErrors(newErrors);

        return isValid;
    };

    // Form submit handler
    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();

        // 1. Perform validation checks
        if (!validateForm()) {
            return;
        }

        setSubmitting(true);

        try {
            // Get CSRF Token
            const csrfToken =
                document
                    .querySelector('meta[name="csrf-token"]')
                    ?.getAttribute('content') || '';

            const response = await fetch('/kontak', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    Accept: 'application/json',
                    'X-CSRF-TOKEN': csrfToken,
                },
                body: JSON.stringify(formData),
            });

            const result = await response.json();

            if (response.ok) {
                toast.success(result.message || 'Pesan berhasil dikirim!');
                setFormData({
                    nama: '',
                    email: '',
                    subjek: '',
                    pesan: '',
                });
                setMessageCount((prev) => prev + 1);
            } else {
                if (response.status === 429) {
                    toast.error(
                        'Terlalu banyak mengirim pesan. Silakan coba lagi nanti.',
                    );
                } else if (response.status === 422 && result.errors) {
                    const validationErrors = {
                        nama: '',
                        email: '',
                        subjek: '',
                        pesan: '',
                    };
                    Object.keys(result.errors).forEach((key) => {
                        if (key in validationErrors) {
                            validationErrors[
                                key as keyof typeof validationErrors
                            ] = result.errors[key][0];
                        }
                    });
                    setErrors(validationErrors);
                    toast.error('Harap periksa kembali isian formulir Anda.');
                } else {
                    toast.error(result.message || 'Gagal mengirim pesan.');
                }
            }
        } catch (err) {
            console.error('Error submitting form:', err);
            toast.error(
                'Terjadi kesalahan koneksi. Silakan coba beberapa saat lagi.',
            );
        } finally {
            setSubmitting(false);
        }
    };

    const breadcrumbItems = [
        { title: 'Beranda', href: '/' },
        { title: 'Hubungi Kami', href: '/kontak' },
    ];

    const getSocialIcon = (platform: string) => {
        switch (platform.toLowerCase()) {
            case 'facebook':
                return <Facebook size={16} />;
            case 'instagram':
                return <Instagram size={16} />;
            case 'youtube':
                return <Youtube size={16} />;
            case 'twitter':
            case 'x':
                return <Twitter size={16} />;
            default:
                return null;
        }
    };

    return (
        <>
            <Seo title="Hubungi Kami - BKA UMRI" description="Kirim pesan langsung, kritik, saran, atau pertanyaan mengenai layanan administrasi keuangan dan pengelolaan aset di Universitas Muhammadiyah Riau." />

            {/* Page Hero */}
            <PageHero
                title="Hubungi Kami"
                description="Kami siap membantu Anda. Silakan hubungi kontak resmi kami atau kirimkan pesan melalui formulir di bawah ini."
            >
                <div ref={heroRef} className="bka-reveal">
                    <Breadcrumbs
                        breadcrumbs={breadcrumbItems}
                        variant="public"
                    />
                </div>
            </PageHero>

            {/* Main Interactive Contact Body */}
            <section className="bg-[#F7F9F7] py-12 md:py-20">
                <div className="bka-container">
                    <div className="grid grid-cols-1 gap-12 lg:grid-cols-12 lg:items-start">
                        {/* LEFT COLUMN: Contact info & Maps Embed (5/12 cols) */}
                        <div
                            ref={leftRef}
                            className="bka-reveal flex flex-col gap-8 lg:col-span-5"
                        >
                            {/* Contact Info Card */}
                            <div className="rounded-2xl border border-[#DDE5DD] bg-white p-6 shadow-sm md:p-8">
                                <h2 className="mb-2 text-xl font-bold text-[#1A1A1A]">
                                    Kantor Biro Keuangan dan Aset
                                </h2>
                                <p className="mb-6 border-b border-[#F1F3F1] pb-4 text-[13px] leading-relaxed text-[#5C6B73]">
                                    Jangan ragu untuk menemui kami terkait
                                    keuangan dan aset Universitas Muhammadiyah
                                    Riau
                                </p>

                                <div className="flex flex-col gap-6">
                                    {/* Address */}
                                    <div className="flex items-start gap-4">
                                        <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-[#e6f4ea] text-[#0a6c32]">
                                            <MapPin size={20} />
                                        </div>
                                        <div className="flex flex-col">
                                            <span className="mb-1 text-xs font-bold text-[#5C6B73]">
                                                Alamat Kantor Biro
                                            </span>
                                            <p className="text-[14px] leading-relaxed break-words whitespace-pre-line text-[#1A1A1A]">
                                                {resolvedKontak.alamat}
                                            </p>
                                        </div>
                                    </div>

                                    {/* Telephone */}
                                    <div className="flex items-start gap-4">
                                        <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-[#e6f4ea] text-[#0a6c32]">
                                            <Phone size={20} />
                                        </div>
                                        <div className="flex flex-col">
                                            <span className="mb-1 text-xs font-bold text-[#5C6B73]">
                                                Telepon / Hotline
                                            </span>
                                            <p className="text-[14px] leading-normal font-semibold text-[#1A1A1A]">
                                                {resolvedKontak.telepon}
                                            </p>
                                        </div>
                                    </div>

                                    {/* Email */}
                                    <div className="flex items-start gap-4">
                                        <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-[#e6f4ea] text-[#0a6c32]">
                                            <Mail size={20} />
                                        </div>
                                        <div className="flex flex-col">
                                            <span className="mb-1 text-xs font-bold text-[#5C6B73]">
                                                Email Resmi
                                            </span>
                                            <a
                                                href={`mailto:${resolvedKontak.email}`}
                                                className="text-[14px] leading-normal font-bold text-[#0a6c32] hover:text-[#085627] hover:underline"
                                            >
                                                {resolvedKontak.email}
                                            </a>
                                        </div>
                                    </div>

                                    {/* Hours */}
                                    <div className="flex items-start gap-4">
                                        <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-[#e6f4ea] text-[#0a6c32]">
                                            <Clock size={20} />
                                        </div>
                                        <div className="flex flex-col">
                                            <span className="mb-1 text-xs font-bold text-[#5C6B73]">
                                                Jam Operasional
                                            </span>
                                            <p className="text-[14px] leading-relaxed whitespace-pre-line text-[#1A1A1A]">
                                                {resolvedKontak.jam_operasional}
                                            </p>
                                        </div>
                                    </div>
                                </div>

                                {/* Social Links */}
                                {resolvedKontak.mediaSosial &&
                                    resolvedKontak.mediaSosial.length > 0 && (
                                        <div className="mt-8 flex flex-wrap items-center justify-between gap-3 border-t border-[#F1F3F1] pt-6">
                                            <span className="text-xs font-bold text-[#5C6B73]">
                                                Media Sosial Resmi BKA:
                                            </span>
                                            <div className="flex gap-2">
                                                {resolvedKontak.mediaSosial.map(
                                                    (med, idx) => (
                                                        <a
                                                            key={idx}
                                                            href={med.url}
                                                            target="_blank"
                                                            rel="noopener noreferrer"
                                                            aria-label={`Official ${med.platform} Page`}
                                                            className="flex h-8 w-8 items-center justify-center rounded-xl bg-[#F7F9F7] text-[#5C6B73] transition-all duration-200 hover:bg-[#0a6c32] hover:text-white"
                                                        >
                                                            {getSocialIcon(
                                                                med.platform,
                                                            )}
                                                        </a>
                                                    ),
                                                )}
                                            </div>
                                        </div>
                                    )}
                            </div>

                            {/* Maps placeholder removed in favor of full-width interactive section below */}
                        </div>

                        {/* RIGHT COLUMN: Contact Form (7/12 cols) */}
                        <div
                            ref={rightRef}
                            className="bka-reveal lg:col-span-7"
                        >
                            <form
                                onSubmit={handleSubmit}
                                className="rounded-2xl border border-[#DDE5DD] bg-white p-6 shadow-sm md:p-10"
                            >
                                <h2 className="mb-2 text-xl font-bold text-[#1A1A1A]">
                                    Kirimkan Pesan Anda
                                </h2>
                                <p className="mb-8 text-xs text-[#5C6B73]">
                                    Punya pertanyaan, keluhan, saran, atau
                                    masukan? Silakan isi data di bawah.
                                </p>

                                <div className="flex flex-col gap-5">
                                    {/* Name Input */}
                                    <div className="flex flex-col gap-2">
                                        <label
                                            htmlFor="nama"
                                            className="text-xs font-bold text-[#1A1A1A]"
                                        >
                                            Nama Lengkap{' '}
                                            <span className="text-rose-500">
                                                *
                                            </span>
                                        </label>
                                        <input
                                            type="text"
                                            id="nama"
                                            name="nama"
                                            value={formData.nama}
                                            onChange={handleChange}
                                            placeholder="Masukkan nama lengkap Anda..."
                                            className={`w-full rounded-xl border bg-white px-4 py-3 text-[14px] text-[#1A1A1A] transition-colors focus:ring-1 focus:outline-none ${
                                                errors.nama
                                                    ? 'border-rose-500 bg-rose-50/10 focus:border-rose-500 focus:ring-rose-500'
                                                    : 'border-[#DDE5DD] focus:border-[#0a6c32] focus:ring-[#0a6c32]'
                                            }`}
                                        />
                                        {errors.nama && (
                                            <span className="text-xs font-semibold text-rose-600">
                                                {errors.nama}
                                            </span>
                                        )}
                                    </div>

                                    {/* Email Input */}
                                    <div className="flex flex-col gap-2">
                                        <label
                                            htmlFor="email"
                                            className="text-xs font-bold text-[#1A1A1A]"
                                        >
                                            Alamat Email{' '}
                                            <span className="text-rose-500">
                                                *
                                            </span>
                                        </label>
                                        <input
                                            type="email"
                                            id="email"
                                            name="email"
                                            value={formData.email}
                                            onChange={handleChange}
                                            placeholder="Masukkan alamat email aktif..."
                                            className={`w-full rounded-xl border bg-white px-4 py-3 text-[14px] text-[#1A1A1A] transition-colors focus:ring-1 focus:outline-none ${
                                                errors.email
                                                    ? 'border-rose-500 bg-rose-50/10 focus:border-rose-500 focus:ring-rose-500'
                                                    : 'border-[#DDE5DD] focus:border-[#0a6c32] focus:ring-[#0a6c32]'
                                            }`}
                                        />
                                        {errors.email && (
                                            <span className="text-xs font-semibold text-rose-600">
                                                {errors.email}
                                            </span>
                                        )}
                                    </div>

                                    {/* Subject Input */}
                                    <div className="flex flex-col gap-2">
                                        <label
                                            htmlFor="subjek"
                                            className="text-xs font-bold text-[#1A1A1A]"
                                        >
                                            Subjek Pesan{' '}
                                            <span className="text-rose-500">
                                                *
                                            </span>
                                        </label>
                                        <input
                                            type="text"
                                            id="subjek"
                                            name="subjek"
                                            value={formData.subjek}
                                            onChange={handleChange}
                                            placeholder="Perihal yang ingin dibahas..."
                                            className={`w-full rounded-xl border bg-white px-4 py-3 text-[14px] text-[#1A1A1A] transition-colors focus:ring-1 focus:outline-none ${
                                                errors.subjek
                                                    ? 'border-rose-500 bg-rose-50/10 focus:border-rose-500 focus:ring-rose-500'
                                                    : 'border-[#DDE5DD] focus:border-[#0a6c32] focus:ring-[#0a6c32]'
                                            }`}
                                        />
                                        {errors.subjek && (
                                            <span className="text-xs font-semibold text-rose-600">
                                                {errors.subjek}
                                            </span>
                                        )}
                                    </div>

                                    {/* Message TextArea */}
                                    <div className="flex flex-col gap-2">
                                        <label
                                            htmlFor="pesan"
                                            className="text-xs font-bold text-[#1A1A1A]"
                                        >
                                            Isi Pesan Lengkap{' '}
                                            <span className="text-rose-500">
                                                *
                                            </span>
                                        </label>
                                        <textarea
                                            id="pesan"
                                            name="pesan"
                                            value={formData.pesan}
                                            onChange={handleChange}
                                            rows={5}
                                            placeholder="Tuliskan detail pertanyaan atau keluhan Anda di sini (minimal 20 karakter)..."
                                            className={`w-full resize-none rounded-xl border bg-white px-4 py-3 text-[14px] text-[#1A1A1A] transition-colors focus:ring-1 focus:outline-none ${
                                                errors.pesan
                                                    ? 'border-rose-500 bg-rose-50/10 focus:border-rose-500 focus:ring-rose-500'
                                                    : 'border-[#DDE5DD] focus:border-[#0a6c32] focus:ring-[#0a6c32]'
                                            }`}
                                        />
                                        {errors.pesan ? (
                                            <span className="text-xs font-semibold text-rose-600">
                                                {errors.pesan}
                                            </span>
                                        ) : (
                                            <div className="flex items-center justify-between text-[11px] font-medium text-[#9EAAB2]">
                                                <span>
                                                    Panjang isi pesan:{' '}
                                                    {
                                                        formData.pesan.trim()
                                                            .length
                                                    }{' '}
                                                    karakter
                                                </span>
                                                <span>
                                                    Minimum: 20 karakter
                                                </span>
                                            </div>
                                        )}
                                    </div>

                                    {/* Submit Button */}
                                    <div className="mt-2 pt-4">
                                        <button
                                            type="submit"
                                            disabled={submitting}
                                            className="inline-flex h-11 w-full cursor-pointer items-center justify-center gap-2 rounded-xl bg-[#0a6c32] text-xs font-bold text-white shadow-md transition-all duration-200 hover:bg-[#085627] disabled:cursor-not-allowed disabled:bg-[#0a6c32]/75"
                                        >
                                            {submitting ? (
                                                <>
                                                    <Loader2
                                                        size={16}
                                                        className="animate-spin"
                                                    />
                                                    <span>
                                                        Sedang Mengirim...
                                                    </span>
                                                </>
                                            ) : (
                                                <>
                                                    <Send size={14} />
                                                    <span>
                                                        Kirim Pesan Sekarang
                                                    </span>
                                                </>
                                            )}
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </section>

            {/* FULL WIDTH INTERACTIVE MAPLIBRE MAP SECTION */}
            <section className="relative w-full border-t border-[#DDE5DD] bg-white">
                {/* Visual Section Intro Header */}
                <div className="bka-container pt-12 pb-6">
                    <div className="flex flex-col gap-2">
                        <span className="text-[10px] font-extrabold tracking-widest text-[#0a6c32] uppercase">
                            Lokasi Kampus Utama
                        </span>
                        <h2 className="text-xl font-bold text-[#1A1A1A] md:text-2xl">
                            Peta Interaktif Kampus Universitas Muhammadiyah Riau
                        </h2>
                        <p className="max-w-2xl text-xs font-light text-[#5C6B73]">
                            Eksplorasi wilayah kampus UMRI secara interaktif
                            menggunakan rendering vektor 3D 60FPS. Anda dapat
                            menggeser, melakukan zoom, memutar orientasi peta,
                            dan mengganti gaya visual peta.
                        </p>
                    </div>
                </div>

                {/* Maplibre container */}
                <div className="group relative h-[450px] w-full bg-slate-100 select-none md:h-[550px]">
                    <div
                        ref={mapContainerRef}
                        className="h-full w-full cursor-grab active:cursor-grabbing"
                    />

                    {/* Floating Controls Overlay - Top Left: Styles Selector */}
                    <div className="absolute top-4 left-4 z-10 flex flex-col gap-2 rounded-2xl border border-[#DDE5DD] bg-white/80 p-2 shadow-sm backdrop-blur-md transition-all">
                        <div className="flex items-center gap-1.5 border-b border-[#F1F3F1] px-1.5 pb-1 text-[9px] font-extrabold tracking-wide text-neutral-400 uppercase">
                            <Layers size={10} className="text-[#0a6c32]" />
                            <span>Gaya Visual Peta</span>
                        </div>
                        <div className="flex flex-col gap-1">
                            {MAP_STYLES.map((style) => (
                                <button
                                    key={style.id}
                                    type="button"
                                    onClick={() =>
                                        handleStyleChange(style.url, style.id)
                                    }
                                    className={cn(
                                        'flex cursor-pointer items-center justify-between rounded-lg px-3 py-1.5 text-left text-[11px] font-bold transition-all outline-none',
                                        activeStyleId === style.id
                                            ? 'bg-[#0a6c32] text-white'
                                            : 'text-[#1A1A1A] hover:bg-[#e6f4ea]',
                                    )}
                                >
                                    <span>{style.label}</span>
                                </button>
                            ))}
                        </div>
                    </div>

                    {/* Floating Controls Overlay - Top Right: Quick Navigation Tools */}
                    <div className="absolute top-4 right-4 z-10 flex flex-col gap-2">
                        {/* Re-center Button */}
                        <button
                            type="button"
                            onClick={handleRecenter}
                            className="flex h-9 w-9 cursor-pointer items-center justify-center rounded-xl border border-[#DDE5DD] bg-white/90 text-[#0a6c32] shadow-sm backdrop-blur-md transition-all outline-none hover:scale-105 hover:bg-white"
                            title="Kembali ke UMRI"
                        >
                            <Navigation size={16} />
                        </button>

                        {/* Tilt / 3D Mode Toggle */}
                        <button
                            type="button"
                            onClick={handleToggle3D}
                            className={cn(
                                'flex h-9 w-9 cursor-pointer items-center justify-center rounded-xl border bg-white/90 shadow-sm backdrop-blur-md transition-all outline-none hover:scale-105',
                                is3DMode
                                    ? 'border-[#0a6c32]/40 bg-emerald-50/50 text-[#0a6c32]'
                                    : 'border-[#DDE5DD] text-neutral-500 hover:bg-white',
                            )}
                            title="Aktifkan Mode 3D / Kemiringan"
                        >
                            <Compass
                                size={16}
                                className={cn(is3DMode && 'animate-pulse')}
                            />
                        </button>
                    </div>

                    {/* Floating Info Overlay - Bottom Left: Coordinates Tracker */}
                    <div className="absolute bottom-4 left-4 z-10 hidden items-center gap-4 rounded-2xl border border-[#DDE5DD] bg-white/90 px-4 py-2.5 text-[10px] font-semibold text-neutral-500 shadow-xs backdrop-blur-md sm:flex">
                        <div className="flex items-center gap-1.5">
                            <span className="size-1.5 animate-ping rounded-full bg-emerald-500" />
                            <span>Koordinat Peta:</span>
                        </div>
                        <div className="font-mono">
                            <span>Lat: </span>
                            <span className="font-bold text-neutral-800 select-all">
                                {centerCoords.lat.toFixed(6)}
                            </span>
                        </div>
                        <div className="font-mono">
                            <span>Lng: </span>
                            <span className="font-bold text-neutral-800 select-all">
                                {centerCoords.lng.toFixed(6)}
                            </span>
                        </div>
                    </div>

                    {/* Floating Info Overlay - Bottom Right: Interactive Contact Details Glassmorphism Card */}
                    <div className="absolute right-4 bottom-4 z-10 flex w-72 flex-col gap-2 rounded-2xl border border-[#DDE5DD]/80 bg-white/80 p-4 shadow-sm backdrop-blur-lg">
                        <div className="flex items-center gap-2">
                            <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-lg bg-[#e6f4ea] text-[#0a6c32]">
                                <MapPin size={12} />
                            </div>
                            <span className="text-xs font-bold text-[#1A1A1A]">
                                Rektorat UMRI Pekanbaru
                            </span>
                        </div>
                        <p className="text-[10px] leading-relaxed font-light text-[#5C6B73]">
                            Jl. T. Tambusai, Delima, Kec. Tampan, Kota
                            Pekanbaru, Riau 28290. Gedung Rektorat Utama, Ruang
                            BKA.
                        </p>

                        <div className="mt-1 flex gap-1.5 border-t border-[#F1F3F1] pt-2.5 select-none">
                            <button
                                type="button"
                                onClick={handleCopyCoords}
                                className="flex flex-1 cursor-pointer items-center justify-center gap-1 rounded-lg border border-neutral-200 bg-white py-1.5 text-[10px] font-bold text-neutral-600 transition-colors outline-none hover:bg-neutral-50"
                            >
                                {copied ? (
                                    <>
                                        <Check
                                            size={11}
                                            className="text-[#0a6c32]"
                                        />
                                        <span>Tersalin</span>
                                    </>
                                ) : (
                                    <>
                                        <Copy size={11} />
                                        <span>Salin Lat Lng</span>
                                    </>
                                )}
                            </button>
                            <a
                                href="https://maps.google.com/?q=Universitas+Muhammadiyah+Riau"
                                target="_blank"
                                rel="noreferrer"
                                className="flex flex-1 items-center justify-center gap-1 rounded-lg bg-[#0a6c32] py-1.5 text-center text-[10px] font-bold text-white shadow-xs transition-all hover:scale-[1.02] hover:bg-[#085627]"
                            >
                                <Maximize2 size={11} />
                                <span>Buka Google Maps</span>
                            </a>
                        </div>
                    </div>
                </div>
            </section>
        </>
    );
}
