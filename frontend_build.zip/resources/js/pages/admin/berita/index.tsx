import { Head, Link, router } from '@inertiajs/react';
import {
    Newspaper,
    Search,
    Plus,
    Trash2,
    Edit2,
    FolderOpen,
    Calendar,
    User,
    Eye,
    AlertCircle,
    X,
} from 'lucide-react';
import { useState, useEffect } from 'react';
import { toast } from 'sonner';
import { ConfirmDialog } from '@/components/ui/confirm-dialog';

interface NewsItem {
    id: number;
    slug: string;
    thumbnail: string;
    category?: string;
    title: string;
    excerpt: string;
    content: string;
    date: string;
    author?: string;
    status: 'draf' | 'terpublikasi' | 'diarsipkan';
    deleted_at?: string | null;
}

interface CategoryItem {
    id: number;
    nama: string;
    slug: string;
}

interface BeritaIndexProps {
    beritas: NewsItem[];
    categories: CategoryItem[];
}

export default function BeritaIndex({
    beritas = [],
    categories = [],
}: BeritaIndexProps) {
    // Filters State
    const [searchQuery, setSearchQuery] = useState('');
    const [filterCategory, setFilterCategory] = useState('Semua');
    const [filterStatus, setFilterStatus] = useState('Semua');

    // Pagination
    const [currentPage, setCurrentPage] = useState(1);
    const itemsPerPage = 10;

    // Category CRUD inline
    const [newCategoryName, setNewCategoryName] = useState('');
    const [isCategoryModalOpen, setIsCategoryModalOpen] = useState(false);

    // Delete confirmation modal
    const [deletingNewsId, setDeletingNewsId] = useState<number | null>(null);

    // Trash logic
    const [showTrashed, setShowTrashed] = useState(() => {
        if (typeof window !== 'undefined') {
            return new URLSearchParams(window.location.search).get('trashed') === 'true';
        }
        return false;
    });

    const toggleTrashed = () => {
        const newValue = !showTrashed;
        setShowTrashed(newValue);
        router.get('/admin/berita', { trashed: newValue ? 'true' : undefined }, { preserveState: true });
    };

    const handleRestore = (id: number) => {
        toast.promise(
            new Promise((resolve, reject) => {
                router.post(`/admin/berita/${id}/restore`, {}, {
                    onSuccess: () => resolve(true),
                    onError: () => reject(new Error('Gagal memulihkan berita')),
                });
            }),
            {
                loading: 'Memulihkan...',
                success: 'Berita berhasil dipulihkan!',
                error: 'Terjadi kesalahan saat memulihkan berita.',
            }
        );
    };

    // Filter Logic (Client-side for premium responsive UX)
    const filteredNews = beritas.filter((item) => {
        const matchesSearch = item.title
            .toLowerCase()
            .includes(searchQuery.toLowerCase());
        const matchesCategory =
            filterCategory === 'Semua' || item.category === filterCategory;
        const matchesStatus =
            filterStatus === 'Semua' || item.status === filterStatus;

        return matchesSearch && matchesCategory && matchesStatus;
    });

    // Pagination Logic
    const totalPages = Math.ceil(filteredNews.length / itemsPerPage);
    const indexOfLastItem = currentPage * itemsPerPage;
    const indexOfFirstItem = indexOfLastItem - itemsPerPage;
    const currentItems = filteredNews.slice(indexOfFirstItem, indexOfLastItem);

    // Handle add category
    const handleAddCategory = (e: React.FormEvent) => {
        e.preventDefault();
        const trimmed = newCategoryName.trim();

        if (!trimmed) {
            return;
        }

        if (
            categories.some(
                (c) => c.nama.toLowerCase() === trimmed.toLowerCase(),
            )
        ) {
            toast.error('Kategori tersebut sudah terdaftar!');
            return;
        }

        router.post(
            '/admin/berita/kategori',
            { nama: trimmed },
            {
                onSuccess: () => {
                    setNewCategoryName('');
                    toast.success(
                        `Kategori "${trimmed}" berhasil ditambahkan!`,
                    );
                },
                onError: (errors) => {
                    if (errors.nama) {
                        toast.error(errors.nama);
                    } else {
                        toast.error('Gagal menambahkan kategori.');
                    }
                },
            },
        );
    };

    // Handle delete category
    const handleDeleteCategory = (catId: number) => {
        const catObj = categories.find((c) => c.id === catId);
        router.delete(`/admin/berita/kategori/${catId}`, {
            onSuccess: () => {
                toast.success(
                    `Kategori "${catObj?.nama}" dihapus. Berita terkait dialihkan ke "Tanpa Kategori".`,
                );
            },
            onError: () => {
                toast.error('Gagal menghapus kategori.');
            },
        });
    };

    // Handle delete news
    const confirmDeleteNews = () => {
        if (deletingNewsId === null) {
            return;
        }

        const targetNews = beritas.find((n) => n.id === deletingNewsId);
        router.delete(`/admin/berita/${deletingNewsId}`, {
            onSuccess: () => {
                setDeletingNewsId(null);
                toast.success(
                    `Berita "${targetNews?.title}" berhasil dihapus.`,
                );
            },
            onError: () => {
                setDeletingNewsId(null);
                toast.error('Gagal menghapus berita.');
            },
        });
    };

    return (
        <>
            <Head title="Kelola Berita - Admin BKA" />

            <div className="mx-auto w-full max-w-7xl space-y-6 p-6 md:space-y-8 md:p-8">
                {/* Header */}
                <div className="flex flex-col justify-between gap-4 border-b border-neutral-200 pb-5 md:flex-row md:items-center">
                    <div>
                        <h1 className="flex items-center gap-2 text-2xl font-extrabold tracking-tight text-neutral-800">
                            <Newspaper className="size-6 text-emerald-600" />
                            Manajemen Berita & Kegiatan
                        </h1>
                        <p className="mt-1 text-sm leading-relaxed font-normal text-neutral-500">
                            Publikasikan pengumuman berita, liputan acara, dan
                            update informasi layanan Biro Keuangan & Aset UMRI.
                        </p>
                    </div>

                    <div className="flex items-center gap-2">
                        <button
                            type="button"
                            onClick={() => setIsCategoryModalOpen(true)}
                            className="inline-flex items-center gap-1.5 rounded-xl border border-neutral-200 bg-white px-4 py-2.5 text-sm font-semibold text-neutral-700 shadow-xs hover:bg-neutral-50"
                        >
                            <FolderOpen className="size-4 text-neutral-500" />
                            Kelola Kategori
                        </button>
                        <Link
                            href="/admin/berita/create"
                            className="inline-flex items-center gap-1.5 rounded-xl bg-emerald-600 px-4 py-2.5 text-sm font-bold text-white shadow-md transition-all hover:bg-emerald-700"
                        >
                            <Plus className="size-4" />
                            Tambah Berita
                        </Link>
                    </div>
                </div>

                {/* CSS Grid layout for perfect side-by-side management */}
                <div className="grid w-full grid-cols-1 items-start gap-8 lg:grid-cols-[28%_1fr]">
                    {/* Left Column: Filter Sidebar & Quick Actions */}
                    <div className="space-y-6 rounded-2xl border border-neutral-200/60 bg-neutral-50/50 p-6">
                        <div className="border-b border-neutral-200 pb-3">
                            <h2 className="text-sm font-extrabold tracking-wider text-emerald-950 uppercase">
                                Filter Pencarian
                            </h2>
                        </div>

                        {/* Search Input */}
                        <div className="space-y-1.5">
                            <label className="text-xs font-bold tracking-wide text-neutral-600 uppercase">
                                Kata Kunci Judul
                            </label>
                            <div className="relative">
                                <input
                                    type="text"
                                    placeholder="Cari judul berita..."
                                    value={searchQuery}
                                    onChange={(e) => {
                                        setSearchQuery(e.target.value);
                                        setCurrentPage(1);
                                    }}
                                    className="w-full rounded-xl border border-neutral-200 bg-white py-2.5 pr-4 pl-10 text-sm font-semibold text-neutral-800 transition-colors focus:border-emerald-600 focus:ring-1 focus:ring-emerald-600 focus:outline-none"
                                />
                                <Search className="absolute top-1/2 left-3.5 size-4 -translate-y-1/2 text-neutral-400" />
                            </div>
                        </div>

                        {/* Category Filter */}
                        <div className="space-y-1.5">
                            <label className="text-xs font-bold tracking-wide text-neutral-600 uppercase">
                                Pilih Kategori
                            </label>
                            <select
                                value={filterCategory}
                                onChange={(e) => {
                                    setFilterCategory(e.target.value);
                                    setCurrentPage(1);
                                }}
                                className="w-full rounded-xl border border-neutral-200 bg-white p-3 text-sm font-semibold text-neutral-800 transition-colors focus:border-emerald-600 focus:ring-1 focus:ring-emerald-600"
                            >
                                <option value="Semua">Semua Kategori</option>
                                {categories.map((c) => (
                                    <option key={c.id} value={c.nama}>
                                        {c.nama}
                                    </option>
                                ))}
                                <option value="Tanpa Kategori">
                                    Tanpa Kategori
                                </option>
                            </select>
                        </div>

                        {/* Status Filter */}
                        <div className="space-y-1.5">
                            <label className="text-xs font-bold tracking-wide text-neutral-600 uppercase">
                                Pilih Status
                            </label>
                            <select
                                value={filterStatus}
                                onChange={(e) => {
                                    setFilterStatus(e.target.value);
                                    setCurrentPage(1);
                                }}
                                className="w-full rounded-xl border border-neutral-200 bg-white p-3 text-sm font-semibold text-neutral-800 transition-colors focus:border-emerald-600 focus:ring-1 focus:ring-emerald-600"
                            >
                                <option value="Semua">Semua Status</option>
                                <option value="terpublikasi">
                                    Terpublikasi
                                </option>
                                <option value="draf">Draf</option>
                                <option value="diarsipkan">Diarsipkan</option>
                            </select>
                        </div>

                        {/* Clear Filters */}
                        {(searchQuery ||
                            filterCategory !== 'Semua' ||
                            filterStatus !== 'Semua') && (
                            <button
                                type="button"
                                onClick={() => {
                                    setSearchQuery('');
                                    setFilterCategory('Semua');
                                    setFilterStatus('Semua');
                                }}
                                className="w-full rounded-xl border border-dashed border-red-200 bg-red-50/50 py-2 text-center text-xs font-bold text-red-600 hover:text-red-700"
                            >
                                Reset Semua Filter
                            </button>
                        )}

                        <div className="pt-4 border-t border-neutral-200/60">
                            <button
                                type="button"
                                onClick={toggleTrashed}
                                className={`flex h-10 w-full items-center justify-center gap-2 rounded-xl border px-4 text-sm font-bold transition-colors ${showTrashed ? 'border-amber-200 bg-amber-50 text-amber-700 hover:bg-amber-100' : 'border-neutral-200 bg-white text-neutral-700 hover:bg-neutral-50'}`}
                            >
                                <Trash2 className="size-4" />
                                <span>
                                    {showTrashed ? 'Kembali ke Data Aktif' : 'Lihat Sampah'}
                                </span>
                            </button>
                        </div>
                    </div>

                    {/* Right Column: Main News Table */}
                    <div className="space-y-6">
                        <div className="rounded-2xl border border-neutral-200/80 bg-white p-6 shadow-[0_1px_4px_rgba(0,0,0,0.03)] md:p-8">
                            <div className="overflow-x-auto">
                                <table className="w-full border-collapse text-left">
                                    <thead>
                                        <tr className="border-b border-neutral-100 text-xs font-bold tracking-wider text-neutral-400 uppercase">
                                            <th className="w-24 py-3 pl-3">
                                                Thumbnail
                                            </th>
                                            <th className="px-3 py-3">
                                                Judul Berita
                                            </th>
                                            <th className="w-32 px-3 py-3">
                                                Kategori
                                            </th>
                                            <th className="w-28 px-3 py-3">
                                                Status
                                            </th>
                                            <th className="w-24 py-3 pr-3 text-right">
                                                Aksi
                                            </th>
                                        </tr>
                                    </thead>
                                    <tbody className="divide-y divide-neutral-100 text-sm text-neutral-800">
                                        {currentItems.map((item) => (
                                            <tr
                                                key={item.id}
                                                className="group hover:bg-neutral-50/40"
                                            >
                                                {/* Thumbnail */}
                                                <td className="py-3 pl-3">
                                                    <div className="aspect-video w-20 overflow-hidden rounded-lg border border-neutral-200 bg-neutral-100">
                                                        <img
                                                            src={item.thumbnail}
                                                            alt=""
                                                            className="h-full w-full object-cover"
                                                        />
                                                    </div>
                                                </td>
                                                {/* Title */}
                                                <td className="px-3 py-3">
                                                    <div className="space-y-1">
                                                        <span className="line-clamp-2 leading-snug font-bold text-neutral-900 transition-colors group-hover:text-emerald-800">
                                                            {item.title}
                                                        </span>
                                                        <div className="flex items-center gap-4 text-xs font-medium text-neutral-400">
                                                            <span className="flex items-center gap-1">
                                                                <Calendar className="size-3" />
                                                                {item.date}
                                                            </span>
                                                            <span className="flex items-center gap-1">
                                                                <User className="size-3" />
                                                                {item.author ||
                                                                    'Admin'}
                                                            </span>
                                                        </div>
                                                    </div>
                                                </td>
                                                {/* Category Badge */}
                                                <td className="px-3 py-3">
                                                    <span
                                                        className={`inline-block rounded-full px-2.5 py-1 text-xs font-semibold ${
                                                            item.category ===
                                                            'Tanpa Kategori'
                                                                ? 'bg-neutral-100 text-neutral-600'
                                                                : 'border border-emerald-100 bg-emerald-50 text-emerald-800'
                                                        }`}
                                                    >
                                                        {item.category ||
                                                            'Tanpa Kategori'}
                                                    </span>
                                                </td>
                                                {/* Status Badge */}
                                                <td className="px-3 py-3">
                                                    <span
                                                        className={`inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-xs font-bold capitalize ${
                                                            item.status ===
                                                            'terpublikasi'
                                                                ? 'border border-green-200 bg-green-50 text-green-700'
                                                                : item.status ===
                                                                    'draf'
                                                                  ? 'border border-blue-200 bg-blue-50 text-blue-700'
                                                                  : 'border border-amber-200 bg-amber-50 text-amber-700'
                                                        }`}
                                                    >
                                                        <span
                                                            className={`size-1.5 rounded-full ${
                                                                item.status ===
                                                                'terpublikasi'
                                                                    ? 'bg-green-600'
                                                                    : item.status ===
                                                                        'draf'
                                                                      ? 'bg-blue-600'
                                                                      : 'bg-amber-600'
                                                            }`}
                                                        />
                                                        {item.status}
                                                    </span>
                                                </td>
                                                <td className="py-3 pr-3 text-right">
                                                    <div className="inline-flex items-center gap-1">
                                                        {!item.deleted_at ? (
                                                            <>
                                                                <a
                                                                    href={`/berita/${item.slug}`}
                                                                    target="_blank"
                                                                    rel="noopener noreferrer"
                                                                    className="rounded-lg p-2 text-neutral-500 hover:bg-neutral-100"
                                                                    title="Pratinjau Publik"
                                                                >
                                                                    <Eye className="size-4" />
                                                                </a>
                                                                <Link
                                                                    href={`/admin/berita/${item.id}/edit`}
                                                                    className="rounded-lg p-2 text-neutral-600 hover:bg-neutral-100"
                                                                    title="Edit Berita"
                                                                >
                                                                    <Edit2 className="size-4" />
                                                                </Link>
                                                            </>
                                                        ) : (
                                                            <button
                                                                type="button"
                                                                onClick={() => handleRestore(item.id)}
                                                                className="rounded-lg p-2 text-emerald-600 hover:bg-emerald-50"
                                                                title="Pulihkan Berita"
                                                            >
                                                                <AlertCircle className="size-4" />
                                                            </button>
                                                        )}
                                                        <button
                                                            type="button"
                                                            onClick={() =>
                                                                setDeletingNewsId(
                                                                    item.id,
                                                                )
                                                            }
                                                            className="rounded-lg p-2 text-red-600 hover:bg-red-50"
                                                            title={item.deleted_at ? 'Hapus Permanen' : 'Hapus Berita (Soft Delete)'}
                                                        >
                                                            <Trash2 className="size-4" />
                                                        </button>
                                                    </div>
                                                </td>
                                            </tr>
                                        ))}

                                        {filteredNews.length === 0 && (
                                            <tr>
                                                <td
                                                    colSpan={5}
                                                    className="py-16 text-center text-neutral-400"
                                                >
                                                    <Newspaper className="mx-auto mb-2 size-12 animate-pulse opacity-35" />
                                                    <p className="text-sm font-semibold">
                                                        Tidak ada berita yang
                                                        cocok dengan filter
                                                        filter saat ini.
                                                    </p>
                                                    <button
                                                        type="button"
                                                        onClick={() => {
                                                            setSearchQuery('');
                                                            setFilterCategory(
                                                                'Semua',
                                                            );
                                                            setFilterStatus(
                                                                'Semua',
                                                            );
                                                        }}
                                                        className="mt-2 text-xs font-bold text-emerald-600 hover:text-emerald-700"
                                                    >
                                                        Reset Filter
                                                    </button>
                                                </td>
                                            </tr>
                                        )}
                                    </tbody>
                                </table>
                            </div>

                            {/* Pagination Controls */}
                            {totalPages > 1 && (
                                <div className="mt-8 flex items-center justify-between border-t border-neutral-100 pt-6">
                                    <span className="text-xs font-semibold text-neutral-500">
                                        Menampilkan {indexOfFirstItem + 1}–
                                        {Math.min(
                                            indexOfLastItem,
                                            filteredNews.length,
                                        )}{' '}
                                        dari {filteredNews.length} berita
                                    </span>
                                    <div className="flex items-center gap-1">
                                        <button
                                            type="button"
                                            disabled={currentPage === 1}
                                            onClick={() =>
                                                setCurrentPage(
                                                    (prev) => prev - 1,
                                                )
                                            }
                                            className="rounded-lg border border-neutral-200 px-3 py-1.5 text-xs font-bold text-neutral-600 hover:bg-neutral-50 disabled:opacity-40"
                                        >
                                            Sebelumnya
                                        </button>
                                        {[...Array(totalPages)].map(
                                            (_, idx) => (
                                                <button
                                                    key={idx}
                                                    type="button"
                                                    onClick={() =>
                                                        setCurrentPage(idx + 1)
                                                    }
                                                    className={`rounded-lg px-3 py-1.5 text-xs font-bold ${
                                                        currentPage === idx + 1
                                                            ? 'bg-emerald-600 text-white'
                                                            : 'border border-neutral-200 text-neutral-600 hover:bg-neutral-50'
                                                    }`}
                                                >
                                                    {idx + 1}
                                                </button>
                                            ),
                                        )}
                                        <button
                                            type="button"
                                            disabled={
                                                currentPage === totalPages
                                            }
                                            onClick={() =>
                                                setCurrentPage(
                                                    (prev) => prev + 1,
                                                )
                                            }
                                            className="rounded-lg border border-neutral-200 px-3 py-1.5 text-xs font-bold text-neutral-600 hover:bg-neutral-50 disabled:opacity-40"
                                        >
                                            Selanjutnya
                                        </button>
                                    </div>
                                </div>
                            )}
                        </div>
                    </div>
                </div>
            </div>

            {/* Modal Box: Inline Category Manager */}
            {isCategoryModalOpen && (
                <div className="fixed inset-0 z-50 flex animate-in items-center justify-center bg-black/60 p-4 backdrop-blur-xs duration-200 fade-in">
                    <div className="relative w-full max-w-md animate-in rounded-2xl border border-neutral-200 bg-white p-6 shadow-2xl duration-200 zoom-in-95">
                        {/* Close button */}
                        <button
                            onClick={() => setIsCategoryModalOpen(false)}
                            className="absolute top-4 right-4 rounded-lg p-1.5 text-neutral-400 transition-colors hover:bg-neutral-100 hover:text-neutral-900"
                        >
                            <X className="size-5" />
                        </button>

                        <h3 className="mb-4 flex items-center gap-2 text-lg font-bold text-neutral-800">
                            <FolderOpen className="size-5 text-emerald-600" />
                            Kelola Kategori Berita
                        </h3>

                        {/* Add category form */}
                        <form
                            onSubmit={handleAddCategory}
                            className="mb-6 flex gap-2"
                        >
                            <input
                                type="text"
                                maxLength={50}
                                placeholder="Tulis kategori baru..."
                                value={newCategoryName}
                                onChange={(e) =>
                                    setNewCategoryName(e.target.value)
                                }
                                className="flex-1 rounded-xl border border-neutral-200 bg-white px-3.5 py-2 text-sm font-semibold text-neutral-800 transition-all outline-none focus:border-emerald-600 focus:ring-1 focus:ring-emerald-600"
                            />
                            <button
                                type="submit"
                                className="rounded-xl bg-emerald-600 px-4 py-2 text-xs font-bold text-white transition-colors hover:bg-emerald-700"
                            >
                                Tambah
                            </button>
                        </form>

                        {/* List of current categories with delete button */}
                        <div className="max-h-[220px] space-y-2 overflow-y-auto pr-1">
                            <label className="block text-xs font-bold tracking-wider text-neutral-400 uppercase">
                                Kategori Terdaftar
                            </label>
                            {categories.map((cat) => (
                                <div
                                    key={cat.id}
                                    className="flex items-center justify-between rounded-xl border border-neutral-200/50 bg-neutral-50 px-3.5 py-2"
                                >
                                    <span className="text-sm font-semibold text-neutral-800">
                                        {cat.nama}
                                    </span>
                                    <button
                                        type="button"
                                        onClick={() =>
                                            handleDeleteCategory(cat.id)
                                        }
                                        className="rounded-lg p-1 text-red-500 hover:bg-red-50"
                                        title="Hapus Kategori"
                                    >
                                        <Trash2 className="size-3.5" />
                                    </button>
                                </div>
                            ))}

                            {categories.length === 0 && (
                                <div className="py-6 text-center text-xs text-neutral-400">
                                    Belum ada kategori kustom.
                                </div>
                            )}
                        </div>

                        <div className="mt-6 flex justify-end border-t border-neutral-100 pt-4">
                            <button
                                type="button"
                                onClick={() => setIsCategoryModalOpen(false)}
                                className="rounded-xl border border-neutral-200 bg-white px-4 py-2 text-xs font-semibold text-neutral-600 transition-colors hover:bg-neutral-50"
                            >
                                Selesai
                            </button>
                        </div>
                    </div>
                </div>
            )}

            {/* Confirm dialog box for news deletion */}
            <ConfirmDialog
                isOpen={deletingNewsId !== null}
                onClose={() => setDeletingNewsId(null)}
                onConfirm={confirmDeleteNews}
                title={showTrashed ? "Hapus Permanen Berita?" : "Pindah ke Sampah?"}
                description={
                    <>
                        Apakah Anda yakin ingin {showTrashed ? 'menghapus permanen' : 'memindahkan'} berita "
                        <strong>
                            {beritas.find((b) => b.id === deletingNewsId)?.title}
                        </strong>
                        "? {showTrashed ? "Tindakan ini akan menghapus data selamanya." : "Tindakan ini akan memindahkan berita ke Sampah."}
                    </>
                }
                confirmText={showTrashed ? "Hapus Permanen" : "Pindah ke Sampah"}
                danger={true}
            />
        </>
    );
}

BeritaIndex.layout = {
    breadcrumbs: [
        {
            title: 'Dashboard',
            href: '/admin',
        },
        {
            title: 'Kelola Berita',
            href: '/admin/berita',
        },
    ],
};
