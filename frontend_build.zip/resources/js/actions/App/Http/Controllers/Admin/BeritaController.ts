import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\BeritaController::storeKategori
 * @see app/Http/Controllers/Admin/BeritaController.php:323
 * @route '/admin/berita/kategori'
 */
export const storeKategori = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeKategori.url(options),
    method: 'post',
})

storeKategori.definition = {
    methods: ["post"],
    url: '/admin/berita/kategori',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\BeritaController::storeKategori
 * @see app/Http/Controllers/Admin/BeritaController.php:323
 * @route '/admin/berita/kategori'
 */
storeKategori.url = (options?: RouteQueryOptions) => {
    return storeKategori.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\BeritaController::storeKategori
 * @see app/Http/Controllers/Admin/BeritaController.php:323
 * @route '/admin/berita/kategori'
 */
storeKategori.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeKategori.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\BeritaController::storeKategori
 * @see app/Http/Controllers/Admin/BeritaController.php:323
 * @route '/admin/berita/kategori'
 */
    const storeKategoriForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeKategori.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\BeritaController::storeKategori
 * @see app/Http/Controllers/Admin/BeritaController.php:323
 * @route '/admin/berita/kategori'
 */
        storeKategoriForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeKategori.url(options),
            method: 'post',
        })
    
    storeKategori.form = storeKategoriForm
/**
* @see \App\Http\Controllers\Admin\BeritaController::destroyKategori
 * @see app/Http/Controllers/Admin/BeritaController.php:341
 * @route '/admin/berita/kategori/{id}'
 */
export const destroyKategori = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyKategori.url(args, options),
    method: 'delete',
})

destroyKategori.definition = {
    methods: ["delete"],
    url: '/admin/berita/kategori/{id}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Admin\BeritaController::destroyKategori
 * @see app/Http/Controllers/Admin/BeritaController.php:341
 * @route '/admin/berita/kategori/{id}'
 */
destroyKategori.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    id: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        id: args.id,
                }

    return destroyKategori.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\BeritaController::destroyKategori
 * @see app/Http/Controllers/Admin/BeritaController.php:341
 * @route '/admin/berita/kategori/{id}'
 */
destroyKategori.delete = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyKategori.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Admin\BeritaController::destroyKategori
 * @see app/Http/Controllers/Admin/BeritaController.php:341
 * @route '/admin/berita/kategori/{id}'
 */
    const destroyKategoriForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroyKategori.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\BeritaController::destroyKategori
 * @see app/Http/Controllers/Admin/BeritaController.php:341
 * @route '/admin/berita/kategori/{id}'
 */
        destroyKategoriForm.delete = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroyKategori.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroyKategori.form = destroyKategoriForm
/**
* @see \App\Http\Controllers\Admin\BeritaController::restore
 * @see app/Http/Controllers/Admin/BeritaController.php:309
 * @route '/admin/berita/{id}/restore'
 */
export const restore = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: restore.url(args, options),
    method: 'post',
})

restore.definition = {
    methods: ["post"],
    url: '/admin/berita/{id}/restore',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\BeritaController::restore
 * @see app/Http/Controllers/Admin/BeritaController.php:309
 * @route '/admin/berita/{id}/restore'
 */
restore.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    id: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        id: args.id,
                }

    return restore.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\BeritaController::restore
 * @see app/Http/Controllers/Admin/BeritaController.php:309
 * @route '/admin/berita/{id}/restore'
 */
restore.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: restore.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\BeritaController::restore
 * @see app/Http/Controllers/Admin/BeritaController.php:309
 * @route '/admin/berita/{id}/restore'
 */
    const restoreForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: restore.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\BeritaController::restore
 * @see app/Http/Controllers/Admin/BeritaController.php:309
 * @route '/admin/berita/{id}/restore'
 */
        restoreForm.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: restore.url(args, options),
            method: 'post',
        })
    
    restore.form = restoreForm
/**
* @see \App\Http\Controllers\Admin\BeritaController::index
 * @see app/Http/Controllers/Admin/BeritaController.php:21
 * @route '/admin/berita'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/berita',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\BeritaController::index
 * @see app/Http/Controllers/Admin/BeritaController.php:21
 * @route '/admin/berita'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\BeritaController::index
 * @see app/Http/Controllers/Admin/BeritaController.php:21
 * @route '/admin/berita'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\BeritaController::index
 * @see app/Http/Controllers/Admin/BeritaController.php:21
 * @route '/admin/berita'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\BeritaController::index
 * @see app/Http/Controllers/Admin/BeritaController.php:21
 * @route '/admin/berita'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\BeritaController::index
 * @see app/Http/Controllers/Admin/BeritaController.php:21
 * @route '/admin/berita'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\BeritaController::index
 * @see app/Http/Controllers/Admin/BeritaController.php:21
 * @route '/admin/berita'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Admin\BeritaController::create
 * @see app/Http/Controllers/Admin/BeritaController.php:78
 * @route '/admin/berita/create'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/admin/berita/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\BeritaController::create
 * @see app/Http/Controllers/Admin/BeritaController.php:78
 * @route '/admin/berita/create'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\BeritaController::create
 * @see app/Http/Controllers/Admin/BeritaController.php:78
 * @route '/admin/berita/create'
 */
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\BeritaController::create
 * @see app/Http/Controllers/Admin/BeritaController.php:78
 * @route '/admin/berita/create'
 */
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\BeritaController::create
 * @see app/Http/Controllers/Admin/BeritaController.php:78
 * @route '/admin/berita/create'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\BeritaController::create
 * @see app/Http/Controllers/Admin/BeritaController.php:78
 * @route '/admin/berita/create'
 */
        createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\BeritaController::create
 * @see app/Http/Controllers/Admin/BeritaController.php:78
 * @route '/admin/berita/create'
 */
        createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\Admin\BeritaController::store
 * @see app/Http/Controllers/Admin/BeritaController.php:110
 * @route '/admin/berita'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/berita',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\BeritaController::store
 * @see app/Http/Controllers/Admin/BeritaController.php:110
 * @route '/admin/berita'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\BeritaController::store
 * @see app/Http/Controllers/Admin/BeritaController.php:110
 * @route '/admin/berita'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\BeritaController::store
 * @see app/Http/Controllers/Admin/BeritaController.php:110
 * @route '/admin/berita'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\BeritaController::store
 * @see app/Http/Controllers/Admin/BeritaController.php:110
 * @route '/admin/berita'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Admin\BeritaController::show
 * @see app/Http/Controllers/Admin/BeritaController.php:0
 * @route '/admin/berita/{beritum}'
 */
export const show = (args: { beritum: string | number } | [beritum: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/admin/berita/{beritum}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\BeritaController::show
 * @see app/Http/Controllers/Admin/BeritaController.php:0
 * @route '/admin/berita/{beritum}'
 */
show.url = (args: { beritum: string | number } | [beritum: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { beritum: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    beritum: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        beritum: args.beritum,
                }

    return show.definition.url
            .replace('{beritum}', parsedArgs.beritum.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\BeritaController::show
 * @see app/Http/Controllers/Admin/BeritaController.php:0
 * @route '/admin/berita/{beritum}'
 */
show.get = (args: { beritum: string | number } | [beritum: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\BeritaController::show
 * @see app/Http/Controllers/Admin/BeritaController.php:0
 * @route '/admin/berita/{beritum}'
 */
show.head = (args: { beritum: string | number } | [beritum: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\BeritaController::show
 * @see app/Http/Controllers/Admin/BeritaController.php:0
 * @route '/admin/berita/{beritum}'
 */
    const showForm = (args: { beritum: string | number } | [beritum: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\BeritaController::show
 * @see app/Http/Controllers/Admin/BeritaController.php:0
 * @route '/admin/berita/{beritum}'
 */
        showForm.get = (args: { beritum: string | number } | [beritum: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\BeritaController::show
 * @see app/Http/Controllers/Admin/BeritaController.php:0
 * @route '/admin/berita/{beritum}'
 */
        showForm.head = (args: { beritum: string | number } | [beritum: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Admin\BeritaController::edit
 * @see app/Http/Controllers/Admin/BeritaController.php:170
 * @route '/admin/berita/{beritum}/edit'
 */
export const edit = (args: { beritum: string | number } | [beritum: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/admin/berita/{beritum}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\BeritaController::edit
 * @see app/Http/Controllers/Admin/BeritaController.php:170
 * @route '/admin/berita/{beritum}/edit'
 */
edit.url = (args: { beritum: string | number } | [beritum: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { beritum: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    beritum: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        beritum: args.beritum,
                }

    return edit.definition.url
            .replace('{beritum}', parsedArgs.beritum.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\BeritaController::edit
 * @see app/Http/Controllers/Admin/BeritaController.php:170
 * @route '/admin/berita/{beritum}/edit'
 */
edit.get = (args: { beritum: string | number } | [beritum: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\BeritaController::edit
 * @see app/Http/Controllers/Admin/BeritaController.php:170
 * @route '/admin/berita/{beritum}/edit'
 */
edit.head = (args: { beritum: string | number } | [beritum: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\BeritaController::edit
 * @see app/Http/Controllers/Admin/BeritaController.php:170
 * @route '/admin/berita/{beritum}/edit'
 */
    const editForm = (args: { beritum: string | number } | [beritum: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\BeritaController::edit
 * @see app/Http/Controllers/Admin/BeritaController.php:170
 * @route '/admin/berita/{beritum}/edit'
 */
        editForm.get = (args: { beritum: string | number } | [beritum: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\BeritaController::edit
 * @see app/Http/Controllers/Admin/BeritaController.php:170
 * @route '/admin/berita/{beritum}/edit'
 */
        editForm.head = (args: { beritum: string | number } | [beritum: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\Admin\BeritaController::update
 * @see app/Http/Controllers/Admin/BeritaController.php:217
 * @route '/admin/berita/{beritum}'
 */
export const update = (args: { beritum: string | number } | [beritum: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/admin/berita/{beritum}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\Admin\BeritaController::update
 * @see app/Http/Controllers/Admin/BeritaController.php:217
 * @route '/admin/berita/{beritum}'
 */
update.url = (args: { beritum: string | number } | [beritum: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { beritum: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    beritum: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        beritum: args.beritum,
                }

    return update.definition.url
            .replace('{beritum}', parsedArgs.beritum.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\BeritaController::update
 * @see app/Http/Controllers/Admin/BeritaController.php:217
 * @route '/admin/berita/{beritum}'
 */
update.put = (args: { beritum: string | number } | [beritum: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\Admin\BeritaController::update
 * @see app/Http/Controllers/Admin/BeritaController.php:217
 * @route '/admin/berita/{beritum}'
 */
update.patch = (args: { beritum: string | number } | [beritum: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Admin\BeritaController::update
 * @see app/Http/Controllers/Admin/BeritaController.php:217
 * @route '/admin/berita/{beritum}'
 */
    const updateForm = (args: { beritum: string | number } | [beritum: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\BeritaController::update
 * @see app/Http/Controllers/Admin/BeritaController.php:217
 * @route '/admin/berita/{beritum}'
 */
        updateForm.put = (args: { beritum: string | number } | [beritum: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\Admin\BeritaController::update
 * @see app/Http/Controllers/Admin/BeritaController.php:217
 * @route '/admin/berita/{beritum}'
 */
        updateForm.patch = (args: { beritum: string | number } | [beritum: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Admin\BeritaController::destroy
 * @see app/Http/Controllers/Admin/BeritaController.php:282
 * @route '/admin/berita/{beritum}'
 */
export const destroy = (args: { beritum: string | number } | [beritum: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/berita/{beritum}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Admin\BeritaController::destroy
 * @see app/Http/Controllers/Admin/BeritaController.php:282
 * @route '/admin/berita/{beritum}'
 */
destroy.url = (args: { beritum: string | number } | [beritum: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { beritum: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    beritum: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        beritum: args.beritum,
                }

    return destroy.definition.url
            .replace('{beritum}', parsedArgs.beritum.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\BeritaController::destroy
 * @see app/Http/Controllers/Admin/BeritaController.php:282
 * @route '/admin/berita/{beritum}'
 */
destroy.delete = (args: { beritum: string | number } | [beritum: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Admin\BeritaController::destroy
 * @see app/Http/Controllers/Admin/BeritaController.php:282
 * @route '/admin/berita/{beritum}'
 */
    const destroyForm = (args: { beritum: string | number } | [beritum: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\BeritaController::destroy
 * @see app/Http/Controllers/Admin/BeritaController.php:282
 * @route '/admin/berita/{beritum}'
 */
        destroyForm.delete = (args: { beritum: string | number } | [beritum: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const BeritaController = { storeKategori, destroyKategori, restore, index, create, store, show, edit, update, destroy }

export default BeritaController