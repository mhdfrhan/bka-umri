import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\AsetController::apiList
 * @see app/Http/Controllers/Admin/AsetController.php:124
 * @route '/admin/aset/pilihan'
 */
export const apiList = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: apiList.url(options),
    method: 'get',
})

apiList.definition = {
    methods: ["get","head"],
    url: '/admin/aset/pilihan',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\AsetController::apiList
 * @see app/Http/Controllers/Admin/AsetController.php:124
 * @route '/admin/aset/pilihan'
 */
apiList.url = (options?: RouteQueryOptions) => {
    return apiList.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AsetController::apiList
 * @see app/Http/Controllers/Admin/AsetController.php:124
 * @route '/admin/aset/pilihan'
 */
apiList.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: apiList.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\AsetController::apiList
 * @see app/Http/Controllers/Admin/AsetController.php:124
 * @route '/admin/aset/pilihan'
 */
apiList.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: apiList.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\AsetController::apiList
 * @see app/Http/Controllers/Admin/AsetController.php:124
 * @route '/admin/aset/pilihan'
 */
    const apiListForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: apiList.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\AsetController::apiList
 * @see app/Http/Controllers/Admin/AsetController.php:124
 * @route '/admin/aset/pilihan'
 */
        apiListForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: apiList.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\AsetController::apiList
 * @see app/Http/Controllers/Admin/AsetController.php:124
 * @route '/admin/aset/pilihan'
 */
        apiListForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: apiList.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    apiList.form = apiListForm
/**
* @see \App\Http\Controllers\Admin\AsetController::editorUpload
 * @see app/Http/Controllers/Admin/AsetController.php:145
 * @route '/admin/editor-upload'
 */
export const editorUpload = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: editorUpload.url(options),
    method: 'post',
})

editorUpload.definition = {
    methods: ["post"],
    url: '/admin/editor-upload',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\AsetController::editorUpload
 * @see app/Http/Controllers/Admin/AsetController.php:145
 * @route '/admin/editor-upload'
 */
editorUpload.url = (options?: RouteQueryOptions) => {
    return editorUpload.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AsetController::editorUpload
 * @see app/Http/Controllers/Admin/AsetController.php:145
 * @route '/admin/editor-upload'
 */
editorUpload.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: editorUpload.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\AsetController::editorUpload
 * @see app/Http/Controllers/Admin/AsetController.php:145
 * @route '/admin/editor-upload'
 */
    const editorUploadForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: editorUpload.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AsetController::editorUpload
 * @see app/Http/Controllers/Admin/AsetController.php:145
 * @route '/admin/editor-upload'
 */
        editorUploadForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: editorUpload.url(options),
            method: 'post',
        })
    
    editorUpload.form = editorUploadForm
/**
* @see \App\Http\Controllers\Admin\AsetController::editorImageDelete
 * @see app/Http/Controllers/Admin/AsetController.php:187
 * @route '/admin/editor-image'
 */
export const editorImageDelete = (options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: editorImageDelete.url(options),
    method: 'delete',
})

editorImageDelete.definition = {
    methods: ["delete"],
    url: '/admin/editor-image',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Admin\AsetController::editorImageDelete
 * @see app/Http/Controllers/Admin/AsetController.php:187
 * @route '/admin/editor-image'
 */
editorImageDelete.url = (options?: RouteQueryOptions) => {
    return editorImageDelete.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AsetController::editorImageDelete
 * @see app/Http/Controllers/Admin/AsetController.php:187
 * @route '/admin/editor-image'
 */
editorImageDelete.delete = (options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: editorImageDelete.url(options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Admin\AsetController::editorImageDelete
 * @see app/Http/Controllers/Admin/AsetController.php:187
 * @route '/admin/editor-image'
 */
    const editorImageDeleteForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: editorImageDelete.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AsetController::editorImageDelete
 * @see app/Http/Controllers/Admin/AsetController.php:187
 * @route '/admin/editor-image'
 */
        editorImageDeleteForm.delete = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: editorImageDelete.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    editorImageDelete.form = editorImageDeleteForm
/**
* @see \App\Http\Controllers\Admin\AsetController::index
 * @see app/Http/Controllers/Admin/AsetController.php:18
 * @route '/admin/aset'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/aset',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\AsetController::index
 * @see app/Http/Controllers/Admin/AsetController.php:18
 * @route '/admin/aset'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AsetController::index
 * @see app/Http/Controllers/Admin/AsetController.php:18
 * @route '/admin/aset'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\AsetController::index
 * @see app/Http/Controllers/Admin/AsetController.php:18
 * @route '/admin/aset'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\AsetController::index
 * @see app/Http/Controllers/Admin/AsetController.php:18
 * @route '/admin/aset'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\AsetController::index
 * @see app/Http/Controllers/Admin/AsetController.php:18
 * @route '/admin/aset'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\AsetController::index
 * @see app/Http/Controllers/Admin/AsetController.php:18
 * @route '/admin/aset'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Admin\AsetController::create
 * @see app/Http/Controllers/Admin/AsetController.php:0
 * @route '/admin/aset/create'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/admin/aset/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\AsetController::create
 * @see app/Http/Controllers/Admin/AsetController.php:0
 * @route '/admin/aset/create'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AsetController::create
 * @see app/Http/Controllers/Admin/AsetController.php:0
 * @route '/admin/aset/create'
 */
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\AsetController::create
 * @see app/Http/Controllers/Admin/AsetController.php:0
 * @route '/admin/aset/create'
 */
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\AsetController::create
 * @see app/Http/Controllers/Admin/AsetController.php:0
 * @route '/admin/aset/create'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\AsetController::create
 * @see app/Http/Controllers/Admin/AsetController.php:0
 * @route '/admin/aset/create'
 */
        createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\AsetController::create
 * @see app/Http/Controllers/Admin/AsetController.php:0
 * @route '/admin/aset/create'
 */
        createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\Admin\AsetController::store
 * @see app/Http/Controllers/Admin/AsetController.php:51
 * @route '/admin/aset'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/aset',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\AsetController::store
 * @see app/Http/Controllers/Admin/AsetController.php:51
 * @route '/admin/aset'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AsetController::store
 * @see app/Http/Controllers/Admin/AsetController.php:51
 * @route '/admin/aset'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\AsetController::store
 * @see app/Http/Controllers/Admin/AsetController.php:51
 * @route '/admin/aset'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AsetController::store
 * @see app/Http/Controllers/Admin/AsetController.php:51
 * @route '/admin/aset'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Admin\AsetController::show
 * @see app/Http/Controllers/Admin/AsetController.php:0
 * @route '/admin/aset/{aset}'
 */
export const show = (args: { aset: string | number } | [aset: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/admin/aset/{aset}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\AsetController::show
 * @see app/Http/Controllers/Admin/AsetController.php:0
 * @route '/admin/aset/{aset}'
 */
show.url = (args: { aset: string | number } | [aset: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { aset: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    aset: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        aset: args.aset,
                }

    return show.definition.url
            .replace('{aset}', parsedArgs.aset.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AsetController::show
 * @see app/Http/Controllers/Admin/AsetController.php:0
 * @route '/admin/aset/{aset}'
 */
show.get = (args: { aset: string | number } | [aset: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\AsetController::show
 * @see app/Http/Controllers/Admin/AsetController.php:0
 * @route '/admin/aset/{aset}'
 */
show.head = (args: { aset: string | number } | [aset: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\AsetController::show
 * @see app/Http/Controllers/Admin/AsetController.php:0
 * @route '/admin/aset/{aset}'
 */
    const showForm = (args: { aset: string | number } | [aset: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\AsetController::show
 * @see app/Http/Controllers/Admin/AsetController.php:0
 * @route '/admin/aset/{aset}'
 */
        showForm.get = (args: { aset: string | number } | [aset: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\AsetController::show
 * @see app/Http/Controllers/Admin/AsetController.php:0
 * @route '/admin/aset/{aset}'
 */
        showForm.head = (args: { aset: string | number } | [aset: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Admin\AsetController::edit
 * @see app/Http/Controllers/Admin/AsetController.php:0
 * @route '/admin/aset/{aset}/edit'
 */
export const edit = (args: { aset: string | number } | [aset: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/admin/aset/{aset}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\AsetController::edit
 * @see app/Http/Controllers/Admin/AsetController.php:0
 * @route '/admin/aset/{aset}/edit'
 */
edit.url = (args: { aset: string | number } | [aset: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { aset: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    aset: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        aset: args.aset,
                }

    return edit.definition.url
            .replace('{aset}', parsedArgs.aset.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AsetController::edit
 * @see app/Http/Controllers/Admin/AsetController.php:0
 * @route '/admin/aset/{aset}/edit'
 */
edit.get = (args: { aset: string | number } | [aset: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\AsetController::edit
 * @see app/Http/Controllers/Admin/AsetController.php:0
 * @route '/admin/aset/{aset}/edit'
 */
edit.head = (args: { aset: string | number } | [aset: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\AsetController::edit
 * @see app/Http/Controllers/Admin/AsetController.php:0
 * @route '/admin/aset/{aset}/edit'
 */
    const editForm = (args: { aset: string | number } | [aset: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\AsetController::edit
 * @see app/Http/Controllers/Admin/AsetController.php:0
 * @route '/admin/aset/{aset}/edit'
 */
        editForm.get = (args: { aset: string | number } | [aset: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\AsetController::edit
 * @see app/Http/Controllers/Admin/AsetController.php:0
 * @route '/admin/aset/{aset}/edit'
 */
        editForm.head = (args: { aset: string | number } | [aset: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\Admin\AsetController::update
 * @see app/Http/Controllers/Admin/AsetController.php:93
 * @route '/admin/aset/{aset}'
 */
export const update = (args: { aset: string | number } | [aset: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/admin/aset/{aset}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\Admin\AsetController::update
 * @see app/Http/Controllers/Admin/AsetController.php:93
 * @route '/admin/aset/{aset}'
 */
update.url = (args: { aset: string | number } | [aset: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { aset: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    aset: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        aset: args.aset,
                }

    return update.definition.url
            .replace('{aset}', parsedArgs.aset.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AsetController::update
 * @see app/Http/Controllers/Admin/AsetController.php:93
 * @route '/admin/aset/{aset}'
 */
update.put = (args: { aset: string | number } | [aset: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\Admin\AsetController::update
 * @see app/Http/Controllers/Admin/AsetController.php:93
 * @route '/admin/aset/{aset}'
 */
update.patch = (args: { aset: string | number } | [aset: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Admin\AsetController::update
 * @see app/Http/Controllers/Admin/AsetController.php:93
 * @route '/admin/aset/{aset}'
 */
    const updateForm = (args: { aset: string | number } | [aset: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AsetController::update
 * @see app/Http/Controllers/Admin/AsetController.php:93
 * @route '/admin/aset/{aset}'
 */
        updateForm.put = (args: { aset: string | number } | [aset: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\Admin\AsetController::update
 * @see app/Http/Controllers/Admin/AsetController.php:93
 * @route '/admin/aset/{aset}'
 */
        updateForm.patch = (args: { aset: string | number } | [aset: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Admin\AsetController::destroy
 * @see app/Http/Controllers/Admin/AsetController.php:113
 * @route '/admin/aset/{aset}'
 */
export const destroy = (args: { aset: string | number } | [aset: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/aset/{aset}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Admin\AsetController::destroy
 * @see app/Http/Controllers/Admin/AsetController.php:113
 * @route '/admin/aset/{aset}'
 */
destroy.url = (args: { aset: string | number } | [aset: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { aset: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    aset: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        aset: args.aset,
                }

    return destroy.definition.url
            .replace('{aset}', parsedArgs.aset.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AsetController::destroy
 * @see app/Http/Controllers/Admin/AsetController.php:113
 * @route '/admin/aset/{aset}'
 */
destroy.delete = (args: { aset: string | number } | [aset: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Admin\AsetController::destroy
 * @see app/Http/Controllers/Admin/AsetController.php:113
 * @route '/admin/aset/{aset}'
 */
    const destroyForm = (args: { aset: string | number } | [aset: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AsetController::destroy
 * @see app/Http/Controllers/Admin/AsetController.php:113
 * @route '/admin/aset/{aset}'
 */
        destroyForm.delete = (args: { aset: string | number } | [aset: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const AsetController = { apiList, editorUpload, editorImageDelete, index, create, store, show, edit, update, destroy }

export default AsetController