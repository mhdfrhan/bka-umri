import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\BerandaController::edit
 * @see app/Http/Controllers/Admin/BerandaController.php:23
 * @route '/admin/beranda'
 */
export const edit = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/admin/beranda',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\BerandaController::edit
 * @see app/Http/Controllers/Admin/BerandaController.php:23
 * @route '/admin/beranda'
 */
edit.url = (options?: RouteQueryOptions) => {
    return edit.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\BerandaController::edit
 * @see app/Http/Controllers/Admin/BerandaController.php:23
 * @route '/admin/beranda'
 */
edit.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\BerandaController::edit
 * @see app/Http/Controllers/Admin/BerandaController.php:23
 * @route '/admin/beranda'
 */
edit.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\BerandaController::edit
 * @see app/Http/Controllers/Admin/BerandaController.php:23
 * @route '/admin/beranda'
 */
    const editForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\BerandaController::edit
 * @see app/Http/Controllers/Admin/BerandaController.php:23
 * @route '/admin/beranda'
 */
        editForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\BerandaController::edit
 * @see app/Http/Controllers/Admin/BerandaController.php:23
 * @route '/admin/beranda'
 */
        editForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\Admin\BerandaController::storeBanner
 * @see app/Http/Controllers/Admin/BerandaController.php:91
 * @route '/admin/beranda/banners'
 */
export const storeBanner = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeBanner.url(options),
    method: 'post',
})

storeBanner.definition = {
    methods: ["post"],
    url: '/admin/beranda/banners',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\BerandaController::storeBanner
 * @see app/Http/Controllers/Admin/BerandaController.php:91
 * @route '/admin/beranda/banners'
 */
storeBanner.url = (options?: RouteQueryOptions) => {
    return storeBanner.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\BerandaController::storeBanner
 * @see app/Http/Controllers/Admin/BerandaController.php:91
 * @route '/admin/beranda/banners'
 */
storeBanner.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeBanner.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\BerandaController::storeBanner
 * @see app/Http/Controllers/Admin/BerandaController.php:91
 * @route '/admin/beranda/banners'
 */
    const storeBannerForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeBanner.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\BerandaController::storeBanner
 * @see app/Http/Controllers/Admin/BerandaController.php:91
 * @route '/admin/beranda/banners'
 */
        storeBannerForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeBanner.url(options),
            method: 'post',
        })
    
    storeBanner.form = storeBannerForm
/**
* @see \App\Http\Controllers\Admin\BerandaController::updateBanner
 * @see app/Http/Controllers/Admin/BerandaController.php:129
 * @route '/admin/beranda/banners/{id}'
 */
export const updateBanner = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateBanner.url(args, options),
    method: 'put',
})

updateBanner.definition = {
    methods: ["put"],
    url: '/admin/beranda/banners/{id}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Admin\BerandaController::updateBanner
 * @see app/Http/Controllers/Admin/BerandaController.php:129
 * @route '/admin/beranda/banners/{id}'
 */
updateBanner.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    id: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        id: args.id,
                }

    return updateBanner.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\BerandaController::updateBanner
 * @see app/Http/Controllers/Admin/BerandaController.php:129
 * @route '/admin/beranda/banners/{id}'
 */
updateBanner.put = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateBanner.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Admin\BerandaController::updateBanner
 * @see app/Http/Controllers/Admin/BerandaController.php:129
 * @route '/admin/beranda/banners/{id}'
 */
    const updateBannerForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateBanner.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\BerandaController::updateBanner
 * @see app/Http/Controllers/Admin/BerandaController.php:129
 * @route '/admin/beranda/banners/{id}'
 */
        updateBannerForm.put = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateBanner.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateBanner.form = updateBannerForm
/**
* @see \App\Http\Controllers\Admin\BerandaController::destroyBanner
 * @see app/Http/Controllers/Admin/BerandaController.php:167
 * @route '/admin/beranda/banners/{id}'
 */
export const destroyBanner = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyBanner.url(args, options),
    method: 'delete',
})

destroyBanner.definition = {
    methods: ["delete"],
    url: '/admin/beranda/banners/{id}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Admin\BerandaController::destroyBanner
 * @see app/Http/Controllers/Admin/BerandaController.php:167
 * @route '/admin/beranda/banners/{id}'
 */
destroyBanner.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    id: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        id: args.id,
                }

    return destroyBanner.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\BerandaController::destroyBanner
 * @see app/Http/Controllers/Admin/BerandaController.php:167
 * @route '/admin/beranda/banners/{id}'
 */
destroyBanner.delete = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyBanner.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Admin\BerandaController::destroyBanner
 * @see app/Http/Controllers/Admin/BerandaController.php:167
 * @route '/admin/beranda/banners/{id}'
 */
    const destroyBannerForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroyBanner.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\BerandaController::destroyBanner
 * @see app/Http/Controllers/Admin/BerandaController.php:167
 * @route '/admin/beranda/banners/{id}'
 */
        destroyBannerForm.delete = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroyBanner.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroyBanner.form = destroyBannerForm
/**
* @see \App\Http\Controllers\Admin\BerandaController::toggleBanner
 * @see app/Http/Controllers/Admin/BerandaController.php:189
 * @route '/admin/beranda/banners/{id}/toggle'
 */
export const toggleBanner = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: toggleBanner.url(args, options),
    method: 'patch',
})

toggleBanner.definition = {
    methods: ["patch"],
    url: '/admin/beranda/banners/{id}/toggle',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Admin\BerandaController::toggleBanner
 * @see app/Http/Controllers/Admin/BerandaController.php:189
 * @route '/admin/beranda/banners/{id}/toggle'
 */
toggleBanner.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    id: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        id: args.id,
                }

    return toggleBanner.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\BerandaController::toggleBanner
 * @see app/Http/Controllers/Admin/BerandaController.php:189
 * @route '/admin/beranda/banners/{id}/toggle'
 */
toggleBanner.patch = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: toggleBanner.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Admin\BerandaController::toggleBanner
 * @see app/Http/Controllers/Admin/BerandaController.php:189
 * @route '/admin/beranda/banners/{id}/toggle'
 */
    const toggleBannerForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: toggleBanner.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\BerandaController::toggleBanner
 * @see app/Http/Controllers/Admin/BerandaController.php:189
 * @route '/admin/beranda/banners/{id}/toggle'
 */
        toggleBannerForm.patch = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: toggleBanner.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    toggleBanner.form = toggleBannerForm
/**
* @see \App\Http\Controllers\Admin\BerandaController::reorderBanners
 * @see app/Http/Controllers/Admin/BerandaController.php:202
 * @route '/admin/beranda/banners/reorder'
 */
export const reorderBanners = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reorderBanners.url(options),
    method: 'post',
})

reorderBanners.definition = {
    methods: ["post"],
    url: '/admin/beranda/banners/reorder',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\BerandaController::reorderBanners
 * @see app/Http/Controllers/Admin/BerandaController.php:202
 * @route '/admin/beranda/banners/reorder'
 */
reorderBanners.url = (options?: RouteQueryOptions) => {
    return reorderBanners.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\BerandaController::reorderBanners
 * @see app/Http/Controllers/Admin/BerandaController.php:202
 * @route '/admin/beranda/banners/reorder'
 */
reorderBanners.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reorderBanners.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\BerandaController::reorderBanners
 * @see app/Http/Controllers/Admin/BerandaController.php:202
 * @route '/admin/beranda/banners/reorder'
 */
    const reorderBannersForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: reorderBanners.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\BerandaController::reorderBanners
 * @see app/Http/Controllers/Admin/BerandaController.php:202
 * @route '/admin/beranda/banners/reorder'
 */
        reorderBannersForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: reorderBanners.url(options),
            method: 'post',
        })
    
    reorderBanners.form = reorderBannersForm
/**
* @see \App\Http\Controllers\Admin\BerandaController::updateKepalaBiro
 * @see app/Http/Controllers/Admin/BerandaController.php:221
 * @route '/admin/beranda/kepala-biro'
 */
export const updateKepalaBiro = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateKepalaBiro.url(options),
    method: 'put',
})

updateKepalaBiro.definition = {
    methods: ["put"],
    url: '/admin/beranda/kepala-biro',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Admin\BerandaController::updateKepalaBiro
 * @see app/Http/Controllers/Admin/BerandaController.php:221
 * @route '/admin/beranda/kepala-biro'
 */
updateKepalaBiro.url = (options?: RouteQueryOptions) => {
    return updateKepalaBiro.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\BerandaController::updateKepalaBiro
 * @see app/Http/Controllers/Admin/BerandaController.php:221
 * @route '/admin/beranda/kepala-biro'
 */
updateKepalaBiro.put = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateKepalaBiro.url(options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Admin\BerandaController::updateKepalaBiro
 * @see app/Http/Controllers/Admin/BerandaController.php:221
 * @route '/admin/beranda/kepala-biro'
 */
    const updateKepalaBiroForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateKepalaBiro.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\BerandaController::updateKepalaBiro
 * @see app/Http/Controllers/Admin/BerandaController.php:221
 * @route '/admin/beranda/kepala-biro'
 */
        updateKepalaBiroForm.put = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateKepalaBiro.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateKepalaBiro.form = updateKepalaBiroForm
/**
* @see \App\Http\Controllers\Admin\BerandaController::updateStatistik
 * @see app/Http/Controllers/Admin/BerandaController.php:262
 * @route '/admin/beranda/statistik'
 */
export const updateStatistik = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateStatistik.url(options),
    method: 'put',
})

updateStatistik.definition = {
    methods: ["put"],
    url: '/admin/beranda/statistik',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Admin\BerandaController::updateStatistik
 * @see app/Http/Controllers/Admin/BerandaController.php:262
 * @route '/admin/beranda/statistik'
 */
updateStatistik.url = (options?: RouteQueryOptions) => {
    return updateStatistik.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\BerandaController::updateStatistik
 * @see app/Http/Controllers/Admin/BerandaController.php:262
 * @route '/admin/beranda/statistik'
 */
updateStatistik.put = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateStatistik.url(options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Admin\BerandaController::updateStatistik
 * @see app/Http/Controllers/Admin/BerandaController.php:262
 * @route '/admin/beranda/statistik'
 */
    const updateStatistikForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateStatistik.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\BerandaController::updateStatistik
 * @see app/Http/Controllers/Admin/BerandaController.php:262
 * @route '/admin/beranda/statistik'
 */
        updateStatistikForm.put = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateStatistik.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateStatistik.form = updateStatistikForm
/**
* @see \App\Http\Controllers\Admin\BerandaController::updateLayanan
 * @see app/Http/Controllers/Admin/BerandaController.php:301
 * @route '/admin/beranda/layanan'
 */
export const updateLayanan = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateLayanan.url(options),
    method: 'put',
})

updateLayanan.definition = {
    methods: ["put"],
    url: '/admin/beranda/layanan',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Admin\BerandaController::updateLayanan
 * @see app/Http/Controllers/Admin/BerandaController.php:301
 * @route '/admin/beranda/layanan'
 */
updateLayanan.url = (options?: RouteQueryOptions) => {
    return updateLayanan.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\BerandaController::updateLayanan
 * @see app/Http/Controllers/Admin/BerandaController.php:301
 * @route '/admin/beranda/layanan'
 */
updateLayanan.put = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateLayanan.url(options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Admin\BerandaController::updateLayanan
 * @see app/Http/Controllers/Admin/BerandaController.php:301
 * @route '/admin/beranda/layanan'
 */
    const updateLayananForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateLayanan.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\BerandaController::updateLayanan
 * @see app/Http/Controllers/Admin/BerandaController.php:301
 * @route '/admin/beranda/layanan'
 */
        updateLayananForm.put = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateLayanan.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateLayanan.form = updateLayananForm
const BerandaController = { edit, storeBanner, updateBanner, destroyBanner, toggleBanner, reorderBanners, updateKepalaBiro, updateStatistik, updateLayanan }

export default BerandaController