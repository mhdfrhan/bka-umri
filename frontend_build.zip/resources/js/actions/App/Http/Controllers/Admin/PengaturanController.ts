import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\PengaturanController::index
 * @see app/Http/Controllers/Admin/PengaturanController.php:20
 * @route '/admin/settings'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/settings',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\PengaturanController::index
 * @see app/Http/Controllers/Admin/PengaturanController.php:20
 * @route '/admin/settings'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\PengaturanController::index
 * @see app/Http/Controllers/Admin/PengaturanController.php:20
 * @route '/admin/settings'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\PengaturanController::index
 * @see app/Http/Controllers/Admin/PengaturanController.php:20
 * @route '/admin/settings'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\PengaturanController::index
 * @see app/Http/Controllers/Admin/PengaturanController.php:20
 * @route '/admin/settings'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\PengaturanController::index
 * @see app/Http/Controllers/Admin/PengaturanController.php:20
 * @route '/admin/settings'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\PengaturanController::index
 * @see app/Http/Controllers/Admin/PengaturanController.php:20
 * @route '/admin/settings'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Admin\PengaturanController::updateSettings
 * @see app/Http/Controllers/Admin/PengaturanController.php:76
 * @route '/admin/settings'
 */
export const updateSettings = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: updateSettings.url(options),
    method: 'post',
})

updateSettings.definition = {
    methods: ["post"],
    url: '/admin/settings',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\PengaturanController::updateSettings
 * @see app/Http/Controllers/Admin/PengaturanController.php:76
 * @route '/admin/settings'
 */
updateSettings.url = (options?: RouteQueryOptions) => {
    return updateSettings.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\PengaturanController::updateSettings
 * @see app/Http/Controllers/Admin/PengaturanController.php:76
 * @route '/admin/settings'
 */
updateSettings.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: updateSettings.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\PengaturanController::updateSettings
 * @see app/Http/Controllers/Admin/PengaturanController.php:76
 * @route '/admin/settings'
 */
    const updateSettingsForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateSettings.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\PengaturanController::updateSettings
 * @see app/Http/Controllers/Admin/PengaturanController.php:76
 * @route '/admin/settings'
 */
        updateSettingsForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateSettings.url(options),
            method: 'post',
        })
    
    updateSettings.form = updateSettingsForm
/**
* @see \App\Http\Controllers\Admin\PengaturanController::toggleRead
 * @see app/Http/Controllers/Admin/PengaturanController.php:168
 * @route '/admin/settings/inbox/{id}/toggle-read'
 */
export const toggleRead = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: toggleRead.url(args, options),
    method: 'post',
})

toggleRead.definition = {
    methods: ["post"],
    url: '/admin/settings/inbox/{id}/toggle-read',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\PengaturanController::toggleRead
 * @see app/Http/Controllers/Admin/PengaturanController.php:168
 * @route '/admin/settings/inbox/{id}/toggle-read'
 */
toggleRead.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    id: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        id: args.id,
                }

    return toggleRead.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\PengaturanController::toggleRead
 * @see app/Http/Controllers/Admin/PengaturanController.php:168
 * @route '/admin/settings/inbox/{id}/toggle-read'
 */
toggleRead.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: toggleRead.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\PengaturanController::toggleRead
 * @see app/Http/Controllers/Admin/PengaturanController.php:168
 * @route '/admin/settings/inbox/{id}/toggle-read'
 */
    const toggleReadForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: toggleRead.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\PengaturanController::toggleRead
 * @see app/Http/Controllers/Admin/PengaturanController.php:168
 * @route '/admin/settings/inbox/{id}/toggle-read'
 */
        toggleReadForm.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: toggleRead.url(args, options),
            method: 'post',
        })
    
    toggleRead.form = toggleReadForm
/**
* @see \App\Http\Controllers\Admin\PengaturanController::destroyMessage
 * @see app/Http/Controllers/Admin/PengaturanController.php:184
 * @route '/admin/settings/inbox/{id}'
 */
export const destroyMessage = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyMessage.url(args, options),
    method: 'delete',
})

destroyMessage.definition = {
    methods: ["delete"],
    url: '/admin/settings/inbox/{id}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Admin\PengaturanController::destroyMessage
 * @see app/Http/Controllers/Admin/PengaturanController.php:184
 * @route '/admin/settings/inbox/{id}'
 */
destroyMessage.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    id: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        id: args.id,
                }

    return destroyMessage.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\PengaturanController::destroyMessage
 * @see app/Http/Controllers/Admin/PengaturanController.php:184
 * @route '/admin/settings/inbox/{id}'
 */
destroyMessage.delete = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyMessage.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Admin\PengaturanController::destroyMessage
 * @see app/Http/Controllers/Admin/PengaturanController.php:184
 * @route '/admin/settings/inbox/{id}'
 */
    const destroyMessageForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroyMessage.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\PengaturanController::destroyMessage
 * @see app/Http/Controllers/Admin/PengaturanController.php:184
 * @route '/admin/settings/inbox/{id}'
 */
        destroyMessageForm.delete = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroyMessage.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroyMessage.form = destroyMessageForm
const PengaturanController = { index, updateSettings, toggleRead, destroyMessage }

export default PengaturanController