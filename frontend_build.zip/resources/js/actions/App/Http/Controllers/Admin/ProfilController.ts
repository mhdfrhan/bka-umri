import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\ProfilController::editTentang
 * @see app/Http/Controllers/Admin/ProfilController.php:23
 * @route '/admin/profil/tentang'
 */
export const editTentang = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: editTentang.url(options),
    method: 'get',
})

editTentang.definition = {
    methods: ["get","head"],
    url: '/admin/profil/tentang',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\ProfilController::editTentang
 * @see app/Http/Controllers/Admin/ProfilController.php:23
 * @route '/admin/profil/tentang'
 */
editTentang.url = (options?: RouteQueryOptions) => {
    return editTentang.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\ProfilController::editTentang
 * @see app/Http/Controllers/Admin/ProfilController.php:23
 * @route '/admin/profil/tentang'
 */
editTentang.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: editTentang.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\ProfilController::editTentang
 * @see app/Http/Controllers/Admin/ProfilController.php:23
 * @route '/admin/profil/tentang'
 */
editTentang.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: editTentang.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\ProfilController::editTentang
 * @see app/Http/Controllers/Admin/ProfilController.php:23
 * @route '/admin/profil/tentang'
 */
    const editTentangForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: editTentang.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\ProfilController::editTentang
 * @see app/Http/Controllers/Admin/ProfilController.php:23
 * @route '/admin/profil/tentang'
 */
        editTentangForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: editTentang.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\ProfilController::editTentang
 * @see app/Http/Controllers/Admin/ProfilController.php:23
 * @route '/admin/profil/tentang'
 */
        editTentangForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: editTentang.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    editTentang.form = editTentangForm
/**
* @see \App\Http\Controllers\Admin\ProfilController::updateTentang
 * @see app/Http/Controllers/Admin/ProfilController.php:41
 * @route '/admin/profil/tentang'
 */
export const updateTentang = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateTentang.url(options),
    method: 'put',
})

updateTentang.definition = {
    methods: ["put"],
    url: '/admin/profil/tentang',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Admin\ProfilController::updateTentang
 * @see app/Http/Controllers/Admin/ProfilController.php:41
 * @route '/admin/profil/tentang'
 */
updateTentang.url = (options?: RouteQueryOptions) => {
    return updateTentang.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\ProfilController::updateTentang
 * @see app/Http/Controllers/Admin/ProfilController.php:41
 * @route '/admin/profil/tentang'
 */
updateTentang.put = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateTentang.url(options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Admin\ProfilController::updateTentang
 * @see app/Http/Controllers/Admin/ProfilController.php:41
 * @route '/admin/profil/tentang'
 */
    const updateTentangForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateTentang.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\ProfilController::updateTentang
 * @see app/Http/Controllers/Admin/ProfilController.php:41
 * @route '/admin/profil/tentang'
 */
        updateTentangForm.put = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateTentang.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateTentang.form = updateTentangForm
/**
* @see \App\Http\Controllers\Admin\ProfilController::editVisiMisi
 * @see app/Http/Controllers/Admin/ProfilController.php:61
 * @route '/admin/profil/visi-misi'
 */
export const editVisiMisi = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: editVisiMisi.url(options),
    method: 'get',
})

editVisiMisi.definition = {
    methods: ["get","head"],
    url: '/admin/profil/visi-misi',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\ProfilController::editVisiMisi
 * @see app/Http/Controllers/Admin/ProfilController.php:61
 * @route '/admin/profil/visi-misi'
 */
editVisiMisi.url = (options?: RouteQueryOptions) => {
    return editVisiMisi.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\ProfilController::editVisiMisi
 * @see app/Http/Controllers/Admin/ProfilController.php:61
 * @route '/admin/profil/visi-misi'
 */
editVisiMisi.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: editVisiMisi.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\ProfilController::editVisiMisi
 * @see app/Http/Controllers/Admin/ProfilController.php:61
 * @route '/admin/profil/visi-misi'
 */
editVisiMisi.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: editVisiMisi.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\ProfilController::editVisiMisi
 * @see app/Http/Controllers/Admin/ProfilController.php:61
 * @route '/admin/profil/visi-misi'
 */
    const editVisiMisiForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: editVisiMisi.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\ProfilController::editVisiMisi
 * @see app/Http/Controllers/Admin/ProfilController.php:61
 * @route '/admin/profil/visi-misi'
 */
        editVisiMisiForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: editVisiMisi.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\ProfilController::editVisiMisi
 * @see app/Http/Controllers/Admin/ProfilController.php:61
 * @route '/admin/profil/visi-misi'
 */
        editVisiMisiForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: editVisiMisi.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    editVisiMisi.form = editVisiMisiForm
/**
* @see \App\Http\Controllers\Admin\ProfilController::updateVisiMisi
 * @see app/Http/Controllers/Admin/ProfilController.php:82
 * @route '/admin/profil/visi-misi'
 */
export const updateVisiMisi = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateVisiMisi.url(options),
    method: 'put',
})

updateVisiMisi.definition = {
    methods: ["put"],
    url: '/admin/profil/visi-misi',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Admin\ProfilController::updateVisiMisi
 * @see app/Http/Controllers/Admin/ProfilController.php:82
 * @route '/admin/profil/visi-misi'
 */
updateVisiMisi.url = (options?: RouteQueryOptions) => {
    return updateVisiMisi.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\ProfilController::updateVisiMisi
 * @see app/Http/Controllers/Admin/ProfilController.php:82
 * @route '/admin/profil/visi-misi'
 */
updateVisiMisi.put = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateVisiMisi.url(options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Admin\ProfilController::updateVisiMisi
 * @see app/Http/Controllers/Admin/ProfilController.php:82
 * @route '/admin/profil/visi-misi'
 */
    const updateVisiMisiForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateVisiMisi.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\ProfilController::updateVisiMisi
 * @see app/Http/Controllers/Admin/ProfilController.php:82
 * @route '/admin/profil/visi-misi'
 */
        updateVisiMisiForm.put = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateVisiMisi.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateVisiMisi.form = updateVisiMisiForm
/**
* @see \App\Http\Controllers\Admin\ProfilController::editStruktur
 * @see app/Http/Controllers/Admin/ProfilController.php:126
 * @route '/admin/profil/struktur'
 */
export const editStruktur = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: editStruktur.url(options),
    method: 'get',
})

editStruktur.definition = {
    methods: ["get","head"],
    url: '/admin/profil/struktur',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\ProfilController::editStruktur
 * @see app/Http/Controllers/Admin/ProfilController.php:126
 * @route '/admin/profil/struktur'
 */
editStruktur.url = (options?: RouteQueryOptions) => {
    return editStruktur.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\ProfilController::editStruktur
 * @see app/Http/Controllers/Admin/ProfilController.php:126
 * @route '/admin/profil/struktur'
 */
editStruktur.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: editStruktur.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\ProfilController::editStruktur
 * @see app/Http/Controllers/Admin/ProfilController.php:126
 * @route '/admin/profil/struktur'
 */
editStruktur.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: editStruktur.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\ProfilController::editStruktur
 * @see app/Http/Controllers/Admin/ProfilController.php:126
 * @route '/admin/profil/struktur'
 */
    const editStrukturForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: editStruktur.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\ProfilController::editStruktur
 * @see app/Http/Controllers/Admin/ProfilController.php:126
 * @route '/admin/profil/struktur'
 */
        editStrukturForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: editStruktur.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\ProfilController::editStruktur
 * @see app/Http/Controllers/Admin/ProfilController.php:126
 * @route '/admin/profil/struktur'
 */
        editStrukturForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: editStruktur.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    editStruktur.form = editStrukturForm
/**
* @see \App\Http\Controllers\Admin\ProfilController::updateStruktur
 * @see app/Http/Controllers/Admin/ProfilController.php:151
 * @route '/admin/profil/struktur'
 */
export const updateStruktur = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateStruktur.url(options),
    method: 'put',
})

updateStruktur.definition = {
    methods: ["put"],
    url: '/admin/profil/struktur',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Admin\ProfilController::updateStruktur
 * @see app/Http/Controllers/Admin/ProfilController.php:151
 * @route '/admin/profil/struktur'
 */
updateStruktur.url = (options?: RouteQueryOptions) => {
    return updateStruktur.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\ProfilController::updateStruktur
 * @see app/Http/Controllers/Admin/ProfilController.php:151
 * @route '/admin/profil/struktur'
 */
updateStruktur.put = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateStruktur.url(options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Admin\ProfilController::updateStruktur
 * @see app/Http/Controllers/Admin/ProfilController.php:151
 * @route '/admin/profil/struktur'
 */
    const updateStrukturForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateStruktur.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\ProfilController::updateStruktur
 * @see app/Http/Controllers/Admin/ProfilController.php:151
 * @route '/admin/profil/struktur'
 */
        updateStrukturForm.put = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateStruktur.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateStruktur.form = updateStrukturForm
const ProfilController = { editTentang, updateTentang, editVisiMisi, updateVisiMisi, editStruktur, updateStruktur }

export default ProfilController