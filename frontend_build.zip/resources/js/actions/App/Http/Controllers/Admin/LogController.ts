import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\LogController::index
 * @see app/Http/Controllers/Admin/LogController.php:17
 * @route '/admin/logs'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/logs',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\LogController::index
 * @see app/Http/Controllers/Admin/LogController.php:17
 * @route '/admin/logs'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\LogController::index
 * @see app/Http/Controllers/Admin/LogController.php:17
 * @route '/admin/logs'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\LogController::index
 * @see app/Http/Controllers/Admin/LogController.php:17
 * @route '/admin/logs'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\LogController::index
 * @see app/Http/Controllers/Admin/LogController.php:17
 * @route '/admin/logs'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\LogController::index
 * @see app/Http/Controllers/Admin/LogController.php:17
 * @route '/admin/logs'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\LogController::index
 * @see app/Http/Controllers/Admin/LogController.php:17
 * @route '/admin/logs'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Admin\LogController::seed
 * @see app/Http/Controllers/Admin/LogController.php:143
 * @route '/admin/logs/seed'
 */
export const seed = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: seed.url(options),
    method: 'post',
})

seed.definition = {
    methods: ["post"],
    url: '/admin/logs/seed',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\LogController::seed
 * @see app/Http/Controllers/Admin/LogController.php:143
 * @route '/admin/logs/seed'
 */
seed.url = (options?: RouteQueryOptions) => {
    return seed.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\LogController::seed
 * @see app/Http/Controllers/Admin/LogController.php:143
 * @route '/admin/logs/seed'
 */
seed.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: seed.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\LogController::seed
 * @see app/Http/Controllers/Admin/LogController.php:143
 * @route '/admin/logs/seed'
 */
    const seedForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: seed.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\LogController::seed
 * @see app/Http/Controllers/Admin/LogController.php:143
 * @route '/admin/logs/seed'
 */
        seedForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: seed.url(options),
            method: 'post',
        })
    
    seed.form = seedForm
/**
* @see \App\Http\Controllers\Admin\LogController::destroyAll
 * @see app/Http/Controllers/Admin/LogController.php:133
 * @route '/admin/logs'
 */
export const destroyAll = (options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyAll.url(options),
    method: 'delete',
})

destroyAll.definition = {
    methods: ["delete"],
    url: '/admin/logs',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Admin\LogController::destroyAll
 * @see app/Http/Controllers/Admin/LogController.php:133
 * @route '/admin/logs'
 */
destroyAll.url = (options?: RouteQueryOptions) => {
    return destroyAll.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\LogController::destroyAll
 * @see app/Http/Controllers/Admin/LogController.php:133
 * @route '/admin/logs'
 */
destroyAll.delete = (options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyAll.url(options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Admin\LogController::destroyAll
 * @see app/Http/Controllers/Admin/LogController.php:133
 * @route '/admin/logs'
 */
    const destroyAllForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroyAll.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\LogController::destroyAll
 * @see app/Http/Controllers/Admin/LogController.php:133
 * @route '/admin/logs'
 */
        destroyAllForm.delete = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroyAll.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroyAll.form = destroyAllForm
const LogController = { index, seed, destroyAll }

export default LogController