import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\ChatbotSettingController::index
 * @see app/Http/Controllers/Admin/ChatbotSettingController.php:19
 * @route '/admin/chatbot'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/chatbot',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\ChatbotSettingController::index
 * @see app/Http/Controllers/Admin/ChatbotSettingController.php:19
 * @route '/admin/chatbot'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\ChatbotSettingController::index
 * @see app/Http/Controllers/Admin/ChatbotSettingController.php:19
 * @route '/admin/chatbot'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\ChatbotSettingController::index
 * @see app/Http/Controllers/Admin/ChatbotSettingController.php:19
 * @route '/admin/chatbot'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\ChatbotSettingController::index
 * @see app/Http/Controllers/Admin/ChatbotSettingController.php:19
 * @route '/admin/chatbot'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\ChatbotSettingController::index
 * @see app/Http/Controllers/Admin/ChatbotSettingController.php:19
 * @route '/admin/chatbot'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\ChatbotSettingController::index
 * @see app/Http/Controllers/Admin/ChatbotSettingController.php:19
 * @route '/admin/chatbot'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Admin\ChatbotSettingController::updateSettings
 * @see app/Http/Controllers/Admin/ChatbotSettingController.php:50
 * @route '/admin/chatbot/settings'
 */
export const updateSettings = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: updateSettings.url(options),
    method: 'post',
})

updateSettings.definition = {
    methods: ["post"],
    url: '/admin/chatbot/settings',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\ChatbotSettingController::updateSettings
 * @see app/Http/Controllers/Admin/ChatbotSettingController.php:50
 * @route '/admin/chatbot/settings'
 */
updateSettings.url = (options?: RouteQueryOptions) => {
    return updateSettings.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\ChatbotSettingController::updateSettings
 * @see app/Http/Controllers/Admin/ChatbotSettingController.php:50
 * @route '/admin/chatbot/settings'
 */
updateSettings.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: updateSettings.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\ChatbotSettingController::updateSettings
 * @see app/Http/Controllers/Admin/ChatbotSettingController.php:50
 * @route '/admin/chatbot/settings'
 */
    const updateSettingsForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateSettings.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\ChatbotSettingController::updateSettings
 * @see app/Http/Controllers/Admin/ChatbotSettingController.php:50
 * @route '/admin/chatbot/settings'
 */
        updateSettingsForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateSettings.url(options),
            method: 'post',
        })
    
    updateSettings.form = updateSettingsForm
/**
* @see \App\Http\Controllers\Admin\ChatbotSettingController::testConnection
 * @see app/Http/Controllers/Admin/ChatbotSettingController.php:98
 * @route '/admin/chatbot/test'
 */
export const testConnection = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: testConnection.url(options),
    method: 'post',
})

testConnection.definition = {
    methods: ["post"],
    url: '/admin/chatbot/test',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\ChatbotSettingController::testConnection
 * @see app/Http/Controllers/Admin/ChatbotSettingController.php:98
 * @route '/admin/chatbot/test'
 */
testConnection.url = (options?: RouteQueryOptions) => {
    return testConnection.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\ChatbotSettingController::testConnection
 * @see app/Http/Controllers/Admin/ChatbotSettingController.php:98
 * @route '/admin/chatbot/test'
 */
testConnection.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: testConnection.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\ChatbotSettingController::testConnection
 * @see app/Http/Controllers/Admin/ChatbotSettingController.php:98
 * @route '/admin/chatbot/test'
 */
    const testConnectionForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: testConnection.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\ChatbotSettingController::testConnection
 * @see app/Http/Controllers/Admin/ChatbotSettingController.php:98
 * @route '/admin/chatbot/test'
 */
        testConnectionForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: testConnection.url(options),
            method: 'post',
        })
    
    testConnection.form = testConnectionForm
const ChatbotSettingController = { index, updateSettings, testConnection }

export default ChatbotSettingController