import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\DokumenController::index
 * @see app/Http/Controllers/Admin/DokumenController.php:18
 * @route '/admin/dokumen'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/dokumen',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\DokumenController::index
 * @see app/Http/Controllers/Admin/DokumenController.php:18
 * @route '/admin/dokumen'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\DokumenController::index
 * @see app/Http/Controllers/Admin/DokumenController.php:18
 * @route '/admin/dokumen'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\DokumenController::index
 * @see app/Http/Controllers/Admin/DokumenController.php:18
 * @route '/admin/dokumen'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\DokumenController::index
 * @see app/Http/Controllers/Admin/DokumenController.php:18
 * @route '/admin/dokumen'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\DokumenController::index
 * @see app/Http/Controllers/Admin/DokumenController.php:18
 * @route '/admin/dokumen'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\DokumenController::index
 * @see app/Http/Controllers/Admin/DokumenController.php:18
 * @route '/admin/dokumen'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Admin\DokumenController::restoreKategori
 * @see app/Http/Controllers/Admin/DokumenController.php:145
 * @route '/admin/dokumen/kategori/{id}/restore'
 */
export const restoreKategori = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: restoreKategori.url(args, options),
    method: 'post',
})

restoreKategori.definition = {
    methods: ["post"],
    url: '/admin/dokumen/kategori/{id}/restore',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\DokumenController::restoreKategori
 * @see app/Http/Controllers/Admin/DokumenController.php:145
 * @route '/admin/dokumen/kategori/{id}/restore'
 */
restoreKategori.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    id: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        id: args.id,
                }

    return restoreKategori.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\DokumenController::restoreKategori
 * @see app/Http/Controllers/Admin/DokumenController.php:145
 * @route '/admin/dokumen/kategori/{id}/restore'
 */
restoreKategori.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: restoreKategori.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\DokumenController::restoreKategori
 * @see app/Http/Controllers/Admin/DokumenController.php:145
 * @route '/admin/dokumen/kategori/{id}/restore'
 */
    const restoreKategoriForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: restoreKategori.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\DokumenController::restoreKategori
 * @see app/Http/Controllers/Admin/DokumenController.php:145
 * @route '/admin/dokumen/kategori/{id}/restore'
 */
        restoreKategoriForm.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: restoreKategori.url(args, options),
            method: 'post',
        })
    
    restoreKategori.form = restoreKategoriForm
/**
* @see \App\Http\Controllers\Admin\DokumenController::storeKategori
 * @see app/Http/Controllers/Admin/DokumenController.php:65
 * @route '/admin/dokumen/kategori'
 */
export const storeKategori = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeKategori.url(options),
    method: 'post',
})

storeKategori.definition = {
    methods: ["post"],
    url: '/admin/dokumen/kategori',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\DokumenController::storeKategori
 * @see app/Http/Controllers/Admin/DokumenController.php:65
 * @route '/admin/dokumen/kategori'
 */
storeKategori.url = (options?: RouteQueryOptions) => {
    return storeKategori.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\DokumenController::storeKategori
 * @see app/Http/Controllers/Admin/DokumenController.php:65
 * @route '/admin/dokumen/kategori'
 */
storeKategori.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeKategori.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\DokumenController::storeKategori
 * @see app/Http/Controllers/Admin/DokumenController.php:65
 * @route '/admin/dokumen/kategori'
 */
    const storeKategoriForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeKategori.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\DokumenController::storeKategori
 * @see app/Http/Controllers/Admin/DokumenController.php:65
 * @route '/admin/dokumen/kategori'
 */
        storeKategoriForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeKategori.url(options),
            method: 'post',
        })
    
    storeKategori.form = storeKategoriForm
/**
* @see \App\Http\Controllers\Admin\DokumenController::updateKategori
 * @see app/Http/Controllers/Admin/DokumenController.php:91
 * @route '/admin/dokumen/kategori/{id}'
 */
export const updateKategori = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateKategori.url(args, options),
    method: 'put',
})

updateKategori.definition = {
    methods: ["put"],
    url: '/admin/dokumen/kategori/{id}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Admin\DokumenController::updateKategori
 * @see app/Http/Controllers/Admin/DokumenController.php:91
 * @route '/admin/dokumen/kategori/{id}'
 */
updateKategori.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    id: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        id: args.id,
                }

    return updateKategori.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\DokumenController::updateKategori
 * @see app/Http/Controllers/Admin/DokumenController.php:91
 * @route '/admin/dokumen/kategori/{id}'
 */
updateKategori.put = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateKategori.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Admin\DokumenController::updateKategori
 * @see app/Http/Controllers/Admin/DokumenController.php:91
 * @route '/admin/dokumen/kategori/{id}'
 */
    const updateKategoriForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateKategori.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\DokumenController::updateKategori
 * @see app/Http/Controllers/Admin/DokumenController.php:91
 * @route '/admin/dokumen/kategori/{id}'
 */
        updateKategoriForm.put = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateKategori.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateKategori.form = updateKategoriForm
/**
* @see \App\Http\Controllers\Admin\DokumenController::destroyKategori
 * @see app/Http/Controllers/Admin/DokumenController.php:116
 * @route '/admin/dokumen/kategori/{id}'
 */
export const destroyKategori = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyKategori.url(args, options),
    method: 'delete',
})

destroyKategori.definition = {
    methods: ["delete"],
    url: '/admin/dokumen/kategori/{id}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Admin\DokumenController::destroyKategori
 * @see app/Http/Controllers/Admin/DokumenController.php:116
 * @route '/admin/dokumen/kategori/{id}'
 */
destroyKategori.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    id: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        id: args.id,
                }

    return destroyKategori.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\DokumenController::destroyKategori
 * @see app/Http/Controllers/Admin/DokumenController.php:116
 * @route '/admin/dokumen/kategori/{id}'
 */
destroyKategori.delete = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyKategori.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Admin\DokumenController::destroyKategori
 * @see app/Http/Controllers/Admin/DokumenController.php:116
 * @route '/admin/dokumen/kategori/{id}'
 */
    const destroyKategoriForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroyKategori.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\DokumenController::destroyKategori
 * @see app/Http/Controllers/Admin/DokumenController.php:116
 * @route '/admin/dokumen/kategori/{id}'
 */
        destroyKategoriForm.delete = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroyKategori.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroyKategori.form = destroyKategoriForm
/**
* @see \App\Http\Controllers\Admin\DokumenController::reorderKategori
 * @see app/Http/Controllers/Admin/DokumenController.php:163
 * @route '/admin/dokumen/kategori/reorder'
 */
export const reorderKategori = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reorderKategori.url(options),
    method: 'post',
})

reorderKategori.definition = {
    methods: ["post"],
    url: '/admin/dokumen/kategori/reorder',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\DokumenController::reorderKategori
 * @see app/Http/Controllers/Admin/DokumenController.php:163
 * @route '/admin/dokumen/kategori/reorder'
 */
reorderKategori.url = (options?: RouteQueryOptions) => {
    return reorderKategori.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\DokumenController::reorderKategori
 * @see app/Http/Controllers/Admin/DokumenController.php:163
 * @route '/admin/dokumen/kategori/reorder'
 */
reorderKategori.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reorderKategori.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\DokumenController::reorderKategori
 * @see app/Http/Controllers/Admin/DokumenController.php:163
 * @route '/admin/dokumen/kategori/reorder'
 */
    const reorderKategoriForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: reorderKategori.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\DokumenController::reorderKategori
 * @see app/Http/Controllers/Admin/DokumenController.php:163
 * @route '/admin/dokumen/kategori/reorder'
 */
        reorderKategoriForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: reorderKategori.url(options),
            method: 'post',
        })
    
    reorderKategori.form = reorderKategoriForm
/**
* @see \App\Http\Controllers\Admin\DokumenController::reorderBerkas
 * @see app/Http/Controllers/Admin/DokumenController.php:185
 * @route '/admin/dokumen/berkas/reorder'
 */
export const reorderBerkas = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reorderBerkas.url(options),
    method: 'post',
})

reorderBerkas.definition = {
    methods: ["post"],
    url: '/admin/dokumen/berkas/reorder',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\DokumenController::reorderBerkas
 * @see app/Http/Controllers/Admin/DokumenController.php:185
 * @route '/admin/dokumen/berkas/reorder'
 */
reorderBerkas.url = (options?: RouteQueryOptions) => {
    return reorderBerkas.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\DokumenController::reorderBerkas
 * @see app/Http/Controllers/Admin/DokumenController.php:185
 * @route '/admin/dokumen/berkas/reorder'
 */
reorderBerkas.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reorderBerkas.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\DokumenController::reorderBerkas
 * @see app/Http/Controllers/Admin/DokumenController.php:185
 * @route '/admin/dokumen/berkas/reorder'
 */
    const reorderBerkasForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: reorderBerkas.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\DokumenController::reorderBerkas
 * @see app/Http/Controllers/Admin/DokumenController.php:185
 * @route '/admin/dokumen/berkas/reorder'
 */
        reorderBerkasForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: reorderBerkas.url(options),
            method: 'post',
        })
    
    reorderBerkas.form = reorderBerkasForm
/**
* @see \App\Http\Controllers\Admin\DokumenController::reorderUnified
 * @see app/Http/Controllers/Admin/DokumenController.php:204
 * @route '/admin/dokumen/berkas/reorder-unified'
 */
export const reorderUnified = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reorderUnified.url(options),
    method: 'post',
})

reorderUnified.definition = {
    methods: ["post"],
    url: '/admin/dokumen/berkas/reorder-unified',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\DokumenController::reorderUnified
 * @see app/Http/Controllers/Admin/DokumenController.php:204
 * @route '/admin/dokumen/berkas/reorder-unified'
 */
reorderUnified.url = (options?: RouteQueryOptions) => {
    return reorderUnified.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\DokumenController::reorderUnified
 * @see app/Http/Controllers/Admin/DokumenController.php:204
 * @route '/admin/dokumen/berkas/reorder-unified'
 */
reorderUnified.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reorderUnified.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\DokumenController::reorderUnified
 * @see app/Http/Controllers/Admin/DokumenController.php:204
 * @route '/admin/dokumen/berkas/reorder-unified'
 */
    const reorderUnifiedForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: reorderUnified.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\DokumenController::reorderUnified
 * @see app/Http/Controllers/Admin/DokumenController.php:204
 * @route '/admin/dokumen/berkas/reorder-unified'
 */
        reorderUnifiedForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: reorderUnified.url(options),
            method: 'post',
        })
    
    reorderUnified.form = reorderUnifiedForm
/**
* @see \App\Http\Controllers\Admin\DokumenController::restoreBerkas
 * @see app/Http/Controllers/Admin/DokumenController.php:444
 * @route '/admin/dokumen/berkas/{id}/restore'
 */
export const restoreBerkas = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: restoreBerkas.url(args, options),
    method: 'post',
})

restoreBerkas.definition = {
    methods: ["post"],
    url: '/admin/dokumen/berkas/{id}/restore',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\DokumenController::restoreBerkas
 * @see app/Http/Controllers/Admin/DokumenController.php:444
 * @route '/admin/dokumen/berkas/{id}/restore'
 */
restoreBerkas.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    id: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        id: args.id,
                }

    return restoreBerkas.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\DokumenController::restoreBerkas
 * @see app/Http/Controllers/Admin/DokumenController.php:444
 * @route '/admin/dokumen/berkas/{id}/restore'
 */
restoreBerkas.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: restoreBerkas.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\DokumenController::restoreBerkas
 * @see app/Http/Controllers/Admin/DokumenController.php:444
 * @route '/admin/dokumen/berkas/{id}/restore'
 */
    const restoreBerkasForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: restoreBerkas.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\DokumenController::restoreBerkas
 * @see app/Http/Controllers/Admin/DokumenController.php:444
 * @route '/admin/dokumen/berkas/{id}/restore'
 */
        restoreBerkasForm.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: restoreBerkas.url(args, options),
            method: 'post',
        })
    
    restoreBerkas.form = restoreBerkasForm
/**
* @see \App\Http\Controllers\Admin\DokumenController::storeBerkas
 * @see app/Http/Controllers/Admin/DokumenController.php:231
 * @route '/admin/dokumen/berkas'
 */
export const storeBerkas = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeBerkas.url(options),
    method: 'post',
})

storeBerkas.definition = {
    methods: ["post"],
    url: '/admin/dokumen/berkas',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\DokumenController::storeBerkas
 * @see app/Http/Controllers/Admin/DokumenController.php:231
 * @route '/admin/dokumen/berkas'
 */
storeBerkas.url = (options?: RouteQueryOptions) => {
    return storeBerkas.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\DokumenController::storeBerkas
 * @see app/Http/Controllers/Admin/DokumenController.php:231
 * @route '/admin/dokumen/berkas'
 */
storeBerkas.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeBerkas.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\DokumenController::storeBerkas
 * @see app/Http/Controllers/Admin/DokumenController.php:231
 * @route '/admin/dokumen/berkas'
 */
    const storeBerkasForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeBerkas.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\DokumenController::storeBerkas
 * @see app/Http/Controllers/Admin/DokumenController.php:231
 * @route '/admin/dokumen/berkas'
 */
        storeBerkasForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeBerkas.url(options),
            method: 'post',
        })
    
    storeBerkas.form = storeBerkasForm
/**
* @see \App\Http\Controllers\Admin\DokumenController::storeMultipleBerkas
 * @see app/Http/Controllers/Admin/DokumenController.php:303
 * @route '/admin/dokumen/berkas/multiple'
 */
export const storeMultipleBerkas = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeMultipleBerkas.url(options),
    method: 'post',
})

storeMultipleBerkas.definition = {
    methods: ["post"],
    url: '/admin/dokumen/berkas/multiple',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\DokumenController::storeMultipleBerkas
 * @see app/Http/Controllers/Admin/DokumenController.php:303
 * @route '/admin/dokumen/berkas/multiple'
 */
storeMultipleBerkas.url = (options?: RouteQueryOptions) => {
    return storeMultipleBerkas.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\DokumenController::storeMultipleBerkas
 * @see app/Http/Controllers/Admin/DokumenController.php:303
 * @route '/admin/dokumen/berkas/multiple'
 */
storeMultipleBerkas.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeMultipleBerkas.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\DokumenController::storeMultipleBerkas
 * @see app/Http/Controllers/Admin/DokumenController.php:303
 * @route '/admin/dokumen/berkas/multiple'
 */
    const storeMultipleBerkasForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeMultipleBerkas.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\DokumenController::storeMultipleBerkas
 * @see app/Http/Controllers/Admin/DokumenController.php:303
 * @route '/admin/dokumen/berkas/multiple'
 */
        storeMultipleBerkasForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeMultipleBerkas.url(options),
            method: 'post',
        })
    
    storeMultipleBerkas.form = storeMultipleBerkasForm
/**
* @see \App\Http\Controllers\Admin\DokumenController::updateBerkas
 * @see app/Http/Controllers/Admin/DokumenController.php:355
 * @route '/admin/dokumen/berkas/{id}'
 */
export const updateBerkas = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateBerkas.url(args, options),
    method: 'put',
})

updateBerkas.definition = {
    methods: ["put"],
    url: '/admin/dokumen/berkas/{id}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Admin\DokumenController::updateBerkas
 * @see app/Http/Controllers/Admin/DokumenController.php:355
 * @route '/admin/dokumen/berkas/{id}'
 */
updateBerkas.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    id: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        id: args.id,
                }

    return updateBerkas.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\DokumenController::updateBerkas
 * @see app/Http/Controllers/Admin/DokumenController.php:355
 * @route '/admin/dokumen/berkas/{id}'
 */
updateBerkas.put = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateBerkas.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Admin\DokumenController::updateBerkas
 * @see app/Http/Controllers/Admin/DokumenController.php:355
 * @route '/admin/dokumen/berkas/{id}'
 */
    const updateBerkasForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateBerkas.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\DokumenController::updateBerkas
 * @see app/Http/Controllers/Admin/DokumenController.php:355
 * @route '/admin/dokumen/berkas/{id}'
 */
        updateBerkasForm.put = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateBerkas.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateBerkas.form = updateBerkasForm
/**
* @see \App\Http\Controllers\Admin\DokumenController::destroyBerkas
 * @see app/Http/Controllers/Admin/DokumenController.php:423
 * @route '/admin/dokumen/berkas/{id}'
 */
export const destroyBerkas = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyBerkas.url(args, options),
    method: 'delete',
})

destroyBerkas.definition = {
    methods: ["delete"],
    url: '/admin/dokumen/berkas/{id}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Admin\DokumenController::destroyBerkas
 * @see app/Http/Controllers/Admin/DokumenController.php:423
 * @route '/admin/dokumen/berkas/{id}'
 */
destroyBerkas.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    id: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        id: args.id,
                }

    return destroyBerkas.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\DokumenController::destroyBerkas
 * @see app/Http/Controllers/Admin/DokumenController.php:423
 * @route '/admin/dokumen/berkas/{id}'
 */
destroyBerkas.delete = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyBerkas.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Admin\DokumenController::destroyBerkas
 * @see app/Http/Controllers/Admin/DokumenController.php:423
 * @route '/admin/dokumen/berkas/{id}'
 */
    const destroyBerkasForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroyBerkas.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\DokumenController::destroyBerkas
 * @see app/Http/Controllers/Admin/DokumenController.php:423
 * @route '/admin/dokumen/berkas/{id}'
 */
        destroyBerkasForm.delete = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroyBerkas.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroyBerkas.form = destroyBerkasForm
const DokumenController = { index, restoreKategori, storeKategori, updateKategori, destroyKategori, reorderKategori, reorderBerkas, reorderUnified, restoreBerkas, storeBerkas, storeMultipleBerkas, updateBerkas, destroyBerkas }

export default DokumenController