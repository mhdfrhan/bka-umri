import DashboardController from './DashboardController'
import BerandaController from './BerandaController'
import BidangController from './BidangController'
import ProfilController from './ProfilController'
import BeritaController from './BeritaController'
import PengumumanController from './PengumumanController'
import DokumentasiController from './DokumentasiController'
import AsetController from './AsetController'
import DokumenController from './DokumenController'
import PengaturanController from './PengaturanController'
import ChatbotSettingController from './ChatbotSettingController'
import ChatbotMonitoringController from './ChatbotMonitoringController'
import ChatbotFaqController from './ChatbotFaqController'
import UserController from './UserController'
import LogController from './LogController'
import SecurityAuditController from './SecurityAuditController'
import MonitoringController from './MonitoringController'
const Admin = {
    DashboardController: Object.assign(DashboardController, DashboardController),
BerandaController: Object.assign(BerandaController, BerandaController),
BidangController: Object.assign(BidangController, BidangController),
ProfilController: Object.assign(ProfilController, ProfilController),
BeritaController: Object.assign(BeritaController, BeritaController),
PengumumanController: Object.assign(PengumumanController, PengumumanController),
DokumentasiController: Object.assign(DokumentasiController, DokumentasiController),
AsetController: Object.assign(AsetController, AsetController),
DokumenController: Object.assign(DokumenController, DokumenController),
PengaturanController: Object.assign(PengaturanController, PengaturanController),
ChatbotSettingController: Object.assign(ChatbotSettingController, ChatbotSettingController),
ChatbotMonitoringController: Object.assign(ChatbotMonitoringController, ChatbotMonitoringController),
ChatbotFaqController: Object.assign(ChatbotFaqController, ChatbotFaqController),
UserController: Object.assign(UserController, UserController),
LogController: Object.assign(LogController, LogController),
SecurityAuditController: Object.assign(SecurityAuditController, SecurityAuditController),
MonitoringController: Object.assign(MonitoringController, MonitoringController),
}

export default Admin