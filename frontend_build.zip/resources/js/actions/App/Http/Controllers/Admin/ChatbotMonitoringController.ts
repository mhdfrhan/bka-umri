import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\ChatbotMonitoringController::index
 * @see app/Http/Controllers/Admin/ChatbotMonitoringController.php:19
 * @route '/admin/chatbot/monitoring'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/chatbot/monitoring',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\ChatbotMonitoringController::index
 * @see app/Http/Controllers/Admin/ChatbotMonitoringController.php:19
 * @route '/admin/chatbot/monitoring'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\ChatbotMonitoringController::index
 * @see app/Http/Controllers/Admin/ChatbotMonitoringController.php:19
 * @route '/admin/chatbot/monitoring'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\ChatbotMonitoringController::index
 * @see app/Http/Controllers/Admin/ChatbotMonitoringController.php:19
 * @route '/admin/chatbot/monitoring'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\ChatbotMonitoringController::index
 * @see app/Http/Controllers/Admin/ChatbotMonitoringController.php:19
 * @route '/admin/chatbot/monitoring'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\ChatbotMonitoringController::index
 * @see app/Http/Controllers/Admin/ChatbotMonitoringController.php:19
 * @route '/admin/chatbot/monitoring'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\ChatbotMonitoringController::index
 * @see app/Http/Controllers/Admin/ChatbotMonitoringController.php:19
 * @route '/admin/chatbot/monitoring'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Admin\ChatbotMonitoringController::conversations
 * @see app/Http/Controllers/Admin/ChatbotMonitoringController.php:58
 * @route '/admin/chatbot/monitoring/conversations'
 */
export const conversations = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: conversations.url(options),
    method: 'get',
})

conversations.definition = {
    methods: ["get","head"],
    url: '/admin/chatbot/monitoring/conversations',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\ChatbotMonitoringController::conversations
 * @see app/Http/Controllers/Admin/ChatbotMonitoringController.php:58
 * @route '/admin/chatbot/monitoring/conversations'
 */
conversations.url = (options?: RouteQueryOptions) => {
    return conversations.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\ChatbotMonitoringController::conversations
 * @see app/Http/Controllers/Admin/ChatbotMonitoringController.php:58
 * @route '/admin/chatbot/monitoring/conversations'
 */
conversations.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: conversations.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\ChatbotMonitoringController::conversations
 * @see app/Http/Controllers/Admin/ChatbotMonitoringController.php:58
 * @route '/admin/chatbot/monitoring/conversations'
 */
conversations.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: conversations.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\ChatbotMonitoringController::conversations
 * @see app/Http/Controllers/Admin/ChatbotMonitoringController.php:58
 * @route '/admin/chatbot/monitoring/conversations'
 */
    const conversationsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: conversations.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\ChatbotMonitoringController::conversations
 * @see app/Http/Controllers/Admin/ChatbotMonitoringController.php:58
 * @route '/admin/chatbot/monitoring/conversations'
 */
        conversationsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: conversations.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\ChatbotMonitoringController::conversations
 * @see app/Http/Controllers/Admin/ChatbotMonitoringController.php:58
 * @route '/admin/chatbot/monitoring/conversations'
 */
        conversationsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: conversations.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    conversations.form = conversationsForm
/**
* @see \App\Http\Controllers\Admin\ChatbotMonitoringController::showConversation
 * @see app/Http/Controllers/Admin/ChatbotMonitoringController.php:100
 * @route '/admin/chatbot/monitoring/conversations/{id}'
 */
export const showConversation = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: showConversation.url(args, options),
    method: 'get',
})

showConversation.definition = {
    methods: ["get","head"],
    url: '/admin/chatbot/monitoring/conversations/{id}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\ChatbotMonitoringController::showConversation
 * @see app/Http/Controllers/Admin/ChatbotMonitoringController.php:100
 * @route '/admin/chatbot/monitoring/conversations/{id}'
 */
showConversation.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    id: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        id: args.id,
                }

    return showConversation.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\ChatbotMonitoringController::showConversation
 * @see app/Http/Controllers/Admin/ChatbotMonitoringController.php:100
 * @route '/admin/chatbot/monitoring/conversations/{id}'
 */
showConversation.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: showConversation.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\ChatbotMonitoringController::showConversation
 * @see app/Http/Controllers/Admin/ChatbotMonitoringController.php:100
 * @route '/admin/chatbot/monitoring/conversations/{id}'
 */
showConversation.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: showConversation.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\ChatbotMonitoringController::showConversation
 * @see app/Http/Controllers/Admin/ChatbotMonitoringController.php:100
 * @route '/admin/chatbot/monitoring/conversations/{id}'
 */
    const showConversationForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: showConversation.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\ChatbotMonitoringController::showConversation
 * @see app/Http/Controllers/Admin/ChatbotMonitoringController.php:100
 * @route '/admin/chatbot/monitoring/conversations/{id}'
 */
        showConversationForm.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: showConversation.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\ChatbotMonitoringController::showConversation
 * @see app/Http/Controllers/Admin/ChatbotMonitoringController.php:100
 * @route '/admin/chatbot/monitoring/conversations/{id}'
 */
        showConversationForm.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: showConversation.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    showConversation.form = showConversationForm
/**
* @see \App\Http\Controllers\Admin\ChatbotMonitoringController::clearConversations
 * @see app/Http/Controllers/Admin/ChatbotMonitoringController.php:148
 * @route '/admin/chatbot/monitoring/conversations'
 */
export const clearConversations = (options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: clearConversations.url(options),
    method: 'delete',
})

clearConversations.definition = {
    methods: ["delete"],
    url: '/admin/chatbot/monitoring/conversations',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Admin\ChatbotMonitoringController::clearConversations
 * @see app/Http/Controllers/Admin/ChatbotMonitoringController.php:148
 * @route '/admin/chatbot/monitoring/conversations'
 */
clearConversations.url = (options?: RouteQueryOptions) => {
    return clearConversations.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\ChatbotMonitoringController::clearConversations
 * @see app/Http/Controllers/Admin/ChatbotMonitoringController.php:148
 * @route '/admin/chatbot/monitoring/conversations'
 */
clearConversations.delete = (options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: clearConversations.url(options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Admin\ChatbotMonitoringController::clearConversations
 * @see app/Http/Controllers/Admin/ChatbotMonitoringController.php:148
 * @route '/admin/chatbot/monitoring/conversations'
 */
    const clearConversationsForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: clearConversations.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\ChatbotMonitoringController::clearConversations
 * @see app/Http/Controllers/Admin/ChatbotMonitoringController.php:148
 * @route '/admin/chatbot/monitoring/conversations'
 */
        clearConversationsForm.delete = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: clearConversations.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    clearConversations.form = clearConversationsForm
/**
* @see \App\Http\Controllers\Admin\ChatbotMonitoringController::apiStats
 * @see app/Http/Controllers/Admin/ChatbotMonitoringController.php:162
 * @route '/admin/chatbot/monitoring/api/stats'
 */
export const apiStats = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: apiStats.url(options),
    method: 'get',
})

apiStats.definition = {
    methods: ["get","head"],
    url: '/admin/chatbot/monitoring/api/stats',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\ChatbotMonitoringController::apiStats
 * @see app/Http/Controllers/Admin/ChatbotMonitoringController.php:162
 * @route '/admin/chatbot/monitoring/api/stats'
 */
apiStats.url = (options?: RouteQueryOptions) => {
    return apiStats.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\ChatbotMonitoringController::apiStats
 * @see app/Http/Controllers/Admin/ChatbotMonitoringController.php:162
 * @route '/admin/chatbot/monitoring/api/stats'
 */
apiStats.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: apiStats.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\ChatbotMonitoringController::apiStats
 * @see app/Http/Controllers/Admin/ChatbotMonitoringController.php:162
 * @route '/admin/chatbot/monitoring/api/stats'
 */
apiStats.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: apiStats.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\ChatbotMonitoringController::apiStats
 * @see app/Http/Controllers/Admin/ChatbotMonitoringController.php:162
 * @route '/admin/chatbot/monitoring/api/stats'
 */
    const apiStatsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: apiStats.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\ChatbotMonitoringController::apiStats
 * @see app/Http/Controllers/Admin/ChatbotMonitoringController.php:162
 * @route '/admin/chatbot/monitoring/api/stats'
 */
        apiStatsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: apiStats.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\ChatbotMonitoringController::apiStats
 * @see app/Http/Controllers/Admin/ChatbotMonitoringController.php:162
 * @route '/admin/chatbot/monitoring/api/stats'
 */
        apiStatsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: apiStats.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    apiStats.form = apiStatsForm
const ChatbotMonitoringController = { index, conversations, showConversation, clearConversations, apiStats }

export default ChatbotMonitoringController