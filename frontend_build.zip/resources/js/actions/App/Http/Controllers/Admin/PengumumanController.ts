import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\PengumumanController::restore
 * @see app/Http/Controllers/Admin/PengumumanController.php:250
 * @route '/admin/pengumuman/{id}/restore'
 */
export const restore = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: restore.url(args, options),
    method: 'post',
})

restore.definition = {
    methods: ["post"],
    url: '/admin/pengumuman/{id}/restore',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\PengumumanController::restore
 * @see app/Http/Controllers/Admin/PengumumanController.php:250
 * @route '/admin/pengumuman/{id}/restore'
 */
restore.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    id: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        id: args.id,
                }

    return restore.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\PengumumanController::restore
 * @see app/Http/Controllers/Admin/PengumumanController.php:250
 * @route '/admin/pengumuman/{id}/restore'
 */
restore.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: restore.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\PengumumanController::restore
 * @see app/Http/Controllers/Admin/PengumumanController.php:250
 * @route '/admin/pengumuman/{id}/restore'
 */
    const restoreForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: restore.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\PengumumanController::restore
 * @see app/Http/Controllers/Admin/PengumumanController.php:250
 * @route '/admin/pengumuman/{id}/restore'
 */
        restoreForm.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: restore.url(args, options),
            method: 'post',
        })
    
    restore.form = restoreForm
/**
* @see \App\Http\Controllers\Admin\PengumumanController::index
 * @see app/Http/Controllers/Admin/PengumumanController.php:20
 * @route '/admin/pengumuman'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/pengumuman',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\PengumumanController::index
 * @see app/Http/Controllers/Admin/PengumumanController.php:20
 * @route '/admin/pengumuman'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\PengumumanController::index
 * @see app/Http/Controllers/Admin/PengumumanController.php:20
 * @route '/admin/pengumuman'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\PengumumanController::index
 * @see app/Http/Controllers/Admin/PengumumanController.php:20
 * @route '/admin/pengumuman'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\PengumumanController::index
 * @see app/Http/Controllers/Admin/PengumumanController.php:20
 * @route '/admin/pengumuman'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\PengumumanController::index
 * @see app/Http/Controllers/Admin/PengumumanController.php:20
 * @route '/admin/pengumuman'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\PengumumanController::index
 * @see app/Http/Controllers/Admin/PengumumanController.php:20
 * @route '/admin/pengumuman'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Admin\PengumumanController::create
 * @see app/Http/Controllers/Admin/PengumumanController.php:60
 * @route '/admin/pengumuman/create'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/admin/pengumuman/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\PengumumanController::create
 * @see app/Http/Controllers/Admin/PengumumanController.php:60
 * @route '/admin/pengumuman/create'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\PengumumanController::create
 * @see app/Http/Controllers/Admin/PengumumanController.php:60
 * @route '/admin/pengumuman/create'
 */
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\PengumumanController::create
 * @see app/Http/Controllers/Admin/PengumumanController.php:60
 * @route '/admin/pengumuman/create'
 */
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\PengumumanController::create
 * @see app/Http/Controllers/Admin/PengumumanController.php:60
 * @route '/admin/pengumuman/create'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\PengumumanController::create
 * @see app/Http/Controllers/Admin/PengumumanController.php:60
 * @route '/admin/pengumuman/create'
 */
        createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\PengumumanController::create
 * @see app/Http/Controllers/Admin/PengumumanController.php:60
 * @route '/admin/pengumuman/create'
 */
        createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\Admin\PengumumanController::store
 * @see app/Http/Controllers/Admin/PengumumanController.php:68
 * @route '/admin/pengumuman'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/pengumuman',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\PengumumanController::store
 * @see app/Http/Controllers/Admin/PengumumanController.php:68
 * @route '/admin/pengumuman'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\PengumumanController::store
 * @see app/Http/Controllers/Admin/PengumumanController.php:68
 * @route '/admin/pengumuman'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\PengumumanController::store
 * @see app/Http/Controllers/Admin/PengumumanController.php:68
 * @route '/admin/pengumuman'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\PengumumanController::store
 * @see app/Http/Controllers/Admin/PengumumanController.php:68
 * @route '/admin/pengumuman'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Admin\PengumumanController::show
 * @see app/Http/Controllers/Admin/PengumumanController.php:0
 * @route '/admin/pengumuman/{pengumuman}'
 */
export const show = (args: { pengumuman: string | number } | [pengumuman: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/admin/pengumuman/{pengumuman}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\PengumumanController::show
 * @see app/Http/Controllers/Admin/PengumumanController.php:0
 * @route '/admin/pengumuman/{pengumuman}'
 */
show.url = (args: { pengumuman: string | number } | [pengumuman: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { pengumuman: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    pengumuman: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        pengumuman: args.pengumuman,
                }

    return show.definition.url
            .replace('{pengumuman}', parsedArgs.pengumuman.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\PengumumanController::show
 * @see app/Http/Controllers/Admin/PengumumanController.php:0
 * @route '/admin/pengumuman/{pengumuman}'
 */
show.get = (args: { pengumuman: string | number } | [pengumuman: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\PengumumanController::show
 * @see app/Http/Controllers/Admin/PengumumanController.php:0
 * @route '/admin/pengumuman/{pengumuman}'
 */
show.head = (args: { pengumuman: string | number } | [pengumuman: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\PengumumanController::show
 * @see app/Http/Controllers/Admin/PengumumanController.php:0
 * @route '/admin/pengumuman/{pengumuman}'
 */
    const showForm = (args: { pengumuman: string | number } | [pengumuman: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\PengumumanController::show
 * @see app/Http/Controllers/Admin/PengumumanController.php:0
 * @route '/admin/pengumuman/{pengumuman}'
 */
        showForm.get = (args: { pengumuman: string | number } | [pengumuman: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\PengumumanController::show
 * @see app/Http/Controllers/Admin/PengumumanController.php:0
 * @route '/admin/pengumuman/{pengumuman}'
 */
        showForm.head = (args: { pengumuman: string | number } | [pengumuman: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Admin\PengumumanController::edit
 * @see app/Http/Controllers/Admin/PengumumanController.php:122
 * @route '/admin/pengumuman/{pengumuman}/edit'
 */
export const edit = (args: { pengumuman: string | number } | [pengumuman: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/admin/pengumuman/{pengumuman}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\PengumumanController::edit
 * @see app/Http/Controllers/Admin/PengumumanController.php:122
 * @route '/admin/pengumuman/{pengumuman}/edit'
 */
edit.url = (args: { pengumuman: string | number } | [pengumuman: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { pengumuman: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    pengumuman: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        pengumuman: args.pengumuman,
                }

    return edit.definition.url
            .replace('{pengumuman}', parsedArgs.pengumuman.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\PengumumanController::edit
 * @see app/Http/Controllers/Admin/PengumumanController.php:122
 * @route '/admin/pengumuman/{pengumuman}/edit'
 */
edit.get = (args: { pengumuman: string | number } | [pengumuman: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\PengumumanController::edit
 * @see app/Http/Controllers/Admin/PengumumanController.php:122
 * @route '/admin/pengumuman/{pengumuman}/edit'
 */
edit.head = (args: { pengumuman: string | number } | [pengumuman: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\PengumumanController::edit
 * @see app/Http/Controllers/Admin/PengumumanController.php:122
 * @route '/admin/pengumuman/{pengumuman}/edit'
 */
    const editForm = (args: { pengumuman: string | number } | [pengumuman: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\PengumumanController::edit
 * @see app/Http/Controllers/Admin/PengumumanController.php:122
 * @route '/admin/pengumuman/{pengumuman}/edit'
 */
        editForm.get = (args: { pengumuman: string | number } | [pengumuman: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\PengumumanController::edit
 * @see app/Http/Controllers/Admin/PengumumanController.php:122
 * @route '/admin/pengumuman/{pengumuman}/edit'
 */
        editForm.head = (args: { pengumuman: string | number } | [pengumuman: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\Admin\PengumumanController::update
 * @see app/Http/Controllers/Admin/PengumumanController.php:153
 * @route '/admin/pengumuman/{pengumuman}'
 */
export const update = (args: { pengumuman: string | number } | [pengumuman: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/admin/pengumuman/{pengumuman}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\Admin\PengumumanController::update
 * @see app/Http/Controllers/Admin/PengumumanController.php:153
 * @route '/admin/pengumuman/{pengumuman}'
 */
update.url = (args: { pengumuman: string | number } | [pengumuman: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { pengumuman: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    pengumuman: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        pengumuman: args.pengumuman,
                }

    return update.definition.url
            .replace('{pengumuman}', parsedArgs.pengumuman.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\PengumumanController::update
 * @see app/Http/Controllers/Admin/PengumumanController.php:153
 * @route '/admin/pengumuman/{pengumuman}'
 */
update.put = (args: { pengumuman: string | number } | [pengumuman: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\Admin\PengumumanController::update
 * @see app/Http/Controllers/Admin/PengumumanController.php:153
 * @route '/admin/pengumuman/{pengumuman}'
 */
update.patch = (args: { pengumuman: string | number } | [pengumuman: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Admin\PengumumanController::update
 * @see app/Http/Controllers/Admin/PengumumanController.php:153
 * @route '/admin/pengumuman/{pengumuman}'
 */
    const updateForm = (args: { pengumuman: string | number } | [pengumuman: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\PengumumanController::update
 * @see app/Http/Controllers/Admin/PengumumanController.php:153
 * @route '/admin/pengumuman/{pengumuman}'
 */
        updateForm.put = (args: { pengumuman: string | number } | [pengumuman: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\Admin\PengumumanController::update
 * @see app/Http/Controllers/Admin/PengumumanController.php:153
 * @route '/admin/pengumuman/{pengumuman}'
 */
        updateForm.patch = (args: { pengumuman: string | number } | [pengumuman: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Admin\PengumumanController::destroy
 * @see app/Http/Controllers/Admin/PengumumanController.php:226
 * @route '/admin/pengumuman/{pengumuman}'
 */
export const destroy = (args: { pengumuman: string | number } | [pengumuman: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/pengumuman/{pengumuman}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Admin\PengumumanController::destroy
 * @see app/Http/Controllers/Admin/PengumumanController.php:226
 * @route '/admin/pengumuman/{pengumuman}'
 */
destroy.url = (args: { pengumuman: string | number } | [pengumuman: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { pengumuman: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    pengumuman: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        pengumuman: args.pengumuman,
                }

    return destroy.definition.url
            .replace('{pengumuman}', parsedArgs.pengumuman.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\PengumumanController::destroy
 * @see app/Http/Controllers/Admin/PengumumanController.php:226
 * @route '/admin/pengumuman/{pengumuman}'
 */
destroy.delete = (args: { pengumuman: string | number } | [pengumuman: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Admin\PengumumanController::destroy
 * @see app/Http/Controllers/Admin/PengumumanController.php:226
 * @route '/admin/pengumuman/{pengumuman}'
 */
    const destroyForm = (args: { pengumuman: string | number } | [pengumuman: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\PengumumanController::destroy
 * @see app/Http/Controllers/Admin/PengumumanController.php:226
 * @route '/admin/pengumuman/{pengumuman}'
 */
        destroyForm.delete = (args: { pengumuman: string | number } | [pengumuman: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const PengumumanController = { restore, index, create, store, show, edit, update, destroy }

export default PengumumanController