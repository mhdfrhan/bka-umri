import HomeController from './HomeController'
import ProfilController from './ProfilController'
import BidangController from './BidangController'
import BeritaController from './BeritaController'
import PengumumanController from './PengumumanController'
import DokumentasiController from './DokumentasiController'
import LampiranController from './LampiranController'
import KontakController from './KontakController'
import SitemapController from './SitemapController'
import ChatbotController from './ChatbotController'
const Public = {
    HomeController: Object.assign(HomeController, HomeController),
ProfilController: Object.assign(ProfilController, ProfilController),
BidangController: Object.assign(BidangController, BidangController),
BeritaController: Object.assign(BeritaController, BeritaController),
PengumumanController: Object.assign(PengumumanController, PengumumanController),
DokumentasiController: Object.assign(DokumentasiController, DokumentasiController),
LampiranController: Object.assign(LampiranController, LampiranController),
KontakController: Object.assign(KontakController, KontakController),
SitemapController: Object.assign(SitemapController, SitemapController),
ChatbotController: Object.assign(ChatbotController, ChatbotController),
}

export default Public