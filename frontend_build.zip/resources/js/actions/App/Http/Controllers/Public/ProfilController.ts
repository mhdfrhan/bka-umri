import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Public\ProfilController::tentang
 * @see app/Http/Controllers/Public/ProfilController.php:19
 * @route '/profil/tentang-kami'
 */
export const tentang = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: tentang.url(options),
    method: 'get',
})

tentang.definition = {
    methods: ["get","head"],
    url: '/profil/tentang-kami',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Public\ProfilController::tentang
 * @see app/Http/Controllers/Public/ProfilController.php:19
 * @route '/profil/tentang-kami'
 */
tentang.url = (options?: RouteQueryOptions) => {
    return tentang.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Public\ProfilController::tentang
 * @see app/Http/Controllers/Public/ProfilController.php:19
 * @route '/profil/tentang-kami'
 */
tentang.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: tentang.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Public\ProfilController::tentang
 * @see app/Http/Controllers/Public/ProfilController.php:19
 * @route '/profil/tentang-kami'
 */
tentang.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: tentang.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Public\ProfilController::tentang
 * @see app/Http/Controllers/Public/ProfilController.php:19
 * @route '/profil/tentang-kami'
 */
    const tentangForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: tentang.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Public\ProfilController::tentang
 * @see app/Http/Controllers/Public/ProfilController.php:19
 * @route '/profil/tentang-kami'
 */
        tentangForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: tentang.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Public\ProfilController::tentang
 * @see app/Http/Controllers/Public/ProfilController.php:19
 * @route '/profil/tentang-kami'
 */
        tentangForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: tentang.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    tentang.form = tentangForm
/**
* @see \App\Http\Controllers\Public\ProfilController::visiMisi
 * @see app/Http/Controllers/Public/ProfilController.php:32
 * @route '/profil/visi-misi'
 */
export const visiMisi = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: visiMisi.url(options),
    method: 'get',
})

visiMisi.definition = {
    methods: ["get","head"],
    url: '/profil/visi-misi',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Public\ProfilController::visiMisi
 * @see app/Http/Controllers/Public/ProfilController.php:32
 * @route '/profil/visi-misi'
 */
visiMisi.url = (options?: RouteQueryOptions) => {
    return visiMisi.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Public\ProfilController::visiMisi
 * @see app/Http/Controllers/Public/ProfilController.php:32
 * @route '/profil/visi-misi'
 */
visiMisi.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: visiMisi.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Public\ProfilController::visiMisi
 * @see app/Http/Controllers/Public/ProfilController.php:32
 * @route '/profil/visi-misi'
 */
visiMisi.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: visiMisi.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Public\ProfilController::visiMisi
 * @see app/Http/Controllers/Public/ProfilController.php:32
 * @route '/profil/visi-misi'
 */
    const visiMisiForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: visiMisi.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Public\ProfilController::visiMisi
 * @see app/Http/Controllers/Public/ProfilController.php:32
 * @route '/profil/visi-misi'
 */
        visiMisiForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: visiMisi.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Public\ProfilController::visiMisi
 * @see app/Http/Controllers/Public/ProfilController.php:32
 * @route '/profil/visi-misi'
 */
        visiMisiForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: visiMisi.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    visiMisi.form = visiMisiForm
/**
* @see \App\Http\Controllers\Public\ProfilController::struktur
 * @see app/Http/Controllers/Public/ProfilController.php:54
 * @route '/profil/struktur-organisasi'
 */
export const struktur = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: struktur.url(options),
    method: 'get',
})

struktur.definition = {
    methods: ["get","head"],
    url: '/profil/struktur-organisasi',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Public\ProfilController::struktur
 * @see app/Http/Controllers/Public/ProfilController.php:54
 * @route '/profil/struktur-organisasi'
 */
struktur.url = (options?: RouteQueryOptions) => {
    return struktur.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Public\ProfilController::struktur
 * @see app/Http/Controllers/Public/ProfilController.php:54
 * @route '/profil/struktur-organisasi'
 */
struktur.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: struktur.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Public\ProfilController::struktur
 * @see app/Http/Controllers/Public/ProfilController.php:54
 * @route '/profil/struktur-organisasi'
 */
struktur.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: struktur.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Public\ProfilController::struktur
 * @see app/Http/Controllers/Public/ProfilController.php:54
 * @route '/profil/struktur-organisasi'
 */
    const strukturForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: struktur.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Public\ProfilController::struktur
 * @see app/Http/Controllers/Public/ProfilController.php:54
 * @route '/profil/struktur-organisasi'
 */
        strukturForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: struktur.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Public\ProfilController::struktur
 * @see app/Http/Controllers/Public/ProfilController.php:54
 * @route '/profil/struktur-organisasi'
 */
        strukturForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: struktur.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    struktur.form = strukturForm
const ProfilController = { tentang, visiMisi, struktur }

export default ProfilController